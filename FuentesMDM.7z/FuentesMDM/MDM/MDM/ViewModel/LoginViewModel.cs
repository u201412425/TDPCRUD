﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MDM.ViewModel
{
    public class LoginViewModel
    {
        public String UsuarioIngreso { get; set; }
        public String Clave { get; set; }

        public LoginViewModel()
        {

        }
    }
}