﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MDM.Models;
using MDM.ViewModel;
using MDM.Service;
using PagedList;
using Newtonsoft.Json;

namespace MDM.Controllers
{
    public class HomeController : Controller
    {
        CuestionarioService _service = new CuestionarioService();
        public ActionResult Index()
        {
            return RedirectToAction("Login");
        }
        public ActionResult CerrarSesion()
        {
            Session.Clear();
            return RedirectToAction("Login");
        }
        public ActionResult Inicio()
        {
            if(Session["objUsuario"]==null)
                return RedirectToAction("Login");
            return View();
        }
        [HttpPost]
        public JsonResult GrabarRespuesta(string idPregunta,string valuePregunta)
        {
            int idUsuario = ((Usuario)Session["objUsuario"]).IdUsuario;
            _service.AgregarRespuesta(Int32.Parse(idPregunta) ,Convert.ToInt32(valuePregunta), idUsuario);
            string porcentaje = _service.ObtenerPorcentajeCompletado(idUsuario);//Calcular porcentaje completado
            return Json(porcentaje, JsonRequestBehavior.AllowGet);
        }
        public ActionResult InicioCuestionario()
        {
            if (Session["objUsuario"] == null)
                return RedirectToAction("Login");
            Session["recienIniciado"] = false;
            return View();
        }
        public ActionResult Cuestionario(int? page)
        {
            if (Session["objUsuario"] == null)
                return RedirectToAction("Login");
            if (((Usuario)Session["objUsuario"]).EncuestaTerminada == true)
                return RedirectToAction("FinalizarEncuesta");
            int idUsuario = ((Usuario)Session["objUsuario"]).IdUsuario;
            if (((bool)Session["recienIniciado"]) == true && _service.SinRepuesta(idUsuario))
                return RedirectToAction("InicioCuestionario");

            CuestionarioViewModel objViewModel = new CuestionarioViewModel();
            int pageSize = 4;
            int pageNumber = (page ?? 1);
            List<Pregunta> ListaPregunta = objViewModel.LstPregunta.ToPagedList(pageNumber, pageSize).ToList();
            _service.ObtenerRespuestas(ListaPregunta,idUsuario);
            ViewBag.Porcentaje = _service.ObtenerPorcentajeCompletado(idUsuario);
            return View(objViewModel.LstPregunta.ToPagedList(pageNumber, pageSize));
        }
        public ActionResult ResultadoEvaluacion()
        {
            if (Session["objUsuario"] == null)
                return RedirectToAction("Login");
            if (((Usuario)Session["objUsuario"]).EncuestaTerminada == false)
                return RedirectToAction("ResultadoEvaluacionIncompleto");
            int idUsuario = ((Usuario)Session["objUsuario"]).IdUsuario;
            List<ResultadoEvaluacion_Result> listaResultado = _service.ListaResultado(idUsuario);
            _service.AsignarValorEsperado(listaResultado);
            var json = JsonConvert.SerializeObject(listaResultado);
            ViewBag.JsonData = json;
            List<DimensionResultado> ListaDetallesResultado = _service.ListaDetallesResultado(idUsuario);
            return View(ListaDetallesResultado);
        }
        public ActionResult ResultadoEvaluacionIncompleto()
        {
            return View();
        }
        public ActionResult Informacion()
        {
            if (Session["objUsuario"] == null)
                return RedirectToAction("Login");
            return View();
        }
        public ActionResult InformacionNiveles()
        {
            if (Session["objUsuario"] == null)
                return RedirectToAction("Login");
            return View();
        }
        public ActionResult InformacionDimensiones()
        {
            if (Session["objUsuario"] == null)
                return RedirectToAction("Login");
            return View();
        }
        public ActionResult FinalizarEncuesta()
        {
            if (Session["objUsuario"] == null)
                return RedirectToAction("Login");
            int idUsuario = ((Usuario)Session["objUsuario"]).IdUsuario;
            Session["objUsuario"] = _service.FinalizarEncuesta(idUsuario);
            return View();
        }
        public ActionResult ReiniciarEncuesta()
        {
            if (Session["objUsuario"] == null)
                return RedirectToAction("Login");
            int idUsuario = ((Usuario)Session["objUsuario"]).IdUsuario;
            Session["objUsuario"] =_service.BorrarRespuestas(idUsuario);
            return RedirectToAction("Cuestionario");
        }
        [HttpGet]
        public ActionResult Login()
        {
            LoginViewModel objViewModel = new LoginViewModel();
            return View(objViewModel);
        }
        [HttpPost]
        public ActionResult Login(LoginViewModel objViewModel)
        {
            try
            {
                MDMEntities context = new MDMEntities();
                Usuario objUsuario = context.Usuario.FirstOrDefault(x => x.UsuarioIngreso == objViewModel.UsuarioIngreso &&
                                                                    x.Clave == objViewModel.Clave);
                if (objUsuario == null)
                    return View(objViewModel);

                Session["objUsuario"] = objUsuario;//Guardar los datos en la sesion
                Session["recienIniciado"] = true;
                return RedirectToAction("Inicio");
            }
            catch (Exception)
            {
                return View(objViewModel);
            }
        }
    }
}