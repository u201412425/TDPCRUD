﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MDM.Models
{
    public class CriterioResultado
    {
        public string Criterio { get; set; }
        public decimal? ValorCriterio { get; set; }
    }
    public class DimensionResultado
    {
        public string Dimension { get; set; }
        public decimal? ValorDimension { get; set; }
        public int NumeroCriterios { get; set; }
        public List<CriterioResultado> ListaCriterio { get; set; }
    }
}