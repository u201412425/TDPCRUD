﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MDM.Models
{
    public partial class Pregunta
    {
        public int Valor { get; set; }
    }
}