﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MDM.Models;

namespace MDM.Service
{
    public class CuestionarioService
    {
        public MDMEntities context ;
        public CuestionarioService()
        {
            context = new MDMEntities();
        }
        public void AgregarRespuesta(int idPregunta,int  idOpcion,int idUsuario)
        {
            Respuesta objRespuesta= context.Respuesta.Where(x=>x.Opcion.IdPregunta == idPregunta && x.IdUsuario==idUsuario).FirstOrDefault();
            if (objRespuesta == null)
            {
                objRespuesta = new Respuesta();
                objRespuesta.IdUsuario = idUsuario;
                context.Respuesta.Add(objRespuesta);
            }
            objRespuesta.IdOpcion = idOpcion;
            context.SaveChanges();
        }
        public string ObtenerPorcentajeCompletado(int idUsuario)
        {
            int numeroPreguntas = context.Pregunta.Count();
            int numeroRespuestas = context.Respuesta.Where(x => x.IdUsuario == idUsuario).Count();
            double porcentaje = (Convert.ToDouble(numeroRespuestas) /Convert.ToDouble(numeroPreguntas))*100;
            porcentaje = Math.Round(porcentaje, 0);
            return porcentaje.ToString();
        }
        public void ObtenerRespuestas(List<Pregunta> ListaPregunta,int idUsuario)
        {
            foreach(Pregunta objPregunta in ListaPregunta)
            {
                try
                {
                    int IdOpcion = (from re in context.Respuesta
                                    join op in context.Opcion on re.IdOpcion equals op.IdOpcion
                                    join pre in context.Pregunta on op.IdPregunta equals pre.IdPregunta
                                    where pre.IdPregunta == objPregunta.IdPregunta && re.IdUsuario==idUsuario
                                    select (op.IdOpcion)).FirstOrDefault();
                    objPregunta.Valor = IdOpcion;

                }
                catch (Exception)
                {
                    objPregunta.Valor = 0;
                }
            }
        }
        public void AsignarValorEsperado(List<ResultadoEvaluacion_Result> listaResultado)
        {
            foreach (ResultadoEvaluacion_Result obj in listaResultado)
            {
                obj.ValorEsperado = context.Dimension.Where(x => x.NombreDimension == obj.Dimension).FirstOrDefault().ValorEsperado;
            }
        }

        public Usuario BorrarRespuestas(int idUsuario)
        {
            var listaRespuesta = context.Respuesta.Where(x => x.IdUsuario == idUsuario).ToList();
            context.Respuesta.RemoveRange(listaRespuesta);
            var objUsuario = context.Usuario.Where(x => x.IdUsuario == idUsuario).FirstOrDefault();
            objUsuario.EncuestaTerminada = false;
            context.SaveChanges();
            return objUsuario;
        }

        public bool SinRepuesta(int idUsuario)
        {
            var NmroRespuesta = context.Respuesta.Where(x => x.IdUsuario == idUsuario).Count();
            if(NmroRespuesta==0)
                return true;
            else
                return false;
        }

        public Usuario FinalizarEncuesta(int idUsuario)
        {
            var objUsuario = context.Usuario.Where(x => x.IdUsuario == idUsuario).FirstOrDefault();
            objUsuario.EncuestaTerminada = true;
            context.SaveChanges();
            return objUsuario;
        }
        public List<ResultadoEvaluacion_Result> ListaResultado(int idUsuario)
        {
            var ListaResultado=context.ResultadoEvaluacion(idUsuario).ToList();
            return ListaResultado;
        }
        public List<DimensionResultado> ListaDetallesResultado(int idUsuario)
        {
            List<DimensionResultado> ListaDetallesResultado = new List<DimensionResultado>();
            var ListaResultado = context.ResultadoEvaluacion(idUsuario);
            var ListaCriterio = context.ResultadoCriterio(idUsuario);
            foreach (var obj in ListaResultado)
            {
                DimensionResultado objNewDimension = new DimensionResultado();
                objNewDimension.Dimension = obj.Dimension;
                objNewDimension.ValorDimension = obj.Valor;
                objNewDimension.ListaCriterio = (from cri in context.Criterio
                                                 join lc in ListaCriterio on cri.NombreCriterio equals lc.Criterio
                                                 join di in context.Dimension on cri.IdDimension equals di.IdDimension
                                                 where di.NombreDimension==obj.Dimension
                                                 select new CriterioResultado
                                                 {
                                                     Criterio = cri.NombreCriterio,
                                                     ValorCriterio = lc.Valor
                                                 }).ToList();
                objNewDimension.NumeroCriterios = objNewDimension.ListaCriterio.Count;
                ListaDetallesResultado.Add(objNewDimension);
            }
            return ListaDetallesResultado;
        }
    }
}