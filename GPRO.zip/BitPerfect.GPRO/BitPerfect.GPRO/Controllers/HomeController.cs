﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Globalization;
using BitPerfect.GPRO.Filters;
using BitPerfect.GPRO.Helpers;
using BitPerfect.GPRO.ViewModel.Home;
using BitPerfect.GPRO.Logic;
using BitPerfect.GPRO.Models;
using System.Data.Entity;

namespace BitPerfect.GPRO.Controllers
{
    public class HomeController : BaseController
    {
        public ActionResult Index()
        {
            return RedirectToAction("Dashboard");
        }

        public ActionResult Idioma(String lang, String returnURL)
        {
            Session["Culture"] = new CultureInfo(lang);
            return Redirect(returnURL);
        }

        public ContentResult KeepAlive()
        {
            Session.Set(SessionKey.UsuarioId, Session.Get(SessionKey.UsuarioId));
            return Content("");
        }

        public ActionResult Login()
        {
            return View();
        }

        [AppAuthorize(AppRol.Administrador)]
        [ViewParameter("Dashboard", "fa fa-dashboard")]
        public ActionResult AdministradorIndex()
        {
            var viewModel = new AdministradorIndexViewModel();
            viewModel.CargarDatos(CargarDatosContext());
            return View(viewModel);
        }

        [AppAuthorize(AppRol.Usuario)]
        [ViewParameter("Dashboard", "fa fa-dashboard")]
        public ActionResult UsuarioIndex()
        {
            var viewModel = new UsuarioIndexViewModel();
            viewModel.CargarDatos(CargarDatosContext());
            return View(viewModel);
        }

        [HttpPost]
        public ActionResult Login(LoginViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }

            var usuario = context.Usuario.FirstOrDefault(x => x.Codigo == model.Codigo && x.Password == model.Contrasena);

            if (usuario == null)
            {
                PostMessage(MessageType.Error, "Usuario y/o Contraseña Incorrectos");
            }
            else
            {
                Session.Clear();
                AppRol rol = AppRol.Usuario;

                switch (usuario.Rol)
                {
                    case ConstantHelpers.Rol.USUARIO: rol = AppRol.Usuario; break;
                    case ConstantHelpers.Rol.ADMINISTRADOR: rol = AppRol.Administrador; break;
                }

                Session.Set(SessionKey.Usuario, usuario);
                Session.Set(SessionKey.UsuarioId, usuario.UsuarioId);
                Session.Set(SessionKey.NombreCompleto, usuario.Apellido + ", " + usuario.Nombre);
                Session.Set(SessionKey.AppRol, rol);
                Session.Set(SessionKey.CodigoRol, usuario.Rol);

                return Dashboard();
            }

            return View(model);
        }

        public ActionResult Dashboard()
        {
            switch (Session.GetAppRol())
            {
                case AppRol.Usuario: return Session.GetProyecto() == null ? RedirectToAction("ChooseProyecto") : RedirectToAction("UsuarioIndex");
                case AppRol.Administrador: return RedirectToAction("AdministradorIndex");
            }

            return RedirectToAction("Login");
        }

        public ActionResult Logout()
        {
            Session.Clear();
            return RedirectToAction("Login");
        }

        [AppAuthorize(AppRol.Usuario)]
        public ActionResult ChooseProyecto()
        {
            ChooseProyectoViewModel viewModel = new ChooseProyectoViewModel();
            viewModel.CargarDatos(CargarDatosContext());
            return View(viewModel);
        }

        [AppAuthorize(AppRol.Usuario)]
        [PermisoProyecto("ProyectoId", PermisoLogic.TipoPermiso.Lectura)]
        public ActionResult SwitchProyecto(Int32 ProyectoId)
        {
            context.Configuration.ProxyCreationEnabled = false;

            var usuarioId = Session.GetUsuarioId();
            var usuarioProyecto = context.UsuarioProyecto.Include(x=>x.Proyecto).FirstOrDefault(x=>x.ProyectoId == ProyectoId && x.UsuarioId == usuarioId);

            if (usuarioProyecto == null)
            {
                PostMessage(MessageType.Error, "El usuario no está asignado al proyecto.");
                return RedirectToAction("ChooseProyecto");
            }

            Session.Set(SessionKey.ProyectoId, usuarioProyecto.ProyectoId);
            Session.Set(SessionKey.Proyecto, usuarioProyecto.Proyecto);
            Session.Set(SessionKey.RolProyecto, usuarioProyecto.Rol);
            return Dashboard();
        }
    }
}
