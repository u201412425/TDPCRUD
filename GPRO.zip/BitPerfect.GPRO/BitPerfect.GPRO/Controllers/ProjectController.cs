﻿using BitPerfect.GPRO.Filters;
using BitPerfect.GPRO.Helpers;
using BitPerfect.GPRO.Models;
using BitPerfect.GPRO.ViewModel.Project;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Transactions;
using System.Web;
using System.Web.Mvc;

namespace BitPerfect.GPRO.Controllers
{
    [AppAuthorize(AppRol.Administrador)]
    public class ProjectController : BaseController
    {
        //
        // GET: /Project/

        public ActionResult ListProyecto()
        {
            var ListProyectoViewModel = new ListProyectoViewModel();
            ListProyectoViewModel.CargarDatos(CargarDatosContext());
            return View(ListProyectoViewModel);
        }

        public ActionResult EditProyecto(Int32? ProyectoId)
        {
            var EditProyectoViewModel = new EditProyectoViewModel();
            EditProyectoViewModel.CargarDatos(CargarDatosContext(), ProyectoId);
            return View(EditProyectoViewModel);
        }

        [HttpPost]
        public ActionResult EditProyecto(EditProyectoViewModel model)
        {
            try
            {
                using (var TransactionScope = new TransactionScope())
                {
                    if (!ModelState.IsValid)
                    {
                        model.CargarDatos(CargarDatosContext(), model.ProyectoId);
                        TryUpdateModel(model);
                        PostMessage(MessageTemplate.DatosIncorrectos);
                        return View(model);
                    }

                    var Proyecto = new Proyecto();

                    if (model.ProyectoId.HasValue)
                    {
                        Proyecto = context.Proyecto.First(x => x.ProyectoId == model.ProyectoId);
                    }
                    else
                    {
                        Proyecto.FechaRegistro = DateTime.Now;
                        Proyecto.UsuarioRegistroId = Session.GetUsuarioId();
                        context.Proyecto.Add(Proyecto);
                    }

                    Proyecto.Codigo = model.Codigo;
                    Proyecto.Nombre = model.Nombre;
                    Proyecto.Estado = model.Estado;

                    context.SaveChanges();

                    TransactionScope.Complete();

                    PostMessage(MessageTemplate.ExitoGuardar);
                    return RedirectToAction("ListProyecto");
                }
            }
            catch (Exception ex)
            {
                InvalidarContext();
                PostMessage(MessageTemplate.ErrorGuardar, ex);
                model.CargarDatos(CargarDatosContext(), model.ProyectoId);
                TryUpdateModel(model);
                return View(model);
            }
        }

        public ActionResult ListEquipo(Int32 ProyectoId)
        {
            var viewModel = new ListEquipoViewModel();
            viewModel.CargarDatos(CargarDatosContext(), ProyectoId);
            return View("_ListEquipo", viewModel);
        }

        public ActionResult AdminEquipo(Int32 ProyectoId)
        {
            var AdminEquipoViewModel = new AdminEquipoViewModel();
            AdminEquipoViewModel.CargarDatos(CargarDatosContext(), ProyectoId);
            return View(AdminEquipoViewModel);
        }

        [HttpPost]
        public ActionResult AdminEquipo(AdminEquipoViewModel model, FormCollection form)
        {
            try
            {
                using (var TransactionScope = new TransactionScope())
                {
                    if (!ModelState.IsValid)
                    {
                        model.CargarDatos(CargarDatosContext(), model.ProyectoId);
                        TryUpdateModel(model);
                        PostMessage(MessageTemplate.DatosIncorrectos);
                        return View(model);
                    }

                    //Eliminamos todo lo anterior
                    context.UsuarioProyecto.RemoveRange(context.UsuarioProyecto.Where(x => x.ProyectoId == model.ProyectoId));

                    foreach (var usuarioSeleccionadoId in model.LstUsuarioSeleccionadoId)
                    {
                        var usuarioProyecto = new UsuarioProyecto();
                        usuarioProyecto.UsuarioId = usuarioSeleccionadoId;
                        usuarioProyecto.ProyectoId = model.ProyectoId;

                        var formValue = form["USU-ROL-" + usuarioSeleccionadoId];

                        if (formValue != null)
                            usuarioProyecto.Rol = formValue;

                        context.UsuarioProyecto.Add(usuarioProyecto);
                    }
                    context.SaveChanges();

                    TransactionScope.Complete();

                    PostMessage(MessageTemplate.ExitoGuardar);
                    return RedirectToAction("ListProyecto");
                }
            }
            catch (Exception ex)
            {
                InvalidarContext();
                PostMessage(MessageTemplate.ErrorGuardar, ex);
                model.CargarDatos(CargarDatosContext(), model.ProyectoId);
                TryUpdateModel(model);
                return View(model);
            }
        }

        public ActionResult ExploreProyecto(Int32 ProyectoId)
        {
            context.Configuration.ProxyCreationEnabled = false;

            var usuarioId = Session.GetUsuarioId();
            var proyecto = context.Proyecto.Find(ProyectoId);
            /*var usuarioProyecto = context.UsuarioProyecto.Where(x => x.ProyectoId == ProyectoId && x.UsuarioId == usuarioId);

            if (usuarioProyecto == null)
            {
                PostMessage(MessageType.Error, "El usuario no está asignado al proyecto.");
                return RedirectToAction("ChooseProyecto");
            }*/

            Session.Set(SessionKey.ProyectoId, ProyectoId);
            Session.Set(SessionKey.Proyecto, proyecto);
            Session.Set(SessionKey.RolProyecto, ConstantHelpers.RolProyecto.JEFE_PROYECTO);

            return RedirectToAction("UsuarioIndex", "Home");
        }
    }
}
