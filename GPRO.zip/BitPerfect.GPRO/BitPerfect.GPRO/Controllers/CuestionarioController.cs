﻿using BitPerfect.GPRO.Filters;
using BitPerfect.GPRO.Helpers;
using BitPerfect.GPRO.Models;
using BitPerfect.GPRO.ViewModel.Cuestionario;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Transactions;
using System.Web;
using System.Web.Mvc;

namespace BitPerfect.GPRO.Controllers
{
    [AppAuthorize(AppRol.Administrador)]
    public class CuestionarioController : BaseController
    {
        //
        // GET: /Cuestionario/

        public ActionResult Index()
        {
            return View();
        }
        public ActionResult ListCuestionario()
        {
            var ListCuestionarioViewModel = new ListCuestionarioViewModel();
            ListCuestionarioViewModel.CargarDatos(CargarDatosContext());
            return View(ListCuestionarioViewModel);
        }
        public ActionResult ExploreCuestionario(Int32? CuestionarioId)
        {
            var EditCuestionarioViewModel = new EditCuestionarioViewModel();
            EditCuestionarioViewModel.CargarDatos(CargarDatosContext(), CuestionarioId);
            return View(EditCuestionarioViewModel);
        }
        public ActionResult EditCuestionario(Int32? CuestionarioId)
        {
            var EditCuestionarioViewModel = new EditCuestionarioViewModel();
            EditCuestionarioViewModel.CargarDatos(CargarDatosContext(), CuestionarioId);
            return View(EditCuestionarioViewModel);
        }
        [HttpPost]
        public ActionResult EditCuestionario(EditCuestionarioViewModel model)
        {
            try
            {
                using (var TransactionScope = new TransactionScope())
                {
                    if (!ModelState.IsValid)
                    {
                        model.CargarDatos(CargarDatosContext(), model.CuestionarioId);
                        TryUpdateModel(model);
                        PostMessage(MessageTemplate.DatosIncorrectos);
                        return View(model);
                    }

                    var Cuestionario = new Cuestionario();

                    if (model.CuestionarioId.HasValue)
                    {
                        Cuestionario = context.Cuestionario.First(x => x.CuestionarioId == model.CuestionarioId);
                    }
                    else
                    {
                        Cuestionario.FechaRegistro = DateTime.Now;
                        Cuestionario.UsuarioRegistroId = Session.GetUsuarioId();
                        context.Cuestionario.Add(Cuestionario);
                    }

                    Cuestionario.Nombre = model.Nombre;
                    Cuestionario.Descripcion = model.Descripcion;
                    Cuestionario.Estado = model.Estado;

                    context.SaveChanges();

                    TransactionScope.Complete();

                    PostMessage(MessageTemplate.ExitoGuardar);
                    return RedirectToAction("ListCuestionario");
                }
            }
            catch (Exception ex)
            {
                InvalidarContext();
                PostMessage(MessageTemplate.ErrorGuardar, ex);
                model.CargarDatos(CargarDatosContext(), model.CuestionarioId);
                TryUpdateModel(model);
                return View(model);
            }
        }

        public ActionResult ListPregunta(Int32 CuestionarioId)
        {
            var viewModel = new ListPreguntaViewModel();
            viewModel.CargarDatos(CargarDatosContext(), CuestionarioId);
            return View("_ListPregunta", viewModel);
        }
        public ActionResult AdminPregunta(Int32 CuestionarioId, Int32? Exito, string ExceptionMessage)
        {
            if (Exito.HasValue && Exito == 1)
            {
                PostMessage(MessageTemplate.ExitoGuardar);
            }
            if (!String.IsNullOrEmpty(ExceptionMessage))
            {
                PostMessage(MessageTemplate.ErrorGuardar, new Exception(ExceptionMessage));
            }
            var ListPreguntaViewModel = new ListPreguntaViewModel();
            ListPreguntaViewModel.CargarDatos(CargarDatosContext(), CuestionarioId);
            return View(ListPreguntaViewModel);
        }
       public ActionResult EditPregunta(Int32? PreguntaCuestionarioId,Int32? CuestionarioId)
        {
            var viewModel = new EditPreguntaViewModel();
            if (CuestionarioId.HasValue)
            {
                viewModel.CuestionarioId = CuestionarioId;
            }
            viewModel.CargarDatos(CargarDatosContext(), PreguntaCuestionarioId);
            return View("_EditPregunta", viewModel);
        }
        [HttpPost]
        public ActionResult EditPregunta(string data)
        {
            try
            {
                using (var TransactionScope = new TransactionScope())
                {
                    var model = new PreguntaCuestionario();
                    JsonConvert.PopulateObject(data, model);
                    var PreguntaAnterior = new PreguntaCuestionario();
                    if (model.PreguntaCuestionarioId > 0)
                    {
                        PreguntaAnterior = context.PreguntaCuestionario.First(x => x.PreguntaCuestionarioId == model.PreguntaCuestionarioId);
                        PreguntaAnterior.Estado = "INA";
                        context.SaveChanges();
                    }

                    var pregunta = new PreguntaCuestionario();
                    context.PreguntaCuestionario.Add(pregunta);

                    pregunta.OpcionCuestionario = model.OpcionCuestionario;
                    pregunta.CuestionarioId = model.CuestionarioId;
                    pregunta.Pregunta = model.Pregunta;
                    pregunta.Orden = model.Orden;
                    pregunta.EsMultiple = model.EsMultiple;
                    pregunta.TieneCampoLibre = model.TieneCampoLibre;
                    pregunta.FechaRegistro = DateTime.Now;
                    pregunta.UsuarioRegistroId = Session.GetUsuarioId();
                    pregunta.Estado = "ACT";
                    context.SaveChanges();

                    TransactionScope.Complete();
                    Int32 CuestionarioId = pregunta.CuestionarioId;
                   
                    return Json(1);
                    //return Json(Url.Action("AdminPregunta", "Cuestionario") + "?CuestionarioId=" + CuestionarioId);
                }
            }
            catch (Exception ex)
            {
                InvalidarContext();
                return Json(ex.Message);
            }
        }

        public ActionResult ExplorePregunta(Int32? PreguntaCuestionarioId)
        {
            var EditPreguntaViewModel = new EditPreguntaViewModel();
            EditPreguntaViewModel.CargarDatos(CargarDatosContext(), PreguntaCuestionarioId);
            return View(EditPreguntaViewModel);
        }
    }
}
