﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BitPerfect.GPRO.Helpers;
using BitPerfect.GPRO.ViewModel.Kanban;
using BitPerfect.GPRO.Filters;

namespace BitPerfect.GPRO.Controllers
{
    public class KanbanController : BaseController
    {
        [ViewParameter("Kanban", "fa fa-th-large")]
        public ActionResult Index()
        {
            var proyectoId = Session.GetProyectoId();
            var iteracion = context.Iteracion.FirstOrDefault(x => x.ProyectoId == proyectoId && x.FechaInicio <= DateTime.Now && x.FechaFin >= DateTime.Now);
            if (iteracion == null)
            {
                PostMessage(MessageType.Info, "No hay una iteración activa.");
                return RedirectToAction("Dashboard", "Home");
            }

            var viewModel = new IndexViewModel();
            viewModel.CargarDatos(CargarDatosContext(), iteracion.IteracionId);
            return View(viewModel);
        }

    }
}
