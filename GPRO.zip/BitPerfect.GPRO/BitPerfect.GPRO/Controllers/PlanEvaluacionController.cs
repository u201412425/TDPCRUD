﻿using BitPerfect.GPRO.Filters;
using BitPerfect.GPRO.Helpers;
using BitPerfect.GPRO.Models;
using BitPerfect.GPRO.ViewModel.PlanEvaluacion;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Transactions;
using System.Web;
using System.Web.Mvc;
namespace BitPerfect.GPRO.Controllers
{
    [AppAuthorize(AppRol.Administrador)]
    public class PlanEvaluacionController : BaseController
    {
        //
        // GET: /PlanEvaluacion/

        public ActionResult Index()
        {
            return View();
        }
        public ActionResult ListPlanEvaluacion()
        {
            var ListPlanEvaluacionViewModel = new ListPlanEvaluacionViewModel();
            ListPlanEvaluacionViewModel.CargarDatos(CargarDatosContext());
            return View(ListPlanEvaluacionViewModel);
        }
        public ActionResult ExplorePlanEvaluacion(Int32? PlanEvaluacionId)
        {
            var EditPlanEvaluacionViewModel = new EditPlanEvaluacionViewModel();
            EditPlanEvaluacionViewModel.CargarDatos(CargarDatosContext(), PlanEvaluacionId);
            return View(EditPlanEvaluacionViewModel);
        }
        public ActionResult EditPlanEvaluacion(Int32? PlanEvaluacionId)
        {
            var EditPlanEvaluacionViewModel = new EditPlanEvaluacionViewModel();
            EditPlanEvaluacionViewModel.CargarDatos(CargarDatosContext(), PlanEvaluacionId);
            return View(EditPlanEvaluacionViewModel);
        }
        [HttpPost]
        public ActionResult EditPlanEvaluacion(EditPlanEvaluacionViewModel model)
        {
            try
            {
                using (var TransactionScope = new TransactionScope())
                {
                    if (!ModelState.IsValid)
                    {
                        model.CargarDatos(CargarDatosContext(), model.PlanEvaluacionId);
                        TryUpdateModel(model);
                        PostMessage(MessageTemplate.DatosIncorrectos);
                        return View(model);
                    }

                    var PlanEvaluacion = new PlanEvaluacion();

                    if (model.PlanEvaluacionId.HasValue)
                    {
                        PlanEvaluacion = context.PlanEvaluacion.First(x => x.PlanEvaluacionId == model.PlanEvaluacionId);
                    }
                    else
                    {
                        PlanEvaluacion.FechaRegistro = DateTime.Now;
                        PlanEvaluacion.UsuarioRegistroId = Session.GetUsuarioId();
                        context.PlanEvaluacion.Add(PlanEvaluacion);
                    }

                    PlanEvaluacion.Nombre = model.Nombre;
                    PlanEvaluacion.Estado = model.Estado;

                    context.SaveChanges();

                    TransactionScope.Complete();

                    PostMessage(MessageTemplate.ExitoGuardar);
                    return RedirectToAction("ListPlanEvaluacion");
                }
            }
            catch (Exception ex)
            {
                InvalidarContext();
                PostMessage(MessageTemplate.ErrorGuardar, ex);
                model.CargarDatos(CargarDatosContext(), model.PlanEvaluacionId);
                TryUpdateModel(model);
                return View(model);
            }
        }

        public ActionResult ListFechaPlanEvaluacion(Int32 PlanEvaluacionId)
        {
            var viewModel = new ListFechaPlanEvaluacionViewModel();
            viewModel.CargarDatos(CargarDatosContext(), PlanEvaluacionId);
            return View("_ListFechaPlanEvaluacion", viewModel);
        }
        public ActionResult AdminFechaPlanEvaluacion(Int32 PlanEvaluacionId)
        {
            var ListFechaPlanEvaluacionViewModel = new ListFechaPlanEvaluacionViewModel();
            ListFechaPlanEvaluacionViewModel.CargarDatos(CargarDatosContext(), PlanEvaluacionId);
            return View(ListFechaPlanEvaluacionViewModel);
        }
        public ActionResult EditFechaPlanEvaluacion(Int32? FechaPlanEvaluacionId, Int32? PlanEvaluacionId)
        {
            var viewModel = new EditFechaPlanEvaluacionViewModel();
            if(PlanEvaluacionId.HasValue)
            {
                viewModel.PlanEvaluacionId = PlanEvaluacionId.Value;
            }
            viewModel.CargarDatos(CargarDatosContext(), FechaPlanEvaluacionId);
            return View(viewModel);
        }
        [HttpPost]
        public ActionResult EditFechaPlanEvaluacion(EditFechaPlanEvaluacionViewModel model)
        {
            try
            {
                using (var TransactionScope = new TransactionScope())
                {
                    if (!ModelState.IsValid)
                    {
                        model.CargarDatos(CargarDatosContext(), model.FechaPlanEvaluacionId);
                        TryUpdateModel(model);
                        PostMessage(MessageTemplate.DatosIncorrectos);
                        return View(model);
                    }

                    var FechaPlanEvaluacion = new FechaPlanEvaluacion();

                    if (model.FechaPlanEvaluacionId.HasValue)
                    {
                        FechaPlanEvaluacion = context.FechaPlanEvaluacion.First(x => x.FechaPlanEvaluacionId == model.FechaPlanEvaluacionId);
                    }
                    else
                    {
                        FechaPlanEvaluacion.FechaRegistro = DateTime.Now;
                        FechaPlanEvaluacion.UsuarioRegistroId = Session.GetUsuarioId();
                        context.FechaPlanEvaluacion.Add(FechaPlanEvaluacion);
                    }
                    FechaPlanEvaluacion.PlanEvaluacionId = model.PlanEvaluacionId;
                    FechaPlanEvaluacion.Nombre = model.Nombre;
                    FechaPlanEvaluacion.Estado = model.Estado;
                    FechaPlanEvaluacion.FechaInicio = model.FechaInicio;
                    FechaPlanEvaluacion.FechaFin = model.FechaFin;

                    context.SaveChanges();

                    TransactionScope.Complete();

                    PostMessage(MessageTemplate.ExitoGuardar);
                    return RedirectToAction("AdminFechaPlanEvaluacion", new { PlanEvaluacionId=model.PlanEvaluacionId});
                }
            }
            catch (Exception ex)
            {
                InvalidarContext();
                PostMessage(MessageTemplate.ErrorGuardar, ex);
                model.CargarDatos(CargarDatosContext(), model.PlanEvaluacionId);
                TryUpdateModel(model);
                return View(model);
            }
        }
        public ActionResult ExploreFechaPlanEvaluacion(Int32? FechaPlanEvaluacionId)
        {
            var EditFechaPlanEvaluacionViewModel = new EditFechaPlanEvaluacionViewModel();
            EditFechaPlanEvaluacionViewModel.CargarDatos(CargarDatosContext(), FechaPlanEvaluacionId);
            return View(EditFechaPlanEvaluacionViewModel);
        }
    }
}
