﻿using BitPerfect.GPRO.Filters;
using BitPerfect.GPRO.Helpers;
using BitPerfect.GPRO.Models;
using BitPerfect.GPRO.ViewModel.Revision;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Transactions;
using System.Web;
using System.Web.Mvc;

namespace BitPerfect.GPRO.Controllers
{
    [AppAuthorize(AppRol.Administrador)]
    public class RevisionController : BaseController
    {
        //
        // GET: /Revision/

        public ActionResult Index()
        {
            return View();
        }
        public ActionResult ListEvaluacion()
        {
            ListEvaluacionViewModel viewModel = new ListEvaluacionViewModel();
            viewModel.CargarDatos(CargarDatosContext());
            return View(viewModel);
        }
        [HttpPost]
        public ActionResult ListEvaluacion(ListEvaluacionViewModel viewModel)
        {
            viewModel.CargarDatos(CargarDatosContext());
            return View(viewModel);
        }

        public ActionResult VerRespuesta(Int32? EvaluacionId, Int32? CuestionarioId)
        {
            var viewModel = new VerRespuestaViewModel();
            viewModel.CargarDatos(CargarDatosContext(), EvaluacionId,CuestionarioId);
            return View("_VerRespuesta", viewModel);
        }
    }
}
