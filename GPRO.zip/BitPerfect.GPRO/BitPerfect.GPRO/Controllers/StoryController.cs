﻿using BitPerfect.GPRO.Helpers;
using BitPerfect.GPRO.Models;
using BitPerfect.GPRO.ViewModel.Story;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Transactions;
using System.Web;
using System.Web.Mvc;
using System.Data.Entity;
using BitPerfect.GPRO.Filters;
using BitPerfect.GPRO.Logic;

namespace BitPerfect.GPRO.Controllers
{
    public class StoryController : BaseController
    {
        [ViewParameter("Historia", "fa fa-header")]
        public ActionResult ListHistoria()
        {
            var ListHistoriaViewModel = new ListHistoriaViewModel();
            ListHistoriaViewModel.CargarDatos(CargarDatosContext());
            return View(ListHistoriaViewModel);
        }

        [ViewParameter("Historia", "fa fa-header")]
        [PermisoHistoria("HistoriaId", PermisoLogic.TipoPermiso.Lectura)]
        public ActionResult InfoDescripcionHistoria(Int32 HistoriaId)
        {
            var historia = context.Historia.Find(HistoriaId);
            return View("_InfoDescripcionHistoria", historia);
        }

        [ViewParameter("Historia", "fa fa-header")]
        public ActionResult EditHistoria(Int32? HistoriaId)
        {
            var EditHistoriaViewModel = new EditHistoriaViewModel();
            EditHistoriaViewModel.CargarDatos(CargarDatosContext(), HistoriaId);
            return View(EditHistoriaViewModel);
        }

        [HttpPost]
        [ViewParameter("Historia", "fa fa-header")]
        public ActionResult EditHistoria(EditHistoriaViewModel model)
        {
            try
            {
                using (var TransactionScope = new TransactionScope())
                {
                    if (!ModelState.IsValid)
                    {
                        model.CargarDatos(CargarDatosContext(), model.HistoriaId);
                        TryUpdateModel(model);
                        PostMessage(MessageTemplate.DatosIncorrectos);
                        return View(model);
                    }

                    var Historia = new Historia();

                    if (model.HistoriaId.HasValue)
                    {
                        Historia = context.Historia.First(x => x.HistoriaId == model.HistoriaId);
                    }
                    else
                    {
                        Historia.FechaRegistro = DateTime.Now;
                        Historia.HorasEfectivas = 0;
                        Historia.NumeroTareas = 0;
                        Historia.UsuarioRegistroId = Session.GetUsuarioId();
                        Historia.ProyectoId = Session.GetProyectoId();
                        Historia.Estado = ConstantHelpers.EstadoHistoria.DISENO;
                        context.Historia.Add(Historia);
                    }

                    Historia.Codigo = model.Codigo;
                    Historia.Nombre = model.Nombre;
                    Historia.Descripcion = model.Descripcion;
                    Historia.HorasEstimadas = model.HorasEstimadas;

                    context.SaveChanges();

                    TransactionScope.Complete();

                    PostMessage(MessageTemplate.ExitoGuardar);
                    return RedirectToAction("ListHistoria");
                }
            }
            catch (Exception ex)
            {
                InvalidarContext();
                PostMessage(MessageTemplate.ErrorGuardar, ex);
                model.CargarDatos(CargarDatosContext(), model.HistoriaId);
                TryUpdateModel(model);
                return View(model);
            }
        }

        [ViewParameter("Historia", "fa fa-header")]
        [PermisoHistoria("HistoriaId", PermisoLogic.TipoPermiso.Escritura)]
        public ActionResult AdminTarea(Int32 HistoriaId, Int32? TareaId)
        {
            var AdminTareaViewModel = new AdminTareaViewModel();
            AdminTareaViewModel.CargarDatos(CargarDatosContext(), HistoriaId, TareaId);
            return View("_AdminTarea", AdminTareaViewModel);
        }

        [HttpPost]
        [ViewParameter("Historia", "fa fa-header")]
        [PermisoHistoria("HistoriaId", PermisoLogic.TipoPermiso.Escritura)]
        public ActionResult AdminTarea(AdminTareaViewModel model)
        {
            try
            {
                using (var TransactionScope = new TransactionScope())
                {
                    if (!ModelState.IsValid)
                    {
                        model.CargarDatos(CargarDatosContext(), model.HistoriaId, model.TareaId);
                        TryUpdateModel(model);
                        PostMessage(MessageTemplate.DatosIncorrectos);
                        return View("_AdminTarea", model);
                    }

                    var tarea = new Tarea();
                    var historia = context.Historia.Find(model.HistoriaId);

                    if (model.TareaId.HasValue)
                    {
                        tarea = context.Tarea.First(x => x.TareaId == model.TareaId);
                    }
                    else
                    {
                        tarea.Estado = ConstantHelpers.EstadoTarea.PENDIENTE;
                        tarea.FechaRegistro = DateTime.Now;
                        tarea.UsuarioRegistroId = Session.GetUsuarioId();
                        tarea.HistoriaId = model.HistoriaId;
                        context.Tarea.Add(tarea);
                    }

                    tarea.Descripcion = model.Descripcion;
                    tarea.Nombre = model.Nombre;

                    context.SaveChanges();

                    historia.NumeroTareas = context.Tarea.Count(x => x.HistoriaId == model.HistoriaId && x.Estado != ConstantHelpers.EstadoTarea.INACTIVO);

                    context.SaveChanges();

                    TransactionScope.Complete();

                    PostMessage(MessageTemplate.ExitoGuardar);
                }
                ModelState.Clear();
                return AdminTarea(model.HistoriaId, null);
            }
            catch (Exception ex)
            {
                InvalidarContext();
                PostMessage(MessageTemplate.ErrorGuardar, ex);
                model.CargarDatos(CargarDatosContext(), model.HistoriaId, model.TareaId);
                TryUpdateModel(model);
                return View("_AdminTarea", model);
            }
        }

        [ViewParameter("Historia", "fa fa-header")]
        [PermisoHistoria("HistoriaId", PermisoLogic.TipoPermiso.Escritura)]
        public ActionResult DeleteTarea(Int32 HistoriaId, Int32 TareaId)
        {
            try
            {
                var tarea = context.Tarea.Find(TareaId);
                var historia = context.Historia.Find(tarea.HistoriaId);
                tarea.Estado = ConstantHelpers.EstadoTarea.INACTIVO;
                context.SaveChanges();

                historia.NumeroTareas = context.Tarea.Count(x => x.HistoriaId == historia.HistoriaId && x.Estado != ConstantHelpers.EstadoTarea.INACTIVO);
                context.SaveChanges();
                return AdminTarea(HistoriaId, null);
            }
            catch (Exception ex)
            {
                PostMessage(MessageTemplate.ErrorGuardar, ex);
            }
            return AdminTarea(HistoriaId, null);
        }

        [ViewParameter("Historia", "fa fa-header")]
        [PermisoHistoria("HistoriaId", PermisoLogic.TipoPermiso.Lectura)]
        [PermisoIteracion("IteracionId", PermisoLogic.TipoPermiso.Lectura)]
        public ActionResult DetailHistoria(Int32 HistoriaId, Int32 IteracionId)
        {
            var viewModel = new DetailHistoriaViewModel();
            viewModel.CargarDatos(CargarDatosContext(), HistoriaId, IteracionId);
            return View(viewModel);
        }

        [ViewParameter("Historia", "fa fa-header")]
        [PermisoHistoriaIteracion("HistoriaIteracionId", PermisoLogic.TipoPermiso.Escritura)]
        public ActionResult AssignHistoria(Int32 HistoriaIteracionId)
        {
            var viewModel = new AssignHistoriaViewModel();
            viewModel.CargarDatos(CargarDatosContext(), HistoriaIteracionId);
            viewModel.UrlReferrer = Request.UrlReferrer.AbsoluteUri;
            return View("_AssignHistoria", viewModel);
        }

        [HttpPost]
        [ViewParameter("Historia", "fa fa-header")]
        [PermisoHistoriaIteracion("HistoriaIteracionId", PermisoLogic.TipoPermiso.Escritura)]
        public ActionResult AssignHistoria(AssignHistoriaViewModel model)
        {
            try
            {
                using (var TransactionScope = new TransactionScope())
                {
                    if (!ModelState.IsValid)
                    {
                        model.CargarDatos(CargarDatosContext(), model.HistoriaIteracionId);
                        TryUpdateModel(model);
                        PostMessage(MessageTemplate.DatosIncorrectos);
                        return View(model);
                    }

                    var historiaIteracion = context.HistoriaIteracion.Find(model.HistoriaIteracionId);
                    var historia = context.Historia.Find(model.HistoriaId);
                    var usuarioProyectoAsignado = context.UsuarioProyecto.Include(x => x.Usuario).First(x => x.ProyectoId == historia.ProyectoId && x.UsuarioId == model.UsuarioAsignadoId);

                    var avanceHistoria = new AvanceHistoria();
                    avanceHistoria.HistoriaId = historiaIteracion.HistoriaId;
                    avanceHistoria.MinutosEfectivos = 0;
                    avanceHistoria.FechaRegistro = DateTime.Now;
                    avanceHistoria.UsuarioRegistroId = Session.GetUsuarioId();
                    avanceHistoria.Estado = historia.Estado;
                    avanceHistoria.Comentario = "Historia asignada a: " + usuarioProyectoAsignado.Usuario.Apellido + ", " + usuarioProyectoAsignado.Usuario.Nombre + " (" + ConstantHelpers.RolProyecto.Nombre(usuarioProyectoAsignado.Rol) + ")";
                    context.AvanceHistoria.Add(avanceHistoria);

                    historiaIteracion.UsuarioAsignadoId = usuarioProyectoAsignado.UsuarioId;
                    context.SaveChanges();

                    TransactionScope.Complete();

                    PostMessage(MessageTemplate.ExitoGuardar);
                    return Redirect(model.UrlReferrer);
                }
            }
            catch (Exception ex)
            {
                InvalidarContext();
                PostMessage(MessageTemplate.ErrorGuardar, ex);
                model.CargarDatos(CargarDatosContext(), model.HistoriaIteracionId);
                TryUpdateModel(model);
            }

            return Redirect(model.UrlReferrer);
        }

        [ViewParameter("Historia", "fa fa-header")]
        [PermisoHistoriaIteracionAsignado("HistoriaIteracionId", PermisoLogic.TipoPermiso.Escritura)]
        public ActionResult AddAvance(Int32 HistoriaIteracionId)
        {
            var viewModel = new AddAvanceViewModel();
            viewModel.CargarDatos(CargarDatosContext(), HistoriaIteracionId);
            return View("_AddAvance", viewModel);
        }

        [HttpPost]
        [ViewParameter("Historia", "fa fa-header")]
        [PermisoHistoriaIteracionAsignado("HistoriaIteracionId", PermisoLogic.TipoPermiso.Escritura)]
        public ActionResult AddAvance(AddAvanceViewModel model)
        {
            try
            {
                using (var TransactionScope = new TransactionScope())
                {
                    if (!ModelState.IsValid)
                    {
                        model.CargarDatos(CargarDatosContext(), model.HistoriaIteracionId);
                        TryUpdateModel(model);
                        PostMessage(MessageTemplate.DatosIncorrectos);
                    }

                    var historia = context.Historia.Find(model.HistoriaId);

                    var avanceHistoria = new AvanceHistoria();

                    avanceHistoria.HistoriaId = model.HistoriaId;
                    avanceHistoria.MinutosEfectivos = model.TiempoEfectivo.Value * (model.Medida == "H" ? 60 : 1);
                    avanceHistoria.FechaRegistro = DateTime.Now;
                    avanceHistoria.UsuarioRegistroId = Session.GetUsuarioId();
                    avanceHistoria.Estado = historia.Estado;
                    avanceHistoria.Comentario = model.Comentario;

                    context.AvanceHistoria.Add(avanceHistoria);
                    context.SaveChanges();

                    historia.HorasEfectivas = context.AvanceHistoria.Where(x => x.HistoriaId == model.HistoriaId).Sum(x => x.MinutosEfectivos) / 60;
                    context.SaveChanges();

                    TransactionScope.Complete();

                    PostMessage(MessageTemplate.ExitoGuardar);
                    return RedirectToAction("DetailHistoria", new { HistoriaId = model.HistoriaId, IteracionId = model.IteracionId });
                }
            }
            catch (Exception ex)
            {
                InvalidarContext();
                PostMessage(MessageTemplate.ErrorGuardar, ex);
                model.CargarDatos(CargarDatosContext(), model.HistoriaIteracionId);
                TryUpdateModel(model);
            }

            return RedirectToAction("DetailHistoria", new { HistoriaId = model.HistoriaId, IteracionId = model.IteracionId });
        }

        [ViewParameter("Historia", "fa fa-header")]
        [PermisoTarea("TareaId", PermisoLogic.TipoPermiso.Escritura)]
        public ActionResult SetTareaCompletada(Int32 TareaId, Boolean Completada)
        {
            var tarea = context.Tarea.Find(TareaId);

            if (tarea.Estado != ConstantHelpers.EstadoTarea.INACTIVO)
            {
                var historia = context.Historia.Find(tarea.HistoriaId);
                var avanceHistoria = new AvanceHistoria();
                avanceHistoria.HistoriaId = historia.HistoriaId;
                avanceHistoria.Estado = historia.Estado;
                avanceHistoria.FechaRegistro = DateTime.Now;
                avanceHistoria.MinutosEfectivos = 0;
                avanceHistoria.UsuarioRegistroId = Session.GetUsuarioId();
                context.AvanceHistoria.Add(avanceHistoria);

                if (Completada)
                {
                    tarea.Estado = ConstantHelpers.EstadoTarea.FINALIZADO;
                    tarea.UsuarioCompletadoId = Session.GetUsuarioId();
                    tarea.FechaCompletado = DateTime.Now;
                    avanceHistoria.Comentario = "Tarea marcada como finalizada: " + tarea.Nombre;
                }
                else
                {
                    tarea.Estado = ConstantHelpers.EstadoTarea.PENDIENTE;
                    tarea.UsuarioCompletadoId = null;
                    tarea.FechaCompletado = null;
                    avanceHistoria.Comentario = "Tarea marcada como pendiente: " + tarea.Nombre;
                }
                context.SaveChanges();
            }

            return Json(new { success = true });
        }

        [ViewParameter("Historia", "fa fa-header")]
        [PermisoHistoriaIteracionAsignado("HistoriaIteracionId", PermisoLogic.TipoPermiso.Escritura)]
        public ActionResult SetEstadoHistoriaIteracion(Int32 HistoriaIteracionId, String Estado)
        {
            var historiaIteracion = context.HistoriaIteracion.Find(HistoriaIteracionId);
            var historia = context.Historia.Find(historiaIteracion.HistoriaId);
            var cambioValido = false;

            if (historia.Estado == ConstantHelpers.EstadoHistoria.PENDIENTE)
            {
                if (Estado == ConstantHelpers.EstadoHistoria.EN_PROGRESO)
                    cambioValido = true;
            }
            else if (historia.Estado == ConstantHelpers.EstadoHistoria.EN_PROGRESO)
            {
                if (Estado == ConstantHelpers.EstadoHistoria.FINALIZADO)
                    cambioValido = true;
            }
            else if (historia.Estado == ConstantHelpers.EstadoHistoria.FINALIZADO)
            {
                if (Estado == ConstantHelpers.EstadoHistoria.APROBADO || Estado == ConstantHelpers.EstadoHistoria.PENDIENTE)
                    cambioValido = true;
            }

            if (cambioValido)
            {
                var avanceHistoria = new AvanceHistoria();
                avanceHistoria.HistoriaId = historia.HistoriaId;
                avanceHistoria.Estado = historia.Estado;
                avanceHistoria.FechaRegistro = DateTime.Now;
                avanceHistoria.MinutosEfectivos = 0;
                avanceHistoria.UsuarioRegistroId = Session.GetUsuarioId();
                avanceHistoria.Comentario = "Cambio de estado de la historia: de '" + ConstantHelpers.EstadoHistoria.Nombre(historia.Estado) + "' a '" + ConstantHelpers.EstadoHistoria.Nombre(Estado) + "'";
                context.AvanceHistoria.Add(avanceHistoria);

                historia.Estado = Estado;

                if (Estado == ConstantHelpers.EstadoHistoria.APROBADO)
                    historia.FechaCompletada = DateTime.Now;

                context.SaveChanges();
                return Json(new { success = true });
            }
            else
            {
                return Json(new { success = false, mensaje = "No se puede cambiar del estado '" + ConstantHelpers.EstadoHistoria.Nombre(historia.Estado) + "' al estado '" + ConstantHelpers.EstadoHistoria.Nombre(Estado) + "'" });
            }
        }
    }
}
