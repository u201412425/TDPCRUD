﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.Entity;
using BitPerfect.GPRO.Helpers;
using BitPerfect.GPRO.ViewModel.Chart;
using BitPerfect.GPRO.Filters;
using BitPerfect.GPRO.Logic;

namespace BitPerfect.GPRO.Controllers
{
    public class ChartController : BaseController
    {
        //
        // GET: /Chart/

        public ActionResult FeedBurndownChart(Int32 ProyectoId, Int32? IteracionId, Int32? HistoriaId, Boolean MostrarSoloAvanceEfectivo = false, Boolean MostrarDiaPorDia = true)
        {
            try
            {
                var proyecto = context.Proyecto.Find(ProyectoId);
                var tituloGrafico = proyecto.Codigo;

                var queryHistorias = context.Historia.Where(x => x.ProyectoId == ProyectoId).OrderBy(x => x.FechaCompletada).AsQueryable();
                var queryAvance = context.AvanceHistoria.Where(x => x.Historia.ProyectoId == ProyectoId).OrderBy(x => x.FechaRegistro).AsQueryable();

                if (MostrarSoloAvanceEfectivo)
                {
                    queryAvance = queryAvance.Where(x => x.MinutosEfectivos > 0);
                }

                if (IteracionId.HasValue)
                {
                    var iteracion = context.Iteracion.Find(IteracionId);
                    tituloGrafico += "<br>" + iteracion.Codigo + " | " + iteracion.Nombre;
                    queryHistorias = queryHistorias.Where(x => x.HistoriaIteracion.Any(h => h.IteracionId == IteracionId));
                    queryAvance = queryAvance.Where(x => x.Historia.HistoriaIteracion.Any(h => h.IteracionId == IteracionId));
                }

                if (HistoriaId.HasValue)
                {
                    var historia = context.Historia.Find(HistoriaId);
                    tituloGrafico += "<br>" + historia.Codigo + " | " + historia.Nombre;
                    queryHistorias = queryHistorias.Where(x => x.HistoriaId == HistoriaId);
                    queryAvance = queryAvance.Where(x => x.Historia.HistoriaId == HistoriaId);
                }


                var lstHistorias = queryHistorias.ToList();
                var lstAvance = queryAvance.ToList();
                var lstHistoriasId = lstHistorias.Select(x => x.HistoriaId);

                var inicioGrafico = context.HistoriaIteracion.Where(x => lstHistoriasId.Contains(x.HistoriaId)).Min(x => x.Iteracion.FechaInicio).Date;
                var finGrafico = context.HistoriaIteracion.Where(x => lstHistoriasId.Contains(x.HistoriaId)).Max(x => x.Iteracion.FechaFin).Date;

                var lstIteraciones = context.Iteracion.Where(x => ((inicioGrafico <= x.FechaInicio && x.FechaInicio <= finGrafico) || (inicioGrafico <= x.FechaFin && x.FechaFin <= finGrafico)) && x.ProyectoId == ProyectoId).ToList();

                var dictMinAvanceHistoria = lstHistorias.ToDictionary(x => x.HistoriaId, x => 0);
                var dictHistoriaCompletada = lstHistorias.ToDictionary(x => x.HistoriaId, x => false);
                lstAvance.ForEach(x => dictMinAvanceHistoria[x.HistoriaId] += x.MinutosEfectivos);
                var minutosTotalHistoria = lstHistorias.Sum(x => x.HorasEstimadas) * 60;
                var minutosTotalAvance = 0;
                var minutosTotalEstimado = new Decimal(minutosTotalHistoria);

                foreach (var historia in lstHistorias)
                {
                    if (dictMinAvanceHistoria[historia.HistoriaId] > historia.HorasEstimadas * 60 || historia.FechaCompletada.HasValue)
                        minutosTotalAvance += dictMinAvanceHistoria[historia.HistoriaId];
                    else
                        minutosTotalAvance += historia.HorasEstimadas * 60;
                }

                var dataInicioHistoria = new
                {
                    name = "",
                    y = minutosTotalHistoria,
                    x = inicioGrafico.ToJsonDateTime()
                };

                var dataInicioAvance = new
                {
                    name = "",
                    y = minutosTotalAvance,
                    x = inicioGrafico.ToJsonDateTime()
                };

                var dataInicioEstimado = new
                {
                    name = "",
                    y = minutosTotalEstimado,
                    x = inicioGrafico.ToJsonDateTime()
                };

                var dataFinEstimado = new
                {
                    name = "",
                    y = Decimal.Zero,
                    x = finGrafico.ToJsonDateTime()
                };

                var serieHistoria = new[] { dataInicioHistoria }.ToList();
                var serieAvance = new[] { dataInicioAvance }.ToList();
                var serieEstimado = new[] { dataInicioEstimado }.ToList();
                var ultimoDiaAvance = inicioGrafico.AddDays(1);
                var ultimoDiaHistoria = inicioGrafico.AddDays(1);
                var ultimoDiaEstimado = inicioGrafico.AddDays(1);

                foreach (var avance in lstAvance)
                {
                    if (MostrarDiaPorDia)
                    {
                        while (ultimoDiaAvance < avance.FechaRegistro.Date)
                        {
                            var dataDiaVacio = new
                            {
                                name = "",
                                y = minutosTotalAvance,
                                x = ultimoDiaAvance.ToJsonDateTime()
                            };

                            serieAvance.Add(dataDiaVacio);
                            ultimoDiaAvance = ultimoDiaAvance.AddDays(1);
                        }
                    }

                    minutosTotalAvance -= avance.MinutosEfectivos;
                    var data = new
                    {
                        name = avance.Comentario,
                        y = minutosTotalAvance,
                        x = avance.FechaRegistro.ToJsonDateTime()
                    };
                    ultimoDiaAvance = avance.FechaRegistro.Date.AddDays(1);
                    serieAvance.Add(data);
                }

                foreach (var historia in lstHistorias)
                {
                    if (!historia.FechaCompletada.HasValue)
                        continue;

                    if (MostrarDiaPorDia)
                    {
                        while (ultimoDiaHistoria.Date < historia.FechaCompletada.Value.Date)
                        {
                            var dataDiaVacio = new
                            {
                                name = "",
                                y = minutosTotalHistoria,
                                x = ultimoDiaHistoria.Date.ToJsonDateTime()
                            };

                            serieHistoria.Add(dataDiaVacio);
                            ultimoDiaHistoria = ultimoDiaHistoria.Date.AddDays(1);
                        }
                    }

                    minutosTotalHistoria -= historia.HorasEstimadas * 60;

                    var data = new
                    {
                        name = historia.Codigo + " | " + historia.Nombre,
                        y = minutosTotalHistoria,
                        x = historia.FechaCompletada.Value.ToJsonDateTime()
                    };
                    ultimoDiaHistoria = historia.FechaCompletada.Value;
                    serieHistoria.Add(data);
                }

                if (MostrarDiaPorDia)
                {
                    while (ultimoDiaAvance.Date < DateTime.Today)
                    {
                        var dataDiaVacio = new
                        {
                            name = "",
                            y = minutosTotalAvance,
                            x = ultimoDiaAvance.Date.ToJsonDateTime()
                        };

                        serieAvance.Add(dataDiaVacio);
                        ultimoDiaAvance = ultimoDiaAvance.Date.AddDays(1);
                    }
                }

                if (MostrarDiaPorDia)
                {
                    while (ultimoDiaHistoria.Date <= DateTime.Today)
                    {
                        var dataDiaVacio = new
                        {
                            name = "",
                            y = minutosTotalHistoria,
                            x = ultimoDiaHistoria.Date.ToJsonDateTime()
                        };

                        serieHistoria.Add(dataDiaVacio);
                        ultimoDiaHistoria = ultimoDiaHistoria.Date.AddDays(1);
                    }
                }

                var porcentajeAvanceEstimadoDiario = minutosTotalEstimado / new Decimal((finGrafico - inicioGrafico).TotalDays);

                if (MostrarDiaPorDia)
                {
                    while (ultimoDiaEstimado.Date <= DateTime.Today)
                    {
                        minutosTotalEstimado -= porcentajeAvanceEstimadoDiario;

                        var dataDiaVacio = new
                        {
                            name = "",
                            y = minutosTotalEstimado,
                            x = ultimoDiaEstimado.Date.ToJsonDateTime()
                        };

                        serieEstimado.Add(dataDiaVacio);
                        ultimoDiaEstimado = ultimoDiaEstimado.Date.AddDays(1);
                    }
                }

                serieEstimado.Add(dataFinEstimado);

                var datosCompletos = new
                {
                    GraficoInicio = inicioGrafico.ToJsonDateTime(),
                    GraficoFin = finGrafico.ToJsonDateTime(),
                    GraficoTitulo = tituloGrafico,
                    SerieHistoria = serieHistoria,
                    SerieAvance = serieAvance,
                    SerieEstimado = serieEstimado,
                    Iteraciones = lstIteraciones.Select(x => new { x.Codigo, x.Nombre, FechaInicio = x.FechaInicio.ToJsonDateTime(), FechaFin = x.FechaFin.ToJsonDateTime() }).ToList()
                };

                return Json(datosCompletos);
            }
            catch (Exception ex)
            {
                return Json(new { error = "Ha ocurrido un error al obtener los datos" });
            }
        }

        [ViewParameter("Burndown", "fa fa-area-chart")]
        public ActionResult Burndown(Int32? ProyectoId, Int32? IteracionId, Int32? HistoriaId)
        {
            var viewModel = new BurndownViewModel();
            viewModel.CargarDatos(CargarDatosContext(), ProyectoId, IteracionId, HistoriaId);
            return View(viewModel);
        }
    }
}
