﻿using BitPerfect.GPRO.Filters;
using BitPerfect.GPRO.Helpers;
using BitPerfect.GPRO.Logic;
using BitPerfect.GPRO.Models;
using BitPerfect.GPRO.ViewModel.Sprint;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Transactions;
using System.Web;
using System.Web.Mvc;

namespace BitPerfect.GPRO.Controllers
{
    public class SprintController : BaseController
    {
        [ViewParameter("HistoriaIteracion", "fa fa-list-ol")]
        public ActionResult ListHistoriaIteracion()
        {
            var ListHistoriaIteracionViewModel = new ListHistoriaIteracionViewModel();
            ListHistoriaIteracionViewModel.CargarDatos(CargarDatosContext());
            return View(ListHistoriaIteracionViewModel);
        }

        [ViewParameter("HistoriaIteracion", "fa fa-list-ol")]
        [PermisoIteracion("IteracionId", PermisoLogic.TipoPermiso.Escritura)]
        public ActionResult AdminHistoriaIteracion(Int32 IteracionId)
        {
            var AdminHistoriaIteracionViewModel = new AdminHistoriaIteracionViewModel();
            AdminHistoriaIteracionViewModel.CargarDatos(CargarDatosContext(), IteracionId);
            return View(AdminHistoriaIteracionViewModel);
        }

        [HttpPost]
        [ViewParameter("HistoriaIteracion", "fa fa-list-ol")]
        [PermisoIteracion("IteracionId", PermisoLogic.TipoPermiso.Escritura)]
        public ActionResult AdminHistoriaIteracion(AdminHistoriaIteracionViewModel model, FormCollection form)
        {
            try
            {
                using (var TransactionScope = new TransactionScope())
                {
                    if (!ModelState.IsValid)
                    {
                        model.CargarDatos(CargarDatosContext(), model.IteracionId);
                        TryUpdateModel(model);
                        PostMessage(MessageTemplate.DatosIncorrectos);
                        return View(model);
                    }

                    //Eliminamos todo lo anterior
                    context.HistoriaIteracion.RemoveRange(context.HistoriaIteracion.Where(x=>x.IteracionId == model.IteracionId));

                    foreach(var historiaSeleccionadaId in model.LstHistoriaSeleccionadaId)
                    {
                        var historiaIteracion = new HistoriaIteracion();
                        historiaIteracion.HistoriaId = historiaSeleccionadaId;
                        historiaIteracion.IteracionId = model.IteracionId;
                        historiaIteracion.UsuarioRegistroId = Session.GetUsuarioId();
                        historiaIteracion.FechaRegistro = DateTime.Now;
                        historiaIteracion.Estado = ConstantHelpers.Estado.ACTIVO;
                        
                        var formValue = form["USU-ASI-" + historiaSeleccionadaId];

                        if(formValue != null && formValue.ToInteger(0) != 0)
                            historiaIteracion.UsuarioAsignadoId = formValue.ToInteger();
                        
                        context.HistoriaIteracion.Add(historiaIteracion);
                    }
                    context.SaveChanges();

                    TransactionScope.Complete();

                    PostMessage(MessageTemplate.ExitoGuardar);
                    return RedirectToAction("ListHistoriaIteracion");
                }
            }
            catch (Exception ex)
            {
                InvalidarContext();
                PostMessage(MessageTemplate.ErrorGuardar, ex);
                model.CargarDatos(CargarDatosContext(), model.IteracionId);
                TryUpdateModel(model);
                return View(model);
            }
        }

        [ViewParameter("HistoriaIteracion", "fa fa-list-ol")]
        [PermisoIteracion("IteracionId", PermisoLogic.TipoPermiso.Escritura)]
        public ActionResult FinishDisenoHistoriaIteracion(Int32 IteracionId)
        {
            var iteracion = context.Iteracion.Find(IteracionId);

            if (iteracion.Estado != ConstantHelpers.EstadoIteracion.DISENO)
                PostMessage(MessageType.Info, "La iteración debe estar en fase de diseño para solicitar la aprobación.");
            return View("_FinishDisenoHistoriaIteracion", iteracion);
        }

        [HttpPost]
        [ViewParameter("HistoriaIteracion", "fa fa-list-ol")]
        [PermisoIteracion("IteracionId", PermisoLogic.TipoPermiso.Escritura)]
        public ActionResult FinishDisenoHistoriaIteracion(Int32 IteracionId, Boolean? isPost)
        {
            var iteracion = context.Iteracion.Find(IteracionId);

            if (iteracion.Estado != ConstantHelpers.EstadoIteracion.DISENO)
            {
                PostMessage(MessageType.Info, "La iteración debe estar en fase de diseño para solicitar la aprobación.");
            }
            else
            {
                iteracion.Estado = ConstantHelpers.EstadoIteracion.PENDIENTE_APROBACION;
                context.SaveChanges();
                PostMessage(MessageTemplate.ExitoGuardar);
            }

            return RedirectToAction("ListHistoriaIteracion", "Sprint");
        }

        [ViewParameter("Iteracion", "fa fa-recycle")]
        public ActionResult ListIteracion()
        {
            var ListIteracionViewModel = new ListIteracionViewModel();
            ListIteracionViewModel.CargarDatos(CargarDatosContext());
            return View(ListIteracionViewModel);
        }

        [ViewParameter("Iteracion", "fa fa-recycle")]
        public ActionResult EditIteracion(Int32? IteracionId)
        {
            var EditIteracionViewModel = new EditIteracionViewModel();
            EditIteracionViewModel.CargarDatos(CargarDatosContext(), IteracionId);
            return View(EditIteracionViewModel);
        }

        [HttpPost]
        [ViewParameter("Iteracion", "fa fa-recycle")]
        public ActionResult EditIteracion(EditIteracionViewModel model)
        {
            try
            {
                using (var TransactionScope = new TransactionScope())
                {
                    if (!ModelState.IsValid)
                    {
                        model.CargarDatos(CargarDatosContext(), model.IteracionId);
                        TryUpdateModel(model);
                        PostMessage(MessageTemplate.DatosIncorrectos);
                        return View(model);
                    }

                    var Iteracion = new Iteracion();

                    if (model.IteracionId.HasValue)
                    {
                        Iteracion = context.Iteracion.First(x => x.IteracionId == model.IteracionId);
                    }
                    else
                    {
                        Iteracion.Estado = ConstantHelpers.EstadoIteracion.DISENO;
                        Iteracion.FechaRegistro = DateTime.Now;
                        Iteracion.ProyectoId = Session.GetProyectoId();
                        Iteracion.UsuarioRegistroId = Session.GetUsuarioId();
                        context.Iteracion.Add(Iteracion);
                    }

                    Iteracion.Codigo = model.Codigo;
                    Iteracion.Nombre = model.Nombre;
                    Iteracion.FechaFin = model.FechaFin;
                    Iteracion.FechaInicio = model.FechaInicio;

                    context.SaveChanges();

                    TransactionScope.Complete();

                    PostMessage(MessageTemplate.ExitoGuardar);
                    return RedirectToAction("ListIteracion");
                }
            }
            catch (Exception ex)
            {
                InvalidarContext();
                PostMessage(MessageTemplate.ErrorGuardar, ex);
                model.CargarDatos(CargarDatosContext(), model.IteracionId);
                TryUpdateModel(model);
                return View(model);
            }
        }

    }
}
