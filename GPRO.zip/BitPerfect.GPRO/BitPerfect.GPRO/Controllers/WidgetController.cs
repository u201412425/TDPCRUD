﻿using BitPerfect.GPRO.Helpers;
using BitPerfect.GPRO.Models;
using BitPerfect.GPRO.ViewModel.Widget;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.Entity;
using System.IO;
using System.Transactions;

namespace BitPerfect.GPRO.Controllers
{
    public class WidgetController : BaseController
    {
        //
        // GET: /Widget/

        public ActionResult ListMensaje(String Objeto, Int32 ObjetoId, Int32? Page)
        {
            var viewModel = new ListMensajeViewModel();
            viewModel.CargarDatos(CargarDatosContext(), Objeto, ObjetoId, Page);
            return PartialView(viewModel);
        }

        public ActionResult PostMensaje(String Objeto, Int32 ObjetoId, String Texto)
        {
            if (String.IsNullOrEmpty(Texto))
                return Content("");
            
            var mensaje = new Mensaje();
            mensaje.Objeto = Objeto;
            mensaje.ObjetoId = ObjetoId;
            mensaje.Texto = Texto;
            mensaje.UsuarioRegistroId = Session.GetUsuarioId();
            mensaje.FechaRegistro = DateTime.Now;
            mensaje.Estado = ConstantHelpers.Estado.ACTIVO;
            context.Mensaje.Add(mensaje);
            context.SaveChanges();
            var nuevoMensajeId = mensaje.MensajeId;
            var nuevoMensaje = context.Mensaje.Include(x => x.Usuario).First(x => x.MensajeId == nuevoMensajeId);

            return PartialView("_RenderMensaje", nuevoMensaje);
        }

        public ActionResult ListArchivo(String Objeto, Int32 ObjetoId, Int32? Page)
        {
            var viewModel = new ListArchivoViewModel();
            viewModel.CargarDatos(CargarDatosContext(), Objeto, ObjetoId, Page);
            return PartialView(viewModel);
        }
        /*
        public ActionResult AgregarArchivo(Int32? RecursoPadreId, Int32? RecursoId)
        {
            AgregarArchivoViewModel model = new AgregarArchivoViewModel();
            model.Fill(CargarDatosContext(), Session.GetUsuarioId(), RecursoPadreId, RecursoId);
            return View("_AgregarArchivo", model);
        }

        [HttpPost]
        [ValidateInput(false)]
        public ActionResult AgregarArchivo(AgregarArchivoViewModel model)
        {
            if (!ModelState.IsValid)
            {
                PostMessage(MessageTemplate.DatosIncorrectos);
                return RedirectToAction("Repositorio", "File", new { RecursoId = model.RecursoPadreId });
            }
            using (TransactionScope _transaction = new TransactionScope())
            {
                try
                {
                    Int32 proyectoId = Session.GetProyectoId();
                    Models.Recurso recurso = null;
                    Models.Recurso recursoPadre = context.Recurso.Find(model.RecursoPadreId);


                    if (model.RecursoId.HasValue)
                    {
                        recurso = context.Recurso.Find(model.RecursoId);
                    }
                    else
                    {
                        recurso = new Models.Recurso();
                        recurso.UsuarioRegistroId = model.UsuarioId;
                        recurso.RecursoPadreId = model.RecursoPadreId;
                        recurso.ProyectoId = proyectoId;
                        context.Recurso.Add(recurso);
                    }

                    recurso.Nombre = model.Nombre;
                    recurso.Tipo = ConstantHelpers.TipoRepositorio.ARCHIVO;
                    recurso.FechaRegistro = DateTime.UtcNow;
                    recurso.Estado = ConstantHelpers.Estado.ACTIVO;

                    if (model.ArchivoNuevo != null)
                    {
                        var nombreArchivo = Path.GetFileNameWithoutExtension(model.ArchivoNuevo.FileName);

                        foreach (char c in System.IO.Path.GetInvalidFileNameChars())
                            nombreArchivo = nombreArchivo.Replace(c, '-');

                        nombreArchivo = nombreArchivo + "-" + Guid.NewGuid().ToString().Replace("-", "").Substring(0, 8) + Path.GetExtension(model.ArchivoNuevo.FileName);

                        while (nombreArchivo.IndexOf("--") > 0)
                            nombreArchivo = nombreArchivo.Replace("--", "-");

                        var rutaArchivo = System.IO.Path.Combine(Server.MapPath("~/Files/"), nombreArchivo);
                        model.ArchivoNuevo.SaveAs(rutaArchivo);

                        recurso.Ruta = nombreArchivo;
                        recurso.Extension = System.IO.Path.GetExtension(model.ArchivoNuevo.FileName).ToLower();

                        if (model.ArchivoNuevo.ContentLength > 1024 * 1024 * 1024)
                            recurso.Tamano = (model.ArchivoNuevo.ContentLength / (1024 * 1024 * 1024)).ToString() + " GB";
                        else if (model.ArchivoNuevo.ContentLength > 1024 * 1024)
                            recurso.Tamano = (model.ArchivoNuevo.ContentLength / (1024 * 1024)).ToString() + " MB";
                        else if (model.ArchivoNuevo.ContentLength > 1024)
                            recurso.Tamano = (model.ArchivoNuevo.ContentLength / (1024)).ToString() + " KB";
                        else
                            recurso.Tamano = "1 KB";
                    }

                    context.SaveChanges();
                    _transaction.Complete();
                    PostMessage(MessageTemplate.ExitoGuardar);
                    return Redirect(Request.UrlReferrer.ToString());
                }
                catch (Exception ex)
                {
                    PostMessage(MessageTemplate.ErrorGuardar);
                    return Redirect(Request.UrlReferrer.ToString());
                }
            }
        }
        */
        public ActionResult PostArchivo(String Objeto, Int32 ObjetoId, String Nombre, HttpPostedFileBase Archivo)
        {
            var archivo = new Archivo();

            archivo.Objeto = Objeto;
            archivo.ObjetoId = ObjetoId;
            archivo.Ruta = "";
            archivo.Nombre = Nombre;
            archivo.Peso = Archivo.ContentLength + " bytes";
            archivo.Extension = System.IO.Path.GetExtension(Archivo.FileName);
            archivo.UsuarioRegistroId = Session.GetUsuarioId();
            archivo.FechaRegistro = DateTime.Now;
            archivo.Estado = ConstantHelpers.Estado.ACTIVO;
            context.Archivo.Add(archivo);
            context.SaveChanges();
            var nuevoArchivoId = archivo.ArchivoId;
            var nuevoArchivo = context.Archivo.Include(x => x.Usuario).First(x => x.ArchivoId == nuevoArchivoId);

            return PartialView("_RenderArchivo", nuevoArchivo);
        }

        public ActionResult BurndownChart(Int32 proyectoId, Int32? iteracionId, Int32? historiaId)
        {
            var viewModel = new BurndownChartViewModel();
            viewModel.CargarDatos(CargarDatosContext(),proyectoId, iteracionId, historiaId);
            return PartialView(viewModel);
        }
    }
}
