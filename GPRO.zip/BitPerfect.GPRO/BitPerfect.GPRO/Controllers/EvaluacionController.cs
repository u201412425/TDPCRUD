﻿using BitPerfect.GPRO.Filters;
using BitPerfect.GPRO.Helpers;
using BitPerfect.GPRO.Models;
using BitPerfect.GPRO.ViewModel.Evaluacion;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Transactions;
using System.Web;
using System.Web.Mvc;

namespace BitPerfect.GPRO.Controllers
{
    public class EvaluacionController : BaseController
    {
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult LstEvaluacion()
        {
            ListEvaluacionViewModel ListEvaluacionViewModel = new ListEvaluacionViewModel();
            ListEvaluacionViewModel.CargarDatos(CargarDatosContext(), Session.GetUsuarioId());
            return View(ListEvaluacionViewModel);
        }
        public ActionResult EditEvaluacion(Int32 EvaluacionProyectoId,Int32 FechaPlanEvaluacionId,Int32 CuestionarioId,Int32? EvaluacionId,bool? Revisar)
        {
            EditEvaluacionViewModel EditEvaluacionViewModel = new EditEvaluacionViewModel();
            EditEvaluacionViewModel.CargarDatos(CargarDatosContext(), Session.GetUsuarioId(), EvaluacionProyectoId, FechaPlanEvaluacionId, CuestionarioId, EvaluacionId);
            if (Revisar.HasValue && Revisar.Value)
            {
                ViewBag.Revisar = "Revisar";
            }
            return View(EditEvaluacionViewModel);
        }
        [HttpPost]
        public ActionResult EditEvaluacion(EditEvaluacionViewModel model, FormCollection form)
        {
            try
            {
                using (var TransactionScope = new TransactionScope())
                {
                    if (!ModelState.IsValid)
                    {
                        model.CargarDatos(CargarDatosContext(), Session.GetUsuarioId(), model.EvaluacionProyectoId, model.FechaPlanEvaluacionId, model.CuestionarioId,model.EvaluacionId);
                        TryUpdateModel(model);
                        PostMessage(MessageTemplate.DatosIncorrectos);
                        return View(model);
                    }

                    Evaluacion evaluacion = new Evaluacion();
                    evaluacion.EvaluacionProyectoId = model.EvaluacionProyectoId;
                    evaluacion.FechaPlanEvaluacionId = model.FechaPlanEvaluacionId;
                    evaluacion.Aprueba = model.Aprueba;
                    evaluacion.FechaRespuesta = DateTime.Now;
                    evaluacion.UsuarioId = Session.GetUsuarioId();
                    model.CargarDatos(CargarDatosContext(), Session.GetUsuarioId(), evaluacion.EvaluacionProyectoId, evaluacion.FechaPlanEvaluacionId, model.CuestionarioId, null);

                    foreach (var pregunta in model.ListaPregunta)
                    {
                        var evaluacionRespuesta = new EvaluacionRespuesta();
                        evaluacionRespuesta.PreguntaCuestionarioId = pregunta.PreguntaCuestionarioId;
                        
                        var respuestasOpcionesI = Request.Form[$"PR-{pregunta.PreguntaCuestionarioId}"];
                        if (!String.IsNullOrEmpty(respuestasOpcionesI))
                        {
                            string[] respuestasOpciones = respuestasOpcionesI.Split(new char[] { ',' });
                            foreach (var respuesta in respuestasOpciones)
                            {
                                    var evaluacionOpcion = new EvaluacionOpcion();
                                    evaluacionOpcion.OpcionCuestionarioId = respuesta.ToInteger();
                                    evaluacionRespuesta.EvaluacionOpcion.Add(evaluacionOpcion);
                            }
                        }

                        if (Request.Params[$"TXT-{pregunta.PreguntaCuestionarioId}"] != null)
                        {
                            evaluacionRespuesta.RespuestaCampoLibre = Request.Params[$"TXT-{pregunta.PreguntaCuestionarioId}"];
                        }

                        evaluacion.EvaluacionRespuesta.Add(evaluacionRespuesta);
                    }
                    context.Evaluacion.Add(evaluacion);
                    context.SaveChanges();

                    TransactionScope.Complete();

                    PostMessage(MessageTemplate.ExitoGuardar);
                    return RedirectToAction("LstEvaluacion");
                }
            }
            catch (Exception ex)
            {
                InvalidarContext();
                PostMessage(MessageTemplate.ErrorGuardar, ex);
                model.CargarDatos(CargarDatosContext(), Session.GetUsuarioId(), model.EvaluacionProyectoId, model.FechaPlanEvaluacionId, model.CuestionarioId, model.EvaluacionId);
                TryUpdateModel(model);
                return View(model);
            }
        }

    }
}
