﻿using BitPerfect.GPRO.Filters;
using BitPerfect.GPRO.Helpers;
using BitPerfect.GPRO.Models;
using BitPerfect.GPRO.ViewModel.EvaluacionProyecto;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Transactions;
using System.Web;
using System.Web.Mvc;
namespace BitPerfect.GPRO.Controllers
{
    [AppAuthorize(AppRol.Administrador)]
    public class EvaluacionProyectoController : BaseController
    {
        //
        // GET: /PlanProyecto/

        public ActionResult Index()
        {
            return View();
        }
        public ActionResult ListEvaluacionProyecto()
        {
            var ListEvaluacionProyectoViewModel = new ListEvaluacionProyectoViewModel();
            ListEvaluacionProyectoViewModel.CargarDatos(CargarDatosContext());
            return View(ListEvaluacionProyectoViewModel);
        }
        public ActionResult ExploreEvaluacionProyecto(Int32? EvaluacionProyectoId)
        {
            var EditEvaluacionProyectoViewModel = new EditEvaluacionProyectoViewModel();
            EditEvaluacionProyectoViewModel.CargarDatos(CargarDatosContext(), EvaluacionProyectoId);
            return View(EditEvaluacionProyectoViewModel);
        }
        public ActionResult EditEvaluacionProyecto(Int32? EvaluacionProyectoId)
        {
            var EditEvaluacionProyectoViewModel = new EditEvaluacionProyectoViewModel();
            EditEvaluacionProyectoViewModel.CargarDatos(CargarDatosContext(), EvaluacionProyectoId);
            return View(EditEvaluacionProyectoViewModel);
        }
        [HttpPost]
        public ActionResult EditEvaluacionProyecto(EditEvaluacionProyectoViewModel model)
        {
            try
            {
                using (var TransactionScope = new TransactionScope())
                {
                    if (!ModelState.IsValid)
                    {
                        model.CargarDatos(CargarDatosContext(), model.EvaluacionProyectoId);
                        TryUpdateModel(model);
                        PostMessage(MessageTemplate.DatosIncorrectos);
                        return View(model);
                    }

                    var EvaluacionProyecto = new EvaluacionProyecto();

                    if (model.EvaluacionProyectoId.HasValue)
                    {
                        EvaluacionProyecto = context.EvaluacionProyecto.First(x => x.EvaluacionProyectoId == model.EvaluacionProyectoId);
                    }
                    else
                    {
                        EvaluacionProyecto.FechaRegistro = DateTime.Now;
                        EvaluacionProyecto.UsuarioRegistroId = Session.GetUsuarioId();
                        context.EvaluacionProyecto.Add(EvaluacionProyecto);
                    }

                    EvaluacionProyecto.CuestionarioId = model.CuestionarioId;
                    EvaluacionProyecto.PlanEvaluacionId= model.PlanEvaluacionId;
                    EvaluacionProyecto.UsuarioAsignadoId = model.UsuarioAsignadoId;
                    EvaluacionProyecto.ProyectoId = model.ProyectoId;
                    EvaluacionProyecto.RolEvaluacionId = model.RolEvaluacionId;
                    EvaluacionProyecto.Estado = model.Estado;

                    context.SaveChanges();

                    TransactionScope.Complete();

                    PostMessage(MessageTemplate.ExitoGuardar);
                    return RedirectToAction("ListEvaluacionProyecto");
                }
            }
            catch (Exception ex)
            {
                InvalidarContext();
                PostMessage(MessageTemplate.ErrorGuardar, ex);
                model.CargarDatos(CargarDatosContext(), model.EvaluacionProyectoId);
                TryUpdateModel(model);
                return View(model);
            }
        }
    }
}
