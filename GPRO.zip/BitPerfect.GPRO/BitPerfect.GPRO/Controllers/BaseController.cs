using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BitPerfect.GPRO.Models;
using BitPerfect.GPRO.Helpers;

namespace BitPerfect.GPRO.Controllers
{
    public class BaseController : Controller
    {
        public GProEntities context;
        private CargarDatosContext cargarDatosContext;

        public BaseController()
        {
            context = new GProEntities();
            context.Configuration.ProxyCreationEnabled = false;
        }

        public void InvalidarContext()
        {
            context = new GProEntities();
        }

        public CargarDatosContext CargarDatosContext()
        {
            if (cargarDatosContext == null)
            {
                cargarDatosContext = new CargarDatosContext { context = context, session = Session };
            }

            return cargarDatosContext;
        }

        public void PostMessage(FlashMessage Message)
        {
            if (TempData["FlashMessages"] == null)
                TempData["FlashMessages"] = new List<FlashMessage>();

            ((List<FlashMessage>)TempData["FlashMessages"]).Add(Message);
        }

        public void PostMessage(MessageTemplate template, Exception exception = null)
        {
            String body = "";
            MessageType type = MessageType.Info;

            switch (template)
            {
                case MessageTemplate.DatosIncorrectos: type = MessageType.Error; body = i18n.ValidationStrings.DatosIncorrectos; break;
                case MessageTemplate.ExitoGuardar: type = MessageType.Success; body = "Los datos han sido guardados exitosamente."; break;
                case MessageTemplate.ErrorGuardar: type = MessageType.Error; body = "Ha ocurrido un error al procesar la solicitud. " + (exception != null ? exception.Message : ""); break;
            }
            PostMessage(type, body);
        }

        public void PostMessage(MessageType Type, String Title, String Body)
        {
            PostMessage(new FlashMessage { Title = Title, Body = Body, Type = Type });
        }

        public void PostMessage(MessageType Type, String Body)
        {
            String Title = "";

            switch (Type)
            {
                case MessageType.Error: Title = "¡Error!"; break;
                case MessageType.Info: Title = "Ojo."; break;
                case MessageType.Success: Title = "¡Éxito!"; break;
                case MessageType.Warning: Title = "¡Atención!"; break;
            }

            PostMessage(new FlashMessage { Title = Title, Body = Body, Type = Type });
        }

        public ActionResult Error(Exception ex)
        {
            return View("Error", ex);
        }

        public ActionResult RedirectToActionPartialView(String actionName)
        {
            return RedirectToActionPartialView(actionName, null, null);
        }

        public ActionResult RedirectToActionPartialView(String actionName, object routeValues)
        {
            return RedirectToActionPartialView(actionName, null, routeValues);
        }

        public ActionResult RedirectToActionPartialView(String actionName, String controllerName)
        {
            return RedirectToActionPartialView(actionName, controllerName, null);
        }

        public ActionResult RedirectToActionPartialView(String actionName, String controllerName, object routeValues)
        {
            var url = Url.Action(actionName, controllerName, routeValues);
            return Content("<script> window.location = '" + url + "'</script>");
        }
    }

    public class CargarDatosContext
    {
        public GProEntities context { get; set; }
        public HttpSessionStateBase session { get; set; }
    }
}
