using BitPerfect.GPRO.Helpers;
using BitPerfect.GPRO.Filters;
using BitPerfect.GPRO.ViewModel.File;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BitPerfect.GPRO.Logic;
using System.Configuration;
using System.Transactions;
using BitPerfect.GPRO.Controllers;

namespace BitPerfect.GPRO.Controllers
{
    
    public class FileController : BaseController
    {
        [ViewParameter("Repositorio", "fa fa-file")]
        public ActionResult ComponenteRepositorio()
        {
            return View("_ComponenteRepositorio");
        }
        
        [ViewParameter("Repositorio", "fa fa-file")]
        public ActionResult ComponenteRepositorioDetalle(Int32? RecursoId)
        {
            RepositorioViewModel model = new RepositorioViewModel();
            model.Fill(CargarDatosContext(), RecursoId);
            return PartialView("_ComponenteRepositorioDetalle", model);
        }
        
        [ViewParameter("Repositorio", "fa fa-file")]
        public ActionResult Repositorio(Int32? RecursoId)
        {
            RepositorioViewModel model = new RepositorioViewModel();
            model.Fill(CargarDatosContext(), RecursoId);
            return View(model);
        }
        
        [ViewParameter("Repositorio", "fa fa-file")]
        public ActionResult AgregarArchivo(Int32? RecursoPadreId, Int32? RecursoId)
        {
            AgregarArchivoViewModel model = new AgregarArchivoViewModel();
            model.Fill(CargarDatosContext(), Session.GetUsuarioId(), RecursoPadreId, RecursoId);
            return View("_AgregarArchivo", model);
        }
        
        [HttpPost]
        [ValidateInput(false)]
        [ViewParameter("Repositorio", "fa fa-file")]
        public ActionResult AgregarArchivo(AgregarArchivoViewModel model)
        {
            if (!ModelState.IsValid)
            {
                PostMessage(MessageTemplate.DatosIncorrectos);
                return RedirectToAction("Repositorio", "File", new { RecursoId = model.RecursoPadreId });
            }
            using (TransactionScope _transaction = new TransactionScope())
            {
                try
                {
                    Int32 proyectoId = Session.GetProyectoId();
                    Models.Recurso recurso = null;
                    Models.Recurso recursoPadre = context.Recurso.Find(model.RecursoPadreId);


                    if (model.RecursoId.HasValue)
                    {
                        recurso = context.Recurso.Find(model.RecursoId);
                    }
                    else
                    {
                        recurso = new Models.Recurso();
                        recurso.UsuarioRegistroId = model.UsuarioId;
                        recurso.RecursoPadreId = model.RecursoPadreId;
                        recurso.ProyectoId = proyectoId;
                        context.Recurso.Add(recurso);
                    }

                    recurso.Nombre = model.Nombre;
                    recurso.Tipo = ConstantHelpers.TipoRepositorio.ARCHIVO;
                    recurso.FechaRegistro = DateTime.UtcNow;
                    recurso.Estado = ConstantHelpers.Estado.ACTIVO;

                    if (model.ArchivoNuevo != null)
                    {
                        var nombreArchivo = Path.GetFileNameWithoutExtension(model.ArchivoNuevo.FileName);
                        
                        foreach (char c in System.IO.Path.GetInvalidFileNameChars())
                            nombreArchivo = nombreArchivo.Replace(c, '-');

                        nombreArchivo = nombreArchivo + "-" + Guid.NewGuid().ToString().Replace("-", "").Substring(0, 8) + Path.GetExtension(model.ArchivoNuevo.FileName);
                        
                        while (nombreArchivo.IndexOf("--") > 0)
                            nombreArchivo = nombreArchivo.Replace("--", "-");

                        var rutaArchivo = System.IO.Path.Combine(Server.MapPath("~/Files/"), nombreArchivo);
                        model.ArchivoNuevo.SaveAs(rutaArchivo);

                        recurso.Ruta = nombreArchivo;
                        recurso.Extension = System.IO.Path.GetExtension(model.ArchivoNuevo.FileName).ToLower();

                        if (model.ArchivoNuevo.ContentLength > 1024 * 1024 * 1024)
                            recurso.Tamano = (model.ArchivoNuevo.ContentLength / (1024 * 1024 * 1024)).ToString() + " GB";
                        else if (model.ArchivoNuevo.ContentLength > 1024 * 1024)
                            recurso.Tamano = (model.ArchivoNuevo.ContentLength / (1024 * 1024)).ToString() + " MB";
                        else if (model.ArchivoNuevo.ContentLength > 1024)
                            recurso.Tamano = (model.ArchivoNuevo.ContentLength / (1024)).ToString() + " KB";
                        else
                            recurso.Tamano = "1 KB";
                    }

                    context.SaveChanges();
                    _transaction.Complete();
                    PostMessage(MessageTemplate.ExitoGuardar);
                    return RedirectToAction("Repositorio", "File", new { RecursoId = model.RecursoPadreId });
                }
                catch (Exception ex)
                {
                    PostMessage(MessageTemplate.ErrorGuardar);
                    return RedirectToAction("Repositorio", "File", new { RecursoId = model.RecursoPadreId });
                }
            }
        }
        
        [ViewParameter("Repositorio", "fa fa-file")]
        public ActionResult AgregarFolder(Int32? RecursoPadreId, Int32? RecursoId)
        {
            AgregarFolderViewModel model = new AgregarFolderViewModel();
            model.Fill(CargarDatosContext(), Session.GetUsuarioId(), RecursoPadreId, RecursoId);
            return View("_AgregarFolder", model);
        }

        [HttpPost]
        [ValidateInput(false)]
        [ViewParameter("Repositorio", "fa fa-file")]
        public ActionResult AgregarFolder(AgregarFolderViewModel model)
        {
            if (!ModelState.IsValid)
            {
                PostMessage(MessageTemplate.DatosIncorrectos);
                return RedirectToAction("Repositorio", "File", new { RecursoId = model.RecursoPadreId });
            }
            try
            {
                Int32 proyectoId = Session.GetProyectoId();
                Models.Recurso recurso = null;
                Models.Recurso recursoPadre = context.Recurso.Find(model.RecursoPadreId);

                if (model.RecursoId.HasValue)
                {
                    recurso = context.Recurso.Find(model.RecursoId);
                }
                else
                {
                    recurso = new Models.Recurso();
                    recurso.UsuarioRegistroId = model.UsuarioId;
                    recurso.RecursoPadreId = model.RecursoPadreId;
                    recurso.ProyectoId = proyectoId;

                    context.Recurso.Add(recurso);
                }

                recurso.Nombre = model.Nombre;
                recurso.Tipo = ConstantHelpers.TipoRepositorio.FOLDER;
                recurso.FechaRegistro = DateTime.UtcNow;

                recurso.Estado = ConstantHelpers.Estado.ACTIVO;
                recurso.Extension = "";
                recurso.Tamano = "";

                var rutaVirtualFoder = (recursoPadre != null ? recursoPadre.Ruta : "") + "/" + model.Nombre;
                recurso.Ruta = rutaVirtualFoder;

                context.SaveChanges();

                PostMessage(MessageTemplate.ExitoGuardar);
                return RedirectToAction("Repositorio", "File", new { RecursoId = model.RecursoPadreId });
            }
            catch
            {
                PostMessage(MessageTemplate.ErrorGuardar);
                return RedirectToAction("Repositorio", "File", new { RecursoId = model.RecursoPadreId });
            }
        }

        //[PermisoRecurso("RecursoId",PermisoLogic.TipoPermiso.Lectura)]
/*        public ActionResult DescargarArchivo(Int32 RecursoId)
        {
            var Recurso = context.Recurso.Find(RecursoId);

            var nombreDescargaArchivo = Recurso.Nombre + Path.GetExtension(Recurso.Ruta);
            return File(new ArchivoAzureLogic().GetStreamRecurso(Recurso.Ruta, AzureContainer.RecursoPublic), "application/octet-stream", nombreDescargaArchivo);
        }*/

      
    }
}
