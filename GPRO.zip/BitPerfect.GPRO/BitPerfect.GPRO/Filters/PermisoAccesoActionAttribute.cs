using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using BitPerfect.GPRO.Helpers;
using System.Web.Mvc;
using System.Web.Routing;
using BitPerfect.GPRO.Logic;

namespace BitPerfect.GPRO.Filters
{

    public enum TipoLayoutPermiso
    {
        Modal,
        Vista,
        Auto
    }

    public class BaseActionFilterAttribute : ActionFilterAttribute
    {
        public List<String> _parametros { get; set; }
        public TipoLayoutPermiso _tipoLayoutPermiso { get; set; }
        public PermisoLogic.TipoPermiso _tipoPermiso { get; set; }

        public BaseActionFilterAttribute()
        {
            _parametros = new List<String>();
        }

        /// <summary>
        /// Obtiene el valor del par�metro. Busca en los par�metos de la Acci�n, si no encuenta, busca en los par�metros del Request.
        /// </summary>
        protected object GetValorParametro(ActionExecutingContext context, String parametro)
        {
            object valor;
            if (context.ActionParameters.TryGetValue(parametro, out valor))
                return valor;
            return context.HttpContext.Request.Params[parametro];
        }

        public virtual bool TieneAcceso(ActionExecutingContext context)
        {
            throw new NotImplementedException("Esta funci�n debe ser implementada en la clase heredada");
        }

        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            if (!TieneAcceso(filterContext))
            {
                var viewName = "";
                switch (_tipoLayoutPermiso)
                {
                    case TipoLayoutPermiso.Vista: viewName = "PermisoInsuficiente"; break;
                    case TipoLayoutPermiso.Modal: viewName = "_PermisoInsuficienteModal"; break;
                    case TipoLayoutPermiso.Auto: viewName = filterContext.HttpContext.Request.IsAjaxRequest() ? "_PermisoInsuficienteModal" : "PermisoInsuficiente"; break;
                }

                filterContext.Result = new ViewResult() { ViewName = viewName };
            }
        }
    }

    public class PermisoProyectoAttribute : BaseActionFilterAttribute
    {
        public PermisoProyectoAttribute() { }
        public PermisoProyectoAttribute(String parametroProyectoId, PermisoLogic.TipoPermiso tipoPermiso, TipoLayoutPermiso tipoLayoutPermiso = TipoLayoutPermiso.Auto)
        {
            _parametros.Add(parametroProyectoId);
            _tipoPermiso = tipoPermiso;
            _tipoLayoutPermiso = tipoLayoutPermiso;
        }

        public override bool TieneAcceso(ActionExecutingContext context)
        {
            try
            {
                var usuarioId = context.HttpContext.Session.GetUsuarioId();
                var proyectoId = GetValorParametro(context, _parametros[0]).ToInteger();

                var permisoLogic = new PermisoLogic();
                var permiso = permisoLogic.GetPermisoProyecto(usuarioId, proyectoId);

                return permisoLogic.TienePermisoSuficiente(permiso, _tipoPermiso);
            }
            catch (Exception ex)
            {
                return false;
            }
        }
    }

    public class PermisoHistoriaAttribute : BaseActionFilterAttribute
    {
        public PermisoHistoriaAttribute() { }
        public PermisoHistoriaAttribute(String parametroHistoriaId, PermisoLogic.TipoPermiso tipoPermiso, TipoLayoutPermiso tipoLayoutPermiso = TipoLayoutPermiso.Auto)
        {
            _parametros.Add(parametroHistoriaId);
            _tipoPermiso = tipoPermiso;
            _tipoLayoutPermiso = tipoLayoutPermiso;
        }

        public override bool TieneAcceso(ActionExecutingContext context)
        {
            try
            {
                var usuarioId = context.HttpContext.Session.GetUsuarioId();
                var historiaId = GetValorParametro(context, _parametros[0]).ToInteger();

                var permisoLogic = new PermisoLogic();
                var permiso = permisoLogic.GetPermisoHistoria(usuarioId, historiaId);

                return permisoLogic.TienePermisoSuficiente(permiso, _tipoPermiso);
            }
            catch (Exception ex)
            {
                return false;
            }
        }
    }

    public class PermisoIteracionAttribute : BaseActionFilterAttribute
    {
        public PermisoIteracionAttribute() { }
        public PermisoIteracionAttribute(String parametroIteracionId, PermisoLogic.TipoPermiso tipoPermiso, TipoLayoutPermiso tipoLayoutPermiso = TipoLayoutPermiso.Auto)
        {
            _parametros.Add(parametroIteracionId);
            _tipoPermiso = tipoPermiso;
            _tipoLayoutPermiso = tipoLayoutPermiso;
        }

        public override bool TieneAcceso(ActionExecutingContext context)
        {
            try
            {
                var usuarioId = context.HttpContext.Session.GetUsuarioId();
                var iteracionId = GetValorParametro(context, _parametros[0]).ToInteger();

                var permisoLogic = new PermisoLogic();
                var permiso = permisoLogic.GetPermisoIteracion(usuarioId, iteracionId);

                return permisoLogic.TienePermisoSuficiente(permiso, _tipoPermiso);
            }
            catch (Exception ex)
            {
                return false;
            }
        }
    }

    public class PermisoHistoriaIteracionAttribute : BaseActionFilterAttribute
    {
        public PermisoHistoriaIteracionAttribute() { }
        public PermisoHistoriaIteracionAttribute(String parametroHistoriaIteracionId, PermisoLogic.TipoPermiso tipoPermiso, TipoLayoutPermiso tipoLayoutPermiso = TipoLayoutPermiso.Auto)
        {
            _parametros.Add(parametroHistoriaIteracionId);
            _tipoPermiso = tipoPermiso;
            _tipoLayoutPermiso = tipoLayoutPermiso;
        }

        public override bool TieneAcceso(ActionExecutingContext context)
        {
            try
            {
                var usuarioId = context.HttpContext.Session.GetUsuarioId();
                var historiaIteracionId = GetValorParametro(context, _parametros[0]).ToInteger();

                var permisoLogic = new PermisoLogic();
                var permiso = permisoLogic.GetPermisoHistoriaIteracion(usuarioId, historiaIteracionId);

                return permisoLogic.TienePermisoSuficiente(permiso, _tipoPermiso);
            }
            catch (Exception ex)
            {
                return false;
            }
        }
    }

    public class PermisoHistoriaIteracionAsignadoAttribute : BaseActionFilterAttribute
    {
        public PermisoHistoriaIteracionAsignadoAttribute() { }
        public PermisoHistoriaIteracionAsignadoAttribute(String parametroHistoriaIteracionId, PermisoLogic.TipoPermiso tipoPermiso, TipoLayoutPermiso tipoLayoutPermiso = TipoLayoutPermiso.Auto)
        {
            _parametros.Add(parametroHistoriaIteracionId);
            _tipoPermiso = tipoPermiso;
            _tipoLayoutPermiso = tipoLayoutPermiso;
        }

        public override bool TieneAcceso(ActionExecutingContext context)
        {
            try
            {
                var usuarioId = context.HttpContext.Session.GetUsuarioId();
                var historiaIteracionId = GetValorParametro(context, _parametros[0]).ToInteger();

                var permisoLogic = new PermisoLogic();
                var permiso = permisoLogic.GetPermisoHistoriaIteracionAsignado(usuarioId, historiaIteracionId);

                return permisoLogic.TienePermisoSuficiente(permiso, _tipoPermiso);
            }
            catch (Exception ex)
            {
                return false;
            }
        }
    }

    public class PermisoTareaAttribute : BaseActionFilterAttribute
    {
        public PermisoTareaAttribute() { }
        public PermisoTareaAttribute(String parametroTareaId, PermisoLogic.TipoPermiso tipoPermiso, TipoLayoutPermiso tipoLayoutPermiso = TipoLayoutPermiso.Auto)
        {
            _parametros.Add(parametroTareaId);
            _tipoPermiso = tipoPermiso;
            _tipoLayoutPermiso = tipoLayoutPermiso;
        }

        public override bool TieneAcceso(ActionExecutingContext context)
        {
            try
            {
                var usuarioId = context.HttpContext.Session.GetUsuarioId();
                var tareaId = GetValorParametro(context, _parametros[0]).ToInteger();

                var permisoLogic = new PermisoLogic();
                var permiso = permisoLogic.GetPermisoTarea(usuarioId, tareaId);

                return permisoLogic.TienePermisoSuficiente(permiso, _tipoPermiso);
            }
            catch (Exception ex)
            {
                return false;
            }
        }
    }
}