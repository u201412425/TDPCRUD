using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;
using BitPerfect.GPRO.Models;
using BitPerfect.GPRO.Helpers;

namespace BitPerfect.GPRO.Logic
{
    public class PermisoLogic
    {
        public GProEntities context = new GProEntities();

        public enum TipoPermiso
        {
            Restringido = 1,
            Lectura = 2,
            Escritura = 3
        }

        public TipoPermiso GetMaxPermiso(TipoPermiso permisoA, TipoPermiso permisoB)
        {
            return (TipoPermiso)Math.Max((Int32)permisoA, (Int32)permisoB);
        }

        public TipoPermiso GetMinPermiso(TipoPermiso permisoA, TipoPermiso permisoB)
        {
            return (TipoPermiso)Math.Min((Int32)permisoA, (Int32)permisoB);
        }

        public Boolean TienePermisoSuficiente(TipoPermiso permisoObtenido, TipoPermiso permisoNecesario)
        {
            return (Int32)permisoObtenido >= (Int32)permisoNecesario;
        }

        public TipoPermiso GetPermisoProyecto(Int32 usuarioId, Int32 proyectoId)
        {
            var usuario = context.Usuario.FirstOrDefault(x => x.UsuarioId == usuarioId);

            if (usuario.Rol == ConstantHelpers.Rol.ADMINISTRADOR)
                return TipoPermiso.Escritura;

            var usuarioProyecto = context.UsuarioProyecto.FirstOrDefault(x => x.UsuarioId == usuarioId && x.ProyectoId == proyectoId && x.Proyecto.Estado == ConstantHelpers.Estado.ACTIVO);

            if (usuarioProyecto != null)
            {
                if (usuarioProyecto.Rol == ConstantHelpers.RolProyecto.SUPERVISOR)
                    return TipoPermiso.Lectura;
                if (usuarioProyecto.Rol == ConstantHelpers.RolProyecto.JEFE_PROYECTO)
                    return TipoPermiso.Escritura;
                if (usuarioProyecto.Rol == ConstantHelpers.RolProyecto.RECURSO)
                    return TipoPermiso.Lectura;
            }

            return TipoPermiso.Restringido;
        }


        public TipoPermiso GetPermisoHistoria(Int32 usuarioId, Int32 historiaId)
        {
            var usuario = context.Usuario.FirstOrDefault(x => x.UsuarioId == usuarioId);

            if (usuario.Rol == ConstantHelpers.Rol.ADMINISTRADOR)
                return TipoPermiso.Escritura;
            var historia = context.Historia.FirstOrDefault(x => x.HistoriaId == historiaId);

            if (historia == null)
                return TipoPermiso.Restringido;

            if (historia.Estado == ConstantHelpers.EstadoHistoria.INACTIVO)
                return TipoPermiso.Lectura;

            var usuarioProyecto = context.UsuarioProyecto.FirstOrDefault(x => x.UsuarioId == usuarioId && x.ProyectoId == historia.ProyectoId && x.Proyecto.Estado == ConstantHelpers.Estado.ACTIVO);

            if (usuarioProyecto != null)
            {

                if (usuarioProyecto.Rol == ConstantHelpers.RolProyecto.SUPERVISOR)
                    return TipoPermiso.Lectura;
                if (usuarioProyecto.Rol == ConstantHelpers.RolProyecto.JEFE_PROYECTO)
                    return TipoPermiso.Escritura;
                if (usuarioProyecto.Rol == ConstantHelpers.RolProyecto.RECURSO)
                    return TipoPermiso.Lectura;
            }

            return TipoPermiso.Restringido;
        }

        public TipoPermiso GetPermisoIteracion(Int32 usuarioId, Int32 iteracionId)
        {
            var usuario = context.Usuario.FirstOrDefault(x => x.UsuarioId == usuarioId);

            if (usuario.Rol == ConstantHelpers.Rol.ADMINISTRADOR)
                return TipoPermiso.Escritura;

            var iteracion = context.Iteracion.FirstOrDefault(x => x.IteracionId == iteracionId);

            if (iteracion == null)
                return TipoPermiso.Restringido;

            if (iteracion.Estado == ConstantHelpers.EstadoIteracion.INACTIVO)
                return TipoPermiso.Lectura;

            var usuarioProyecto = context.UsuarioProyecto.FirstOrDefault(x => x.UsuarioId == usuarioId && x.ProyectoId == iteracion.ProyectoId && x.Proyecto.Estado == ConstantHelpers.Estado.ACTIVO);

            if (usuarioProyecto != null)
            {

                if (usuarioProyecto.Rol == ConstantHelpers.RolProyecto.SUPERVISOR)
                    return TipoPermiso.Lectura;
                if (usuarioProyecto.Rol == ConstantHelpers.RolProyecto.JEFE_PROYECTO)
                    return TipoPermiso.Escritura;
                if (usuarioProyecto.Rol == ConstantHelpers.RolProyecto.RECURSO)
                    return TipoPermiso.Lectura;
            }

            return TipoPermiso.Restringido;
        }

        public TipoPermiso GetPermisoHistoriaIteracion(Int32 usuarioId, Int32 historiaIteracionId)
        {
            var usuario = context.Usuario.FirstOrDefault(x => x.UsuarioId == usuarioId);

            if (usuario.Rol == ConstantHelpers.Rol.ADMINISTRADOR)
                return TipoPermiso.Escritura;

            var historiaIteracion = context.HistoriaIteracion.Include(x => x.Historia).Include(x => x.Iteracion).FirstOrDefault(x => x.HistoriaIteracionId == historiaIteracionId);

            if (historiaIteracion == null)
                return TipoPermiso.Restringido;

            if (historiaIteracion.Estado == ConstantHelpers.Estado.INACTIVO || historiaIteracion.Iteracion.Estado == ConstantHelpers.EstadoIteracion.INACTIVO || historiaIteracion.Historia.Estado == ConstantHelpers.EstadoHistoria.INACTIVO)
                return TipoPermiso.Lectura;

            var usuarioProyecto = context.UsuarioProyecto.FirstOrDefault(x => x.UsuarioId == usuarioId && x.ProyectoId == historiaIteracion.Iteracion.ProyectoId && x.Proyecto.Estado == ConstantHelpers.Estado.ACTIVO);

            if (usuarioProyecto != null)
            {

                if (usuarioProyecto.Rol == ConstantHelpers.RolProyecto.SUPERVISOR)
                    return TipoPermiso.Lectura;
                if (usuarioProyecto.Rol == ConstantHelpers.RolProyecto.JEFE_PROYECTO)
                    return TipoPermiso.Escritura;
                if (usuarioProyecto.Rol == ConstantHelpers.RolProyecto.RECURSO)
                    return TipoPermiso.Lectura;
            }

            return TipoPermiso.Restringido;
        }

        public TipoPermiso GetPermisoHistoriaIteracionAsignado(Int32 usuarioId, Int32 historiaIteracionId)
        {
            var usuario = context.Usuario.FirstOrDefault(x => x.UsuarioId == usuarioId);

            if (usuario.Rol == ConstantHelpers.Rol.ADMINISTRADOR)
                return TipoPermiso.Escritura;

            var historiaIteracion = context.HistoriaIteracion.Include(x => x.Historia).Include(x => x.Iteracion).FirstOrDefault(x => x.HistoriaIteracionId == historiaIteracionId);

            if (historiaIteracion == null)
                return TipoPermiso.Restringido;

            if (historiaIteracion.Estado == ConstantHelpers.Estado.INACTIVO || historiaIteracion.Iteracion.Estado == ConstantHelpers.EstadoIteracion.INACTIVO || historiaIteracion.Historia.Estado == ConstantHelpers.EstadoHistoria.INACTIVO)
                return TipoPermiso.Lectura;

            var usuarioProyecto = context.UsuarioProyecto.FirstOrDefault(x => x.UsuarioId == usuarioId && x.ProyectoId == historiaIteracion.Iteracion.ProyectoId && x.Proyecto.Estado == ConstantHelpers.Estado.ACTIVO);

            if (usuarioProyecto != null)
            {

                if (historiaIteracion.UsuarioAsignadoId == usuario.UsuarioId)
                    return TipoPermiso.Escritura;
                else
                    return TipoPermiso.Lectura;
            }

            return TipoPermiso.Restringido;
        }

        public TipoPermiso GetPermisoTarea(Int32 usuarioId, Int32 tareaId)
        {
            var usuario = context.Usuario.FirstOrDefault(x => x.UsuarioId == usuarioId);

            if (usuario.Rol == ConstantHelpers.Rol.ADMINISTRADOR)
                return TipoPermiso.Escritura;

            var tarea = context.Tarea.Include(x => x.Historia).FirstOrDefault(x => x.TareaId == tareaId);

            if (tarea == null)
                return TipoPermiso.Restringido;

            if (tarea.Estado == ConstantHelpers.EstadoTarea.INACTIVO || tarea.Historia.Estado == ConstantHelpers.EstadoHistoria.INACTIVO)
                return TipoPermiso.Lectura;


            var usuarioProyecto = context.UsuarioProyecto.FirstOrDefault(x => x.UsuarioId == usuarioId && x.ProyectoId == tarea.Historia.ProyectoId && x.Proyecto.Estado == ConstantHelpers.Estado.ACTIVO);

            if (usuarioProyecto != null)
            {
                return TipoPermiso.Escritura;

                if (usuarioProyecto.Rol == ConstantHelpers.RolProyecto.SUPERVISOR)
                    return TipoPermiso.Lectura;
                if (usuarioProyecto.Rol == ConstantHelpers.RolProyecto.JEFE_PROYECTO)
                    return TipoPermiso.Escritura;
                if (usuarioProyecto.Rol == ConstantHelpers.RolProyecto.RECURSO)
                    return TipoPermiso.Lectura;
            }

            return TipoPermiso.Restringido;
        }
    }
}