using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Web;
using System.Web.Mvc;
using System.Web.Mvc.Html;
using System.Web.Mvc.Ajax;

namespace BitPerfect.GPRO.Helpers
{
    public class DataHelper<TModel>
    {
        private AppWebViewPage<TModel> dataWebViewPage { get; set; }

        public DataHelper(AppWebViewPage<TModel> dataWebViewPage)
        {
            if (dataWebViewPage == null)
            {
                throw new ArgumentNullException("dataWebViewPage");
            }
            this.dataWebViewPage = dataWebViewPage;
        }

        public MvcHtmlString AjaxLink(String actionName, AjaxOptions ajaxOptions)
        {
            return AjaxLink(actionName, null, null, ajaxOptions, null);
        }

        public MvcHtmlString AjaxLink(String actionName, object routeValues, AjaxOptions ajaxOptions)
        {
            return AjaxLink(actionName, null, routeValues, ajaxOptions, null);
        }

        public MvcHtmlString AjaxLink(String actionName, String controllerName, AjaxOptions ajaxOptions)
        {
            return AjaxLink(actionName, controllerName, null, ajaxOptions, null);
        }

        public MvcHtmlString AjaxLink(String actionName, object routeValues, AjaxOptions ajaxOptions, object htmlAttributes)
        {
            return AjaxLink(actionName, null, routeValues, ajaxOptions, htmlAttributes);
        }

        public MvcHtmlString AjaxLink(String actionName, String controllerName, object routeValues, AjaxOptions ajaxOptions)
        {
            return AjaxLink(actionName, controllerName, routeValues, ajaxOptions, null);
        }

        public MvcHtmlString AjaxLink(String actionName, String controllerName, object routeValues, AjaxOptions ajaxOptions, object htmlAttributes)
        {
            var actionLink = dataWebViewPage.Ajax.ActionLink("#", actionName, controllerName, routeValues, ajaxOptions, htmlAttributes).ToString();
            actionLink = actionLink.Replace("data-ajax=\"true\"", "data-ajax-link=\"true\"");
            return MvcHtmlString.Create(actionLink.Substring(3, actionLink.Length - 9));
        }


        /*
         * data-type="modal-link" data-source-url="@Url.Action("EditAutor", new { ExperienciaExitosaId = Model.ExperienciaExitosaId, AutorId = item.AutorId})"
         */

        public IHtmlString ModalLink(String action)
        {
            return ModalLink(action, null, null);
        }

        public IHtmlString ModalLink(String action, String controller)
        {
            return ModalLink(action, controller, null);
        }

        public IHtmlString ModalLink(String action, object routeValues)
        {
            return ModalLink(action, null, routeValues);
        }

        public IHtmlString ModalLink(String action, String controller, object routeValues)
        {
            var result = "data-type=\"modal-link\"  data-source-url=\"" + dataWebViewPage.Url.Action(action, controller, routeValues) + "\"";
            return new HtmlString(result);
        }

        public IHtmlString Tooltip(String title, String position = "top", Boolean esHtml = false)
        {
            var result = "data-toggle=\"tooltip\" data-placement=\"" + position + "\" title=\"" + title + "\"" + (esHtml ? " data-html=\"true\"" : "");
            return new HtmlString(result);
        }

        public IHtmlString WidgetMensaje(String Objeto, Int32 ObjetoId)
        {
            var result = @"<div data-widget-message='" + Objeto + @"' data-widget-object-id='" + ObjetoId + @"'>
                            <div class='widget style1 lazur-bg'>
                                <div class='row'>
                                    <div class='col-xs-4'>
                                        <i class='fa fa-envelope-o fa-5x'></i>
                                    </div>
                                    <div class='col-xs-8 text-right'>
                                        <span>Mensajes</span>
                                        <h2 class='font-bold'>Cargando</h2>
                                    </div>
                                </div>
                            </div>
                        </div>";

            return new HtmlString(result);
        }

        public IHtmlString WidgetArchivo(String Objeto, Int32 ObjetoId)
        {
            var result = @"<div data-widget-file='" + Objeto + @"' data-widget-object-id='" + ObjetoId + @"'>
                            <div class='widget style1 lazur-bg'>
                                <div class='row'>
                                    <div class='col-xs-4'>
                                        <i class='fa fa-cloud fa-5x'></i>
                                    </div>
                                    <div class='col-xs-8 text-right'>
                                        <span>Archivos</span>
                                        <h2 class='font-bold'>Cargando</h2>
                                    </div>
                                </div>
                            </div>
                        </div>";

            return new HtmlString(result);
        }

        public IHtmlString WidgetBurndownChart(Int32 ProyectoId, Int32? ItereacionId = null, Int32? HistoriaId = null)
        {
            var parametros = "data-widget-burndown-chart=\"" + ProyectoId + "\"";
            parametros += ItereacionId.HasValue ? " data-widget-iteracion=\"" + ItereacionId.Value + "\"" : "";
            parametros += HistoriaId.HasValue ? " data-widget-historia=\"" + HistoriaId.Value + "\"" : "";

            var result = @"<div " + parametros + @"'>
                            <div class='widget style1 lazur-bg'>
                                <div class='row'>
                                    <div class='col-xs-4'>
                                        <i class='fa fa-area-chart fa-5x'></i>
                                    </div>
                                    <div class='col-xs-8 text-right'>
                                        <span>Gr�fico</span>
                                        <h2 class='font-bold'>Cargando</h2>
                                    </div>
                                </div>
                            </div>
                        </div>";

            return new HtmlString(result);
        }

        public IHtmlString ValidationFor<TProperty>(Expression<Func<TModel, TProperty>> propertyExpression)
        {
            var html = dataWebViewPage.Html;
            var propertyName = html.NameFor(propertyExpression).ToString();
            var metadata = ModelMetadata.FromLambdaExpression(propertyExpression, html.ViewData);
            var attributes = html.GetUnobtrusiveValidationAttributes(propertyName, metadata);
            return new HtmlString(String.Join(" ", attributes.Select(x => String.Format("{0}=\"{1}\"", x.Key, x.Value)).ToArray()));
        }
    }
}
