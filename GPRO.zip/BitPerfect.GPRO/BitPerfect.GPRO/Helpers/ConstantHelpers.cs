using BitPerfect.GPRO.Models;
using PagedList.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BitPerfect.GPRO.Helpers
{
    public static class ConstantHelpers
    {
        public static readonly Int32 DEFAULT_PAGE_SIZE = 30;

        public static class Rol
        {
            public const String ADMINISTRADOR = "ADM";
            public const String USUARIO = "USR";

            public static String Nombre(String rol)
            {
                switch (rol)
                {
                    case Rol.ADMINISTRADOR: return "Administrador";
                    case Rol.USUARIO: return "Usuario";
                    default: return "N/A";
                }
            }
        }

        public static class RolProyecto
        {
            public const String JEFE_PROYECTO = "JPR";
            public const String RECURSO = "REC";
            public const String SUPERVISOR = "SVR";

            public static String Nombre(String rol)
            {
                switch (rol)
                {
                    case RolProyecto.JEFE_PROYECTO: return "Jefe de Proyecto";
                    case RolProyecto.RECURSO: return "Recurso";
                    case RolProyecto.SUPERVISOR: return "Supervisor";
                    default: return "N/A";
                }
            }
        }

        public static class ObjetoMensaje
        {
            public const String PROYECTO = "PROYE";
            public const String HISTORIA = "HISTO";

            public static String Nombre(String objeto)
            {
                switch (objeto)
                {
                    case ObjetoMensaje.PROYECTO: return "Proyecto";
                    case ObjetoMensaje.HISTORIA: return "Historia";
                    default: return "N/A";
                }
            }
        }

        public static class ObjetoArchivo
        {
            public const String PROYECTO = "PROYE";
            public const String HISTORIA = "HISTO";

            public static String Nombre(String objeto)
            {
                switch (objeto)
                {
                    case ObjetoMensaje.PROYECTO: return "Proyecto";
                    case ObjetoMensaje.HISTORIA: return "Historia";
                    default: return "N/A";
                }
            }
        }

        public static class Estado
        {
            public const String ACTIVO = "ACT";
            public const String INACTIVO = "INA";

            public static String Nombre(String estado)
            {
                switch (estado)
                {
                    case Estado.ACTIVO: return "Activo";
                    case Estado.INACTIVO: return "Inactivo";
                    default: return "N/A";
                }
            }
        }

        public static class EstadoIteracion
        {
            public const String DISENO = "DIS";
            public const String PENDIENTE_APROBACION = "PEN";
            public const String ACTIVO = "ACT";
            public const String FINALIZADO = "FIN";
            public const String INACTIVO = "INA";

            public static String Nombre(String estado)
            {
                switch (estado)
                {
                    case EstadoIteracion.DISENO: return "Diseño";
                    case EstadoIteracion.PENDIENTE_APROBACION: return "Pend. aprobación";
                    case EstadoIteracion.ACTIVO: return "Activo";
                    case EstadoIteracion.FINALIZADO: return "Finalizado";
                    case EstadoIteracion.INACTIVO: return "Inactivo";
                    default: return "N/A";
                }
            }
        }

        public static class TipoRepositorio
        {
            public const String FOLDER = "FOL";
            public const String ARCHIVO = "ARC";
        }

        public static class EstadoHistoria
        {
            public const String DISENO = "DIS";
            public const String PENDIENTE = "PEN";
            public const String EN_PROGRESO = "PRO";
            public const String FINALIZADO = "FIN";
            public const String APROBADO = "APR";
            public const String INACTIVO = "INA";

            public static String Nombre(String estado)
            {
                switch (estado)
                {
                    case EstadoHistoria.DISENO: return "Diseño";
                    case EstadoHistoria.PENDIENTE: return "Pendiente";
                    case EstadoHistoria.EN_PROGRESO: return "En progreso";
                    case EstadoHistoria.FINALIZADO: return "Finalizado";
                    case EstadoHistoria.APROBADO: return "Aprobado";
                    case EstadoHistoria.INACTIVO: return "Inactivo";
                    default: return "N/A";
                }
            }
        }

        public static class EstadoTarea
        {
            public const String PENDIENTE = "PEN";
            public const String FINALIZADO = "FIN";
            public const String INACTIVO = "INA";

            public static String Nombre(String estado)
            {
                switch (estado)
                {
                    case EstadoTarea.PENDIENTE: return "Pendiente";
                    case EstadoTarea.FINALIZADO: return "Finalizado";
                    case EstadoTarea.INACTIVO: return "Inactivo";
                    default: return "N/A";
                }
            }
        }

        public static class Layout
        {
            public const String MODAL_LAYOUT_PATH = "~/Views/Shared/_ModalLayout.cshtml";
            public const String MODAL_EMAIL_PATH = "~/Views/Shared/_MailLayout.cshtml";
        }

        public static class ExtensionRepositorioIcono
        {
            private static readonly Dictionary<String, String> DictExtensionesIconos = new Dictionary<String, String>
                {
                    {".doc","fa-file-word-o" },
                    {".docx","fa-file-word-o" },
                    {".log","fa-file-text-o" },
                    {".rtf","fa-file-text-o" },
                    {".txt","fa-file-text-o" },
                    {".pps","fa-file-powerpoint-o" },
                    {".ppt","fa-file-powerpoint-o" },
                    {".pptx","fa-file-powerpoint-o" },
                    {".xml","fa-file-code-o" },
                    {".m3u","fa-file-audio-o" },
                    {".m4a","fa-file-audio-o" },
                    {".mid","fa-file-audio-o" },
                    {".mp3","fa-file-audio-o" },
                    {".mpa","fa-file-audio-o" },
                    {".wav","fa-file-audio-o" },
                    {".wma","fa-file-audio-o" },
                    {".avi","fa-file-video-o" },
                    {".flv","fa-file-video-o" },
                    {".m4v","fa-file-video-o" },
                    {".mov","fa-file-video-o" },
                    {".mp4","fa-file-video-o" },
                    {".mpg","fa-file-video-o" },
                    {".vob","fa-file-video-o" },
                    {".wmv","fa-file-video-o" },
                    {".swf","fa-file-code-o" },
                    {".bmp","fa-file-image-o" },
                    {".gif","fa-file-image-o" },
                    {".jpg","fa-file-image-o" },
                    {".png","fa-file-image-o" },
                    {".psd","fa-file-image-o" },
                    {".tif","fa-file-image-o" },
                    {".tiff","fa-file-image-o" },
                    {".pdf","fa-file-pdf-o" },
                    {".xlr","fa-file-excel-o" },
                    {".xls","fa-file-excel-o" },
                    {".xlsx","fa-file-excel-o" },
                    {".asp","fa-file-code-o" },
                    {".aspx","fa-file-code-o" },
                    {".cer","fa-file-code-o" },
                    {".cfm","fa-file-code-o" },
                    {".csr","fa-file-code-o" },
                    {".css","fa-file-code-o" },
                    {".htm","fa-file-code-o" },
                    {".html","fa-file-code-o" },
                    {".js","fa-file-code-o" },
                    {".jsp","fa-file-code-o" },
                    {".php","fa-file-code-o" },
                    {".rss","fa-file-code-o" },
                    {".xhtml","fa-file-code-o" },
                    {".fnt","fa-file-code-o" },
                    {".fon","fa-file-code-o" },
                    {".otf","fa-file-code-o" },
                    {".ttf","fa-file-code-o" },
                    {".c","fa-file-code-o" },
                    {".class","fa-file-code-o" },
                    {".cpp","fa-file-code-o" },
                    {".cs","fa-file-code-o" },
                    {".dtd","fa-file-code-o" },
                    {".fla","fa-file-code-o" },
                    {".h","fa-file-code-o" },
                    {".java","fa-file-code-o" },
                    {".lua","fa-file-code-o" },
                    {".m","fa-file-code-o" },
                    {".pl","fa-file-code-o" },
                    {".py","fa-file-code-o" },
                    {".sh","fa-file-code-o" },
                    {".sln","fa-file-code-o" },
                    {".swift","fa-file-code-o" },
                    {".7z","fa-file-archive-o" },
                    {".cbr","fa-file-archive-o" },
                    {".deb","fa-file-archive-o" },
                    {".gz","fa-file-archive-o" },
                    {".pkg","fa-file-archive-o" },
                    {".rar","fa-file-archive-o" },
                    {".rpm","fa-file-archive-o" },
                    {".sitx","fa-file-archive-o" },
                    {".tar.gz","fa-file-archive-o" },
                    {".zip","fa-file-archive-o" },
                    {".zipx","fa-file-archive-o" },
                };

            public static String Icono(String extension)
            {
                if (DictExtensionesIconos.ContainsKey(extension))
                    return DictExtensionesIconos[extension];
                else
                    return "fa-file-o";
            }
        }

        public static String RutaImagenPerfil(Usuario usuario)
        {
            return "/Static/ImgPerfil/" + usuario.ImagenPerfil + ".jpg";
        }

        public static PagedListRenderOptions Bootstrap3Pager
        {
            get
            {
                return new PagedListRenderOptions
                {
                    DisplayLinkToFirstPage = PagedListDisplayMode.IfNeeded,
                    DisplayLinkToLastPage = PagedListDisplayMode.IfNeeded,
                    DisplayLinkToPreviousPage = PagedListDisplayMode.IfNeeded,
                    DisplayLinkToNextPage = PagedListDisplayMode.IfNeeded,
                    DisplayLinkToIndividualPages = true,
                    DisplayPageCountAndCurrentLocation = false,
                    MaximumPageNumbersToDisplay = 10,
                    DisplayEllipsesWhenNotShowingAllPageNumbers = true,
                    EllipsesFormat = "&#8230;",
                    LinkToFirstPageFormat = "««",
                    LinkToPreviousPageFormat = "«",
                    LinkToIndividualPageFormat = "{0}",
                    LinkToNextPageFormat = "»",
                    LinkToLastPageFormat = "»»",
                    PageCountAndCurrentLocationFormat = "Page {0} of {1}.",
                    ItemSliceAndTotalFormat = "Showing items {0} through {1} of {2}.",
                    FunctionToDisplayEachPageNumber = null,
                    ClassToApplyToFirstListItemInPager = null,
                    ClassToApplyToLastListItemInPager = null,
                    ContainerDivClasses = new[] { "pagination-container" },
                    UlElementClasses = new[] { "pagination" },
                    LiElementClasses = Enumerable.Empty<string>(),
                };
            }
        }
    }
}