using BitPerfect.GPRO.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.SessionState;

namespace BitPerfect.GPRO.Helpers
{
    public enum AppRol
    {
        Administrador,
        Usuario,
        Supervisor
    }

    public enum SessionKey
    {
        Usuario,
        UsuarioId,
        NombreCompleto,
        AppRol,
        CodigoRol,
        ProyectoId,
        Proyecto,
        RolProyecto
    }

    public static class SessionHelpers
    {
        #region TieneRol
        public static Boolean TieneRol(this HttpSessionState Session, AppRol Rol)
        {
            return Session.GetAppRol() == Rol;
        }

        public static Boolean TieneRol(this HttpSessionStateBase Session, AppRol Rol)
        {
            return Session.GetAppRol() == Rol;
        }
        #endregion

        #region GetUsuarioId
        public static Int32 GetUsuarioId(this HttpSessionState Session)
        {
            return Get(Session, SessionKey.UsuarioId).ToInteger();
        }

        public static Int32 GetUsuarioId(this HttpSessionStateBase Session)
        {
            return Get(Session, SessionKey.UsuarioId).ToInteger();
        }
        #endregion

        #region GetUsuario
        public static Usuario GetUsuario(this HttpSessionState Session)
        {
            return (Usuario)Get(Session, SessionKey.Usuario);
        }

        public static Usuario GetUsuario(this HttpSessionStateBase Session)
        {
            return (Usuario)Get(Session, SessionKey.Usuario);
        }
        #endregion

        #region GetNombreCompleto
        public static String GetNombreCompleto(this HttpSessionState Session)
        {
            return Get(Session, SessionKey.NombreCompleto).ToString();
        }

        public static String GetNombreCompleto(this HttpSessionStateBase Session)
        {
            return Get(Session, SessionKey.NombreCompleto).ToString();
        }
        #endregion

        #region GetRol
        public static AppRol? GetAppRol(this HttpSessionState Session)
        {
            return (AppRol?)Get(Session, SessionKey.AppRol);
        }

        public static AppRol? GetAppRol(this HttpSessionStateBase Session)
        {
            return (AppRol?)Get(Session, SessionKey.AppRol);
        }
        #endregion

        #region GetProyectoId

        public static int GetProyectoId(this HttpSessionState Session)
        {
            return Get(Session, SessionKey.ProyectoId).ToInteger();
        }
        public static int GetProyectoId(this HttpSessionStateBase Session)
        {
            return Get(Session, SessionKey.ProyectoId).ToInteger();
        }
        #endregion

        #region GetProyecto

        public static Proyecto GetProyecto(this HttpSessionState Session)
        {
            return (Proyecto)Get(Session, SessionKey.Proyecto);
        }
        public static Proyecto GetProyecto(this HttpSessionStateBase Session)
        {
            return (Proyecto)Get(Session, SessionKey.Proyecto);
        }
        #endregion

        #region GetRolProyecto

        public static String GetRolProyecto(this HttpSessionState Session)
        {
            return (String)Get(Session, SessionKey.RolProyecto);
        }
        public static String GetRolProyecto(this HttpSessionStateBase Session)
        {
            return (String)Get(Session, SessionKey.RolProyecto);
        }
        #endregion

        #region GetCodigoRol
        public static String GetCodigoRol(this HttpSessionState Session)
        {
            return (String)Get(Session, SessionKey.CodigoRol);
        }

        public static String GetCodigoRol(this HttpSessionStateBase Session)
        {
            return (String)Get(Session, SessionKey.CodigoRol);
        }
        #endregion

        #region Private

        private static object Get(HttpSessionState Session, String Key)
        {
            return Session[Key];
        }

        private static void Set(HttpSessionState Session, String Key, object Value)
        {
            Session[Key] = Value;
        }

        private static bool Exists(HttpSessionState Session, String Key)
        {
            return Session[Key] != null;
        }

        private static object Get(HttpSessionStateBase Session, String Key)
        {
            return Session[Key];
        }

        private static void Set(HttpSessionStateBase Session, String Key, object Value)
        {
            Session[Key] = Value;
        }

        private static bool Exists(HttpSessionStateBase Session, String Key)
        {
            return Session[Key] != null;
        }

        #endregion

        #region Getters setters GlobalKey
        //HttpSessionState
        public static object Get(this HttpSessionState Session, SessionKey Key)
        {
            return Get(Session, Key.ToString());
        }

        public static void Set(this HttpSessionState Session, SessionKey Key, object Value)
        {
            Set(Session, Key.ToString(), Value);
        }

        public static bool Exists(this HttpSessionState Session, SessionKey Key)
        {
            return Exists(Session, Key.ToString());
        }

        //HttpSessionStateBase
        public static object Get(this HttpSessionStateBase Session, SessionKey Key)
        {
            return Get(Session, Key.ToString());
        }

        public static void Set(this HttpSessionStateBase Session, SessionKey Key, object Value)
        {
            Set(Session, Key.ToString(), Value);
        }

        public static bool Exists(this HttpSessionStateBase Session, SessionKey Key)
        {
            return Exists(Session, Key.ToString());
        }
        #endregion
    }
}