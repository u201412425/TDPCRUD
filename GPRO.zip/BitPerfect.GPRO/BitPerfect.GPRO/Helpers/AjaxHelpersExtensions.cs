using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;
using System.Linq.Expressions;
using System.Web.Mvc.Html;
using System.Web.Mvc.Ajax;

namespace BitPerfect.GPRO.Helpers
{
    public static class AjaxHelpersExtensions
    {
        #region Ajax
        public static MvcHtmlString ActionLinkData(this AjaxHelper ajaxHelper, string actionName, AjaxOptions ajaxOptions)
        {
            return AjaxHelpersExtensions.ActionLinkData(ajaxHelper, actionName, (string)null, ajaxOptions);
        }

        public static MvcHtmlString ActionLinkData(this AjaxHelper ajaxHelper, string actionName, object routeValues, AjaxOptions ajaxOptions)
        {
            return AjaxHelpersExtensions.ActionLinkData(ajaxHelper, actionName, (string)null, routeValues, ajaxOptions);
        }

        public static MvcHtmlString ActionLinkData(this AjaxHelper ajaxHelper, string actionName, object routeValues, AjaxOptions ajaxOptions, object htmlAttributes)
        {
            return AjaxHelpersExtensions.ActionLinkData(ajaxHelper, actionName, (string)null, routeValues, ajaxOptions, htmlAttributes);
        }

        public static MvcHtmlString ActionLinkData(this AjaxHelper ajaxHelper, string actionName, string controllerName, AjaxOptions ajaxOptions)
        {
            return AjaxHelpersExtensions.ActionLinkData(ajaxHelper, actionName, controllerName, (object)null, ajaxOptions, (object)null);
        }

        public static MvcHtmlString ActionLinkData(this AjaxHelper ajaxHelper, string actionName, string controllerName, object routeValues, AjaxOptions ajaxOptions)
        {
            return AjaxHelpersExtensions.ActionLinkData(ajaxHelper, actionName, controllerName, routeValues, ajaxOptions, (object)null);
        }

        public static MvcHtmlString ActionLinkData(this AjaxHelper ajaxHelper, string actionName, string controllerName, object routeValues, AjaxOptions ajaxOptions, object htmlAttributes)
        {
            var actionLink = ajaxHelper.ActionLink("#LINK-TEXT#", actionName, controllerName, routeValues, ajaxOptions, htmlAttributes).ToString();
            actionLink = actionLink.Replace(">#LINK-TEXT#</a>", "").Substring(3);
            return MvcHtmlString.Create(actionLink);
        }
        #endregion
    }

}