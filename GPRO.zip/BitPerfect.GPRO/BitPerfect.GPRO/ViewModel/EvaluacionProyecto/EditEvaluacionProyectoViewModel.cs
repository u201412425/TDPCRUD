﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using ent = BitPerfect.GPRO.Models;
using BitPerfect.GPRO.Controllers;
using BitPerfect.GPRO.Helpers;
using System.ComponentModel.DataAnnotations;
using System.Data.Entity;

namespace BitPerfect.GPRO.ViewModel.EvaluacionProyecto
{
    public class EditEvaluacionProyectoViewModel
    {
        public Int32? EvaluacionProyectoId { get; set; }
        [Display(Name = "Estado")]
        [Required(ErrorMessageResourceName = "CampoRequerido", ErrorMessageResourceType = typeof(i18n.ValidationStrings))]
        public String Estado { get; set; }
        [Display(Name = "Plan de Evaluación")]
        [Required(ErrorMessageResourceName = "CampoRequerido", ErrorMessageResourceType = typeof(i18n.ValidationStrings))]
        public Int32 PlanEvaluacionId { get; set; }
        [Display(Name = "Usuario por asignar")]
        [Required(ErrorMessageResourceName = "CampoRequerido", ErrorMessageResourceType = typeof(i18n.ValidationStrings))]
        public Int32 UsuarioAsignadoId { get; set; }
        [Display(Name = "Cuestionario")]
        [Required(ErrorMessageResourceName = "CampoRequerido", ErrorMessageResourceType = typeof(i18n.ValidationStrings))]
        public Int32 CuestionarioId { get; set; }
        [Display(Name = "Rol")]
        [Required(ErrorMessageResourceName = "CampoRequerido", ErrorMessageResourceType = typeof(i18n.ValidationStrings))]
        public Int32 RolEvaluacionId { get; set; }
        [Display(Name = "Proyecto")]
        [Required(ErrorMessageResourceName = "CampoRequerido", ErrorMessageResourceType = typeof(i18n.ValidationStrings))]
        public Int32 ProyectoId { get; set; }
        public List<ent.Usuario> LstUsuario { get; set; }
        public List<ent.Cuestionario> LstCuestionario { get; set; }
        public List<ent.PlanEvaluacion> LstPlanEvaluacion { get; set; }
        public List<ent.RolEvaluacion> LstRolEvaluacion { get; set; }
        public List<ent.Proyecto> LstProyecto { get; set; }

        public EditEvaluacionProyectoViewModel()
        {
        }

        public void CargarDatos(CargarDatosContext dataContext, Int32? evaluacionProyectoId)
        {
            EvaluacionProyectoId = evaluacionProyectoId;
            this.LstUsuario = dataContext.context.Usuario.ToList();
            this.LstCuestionario = dataContext.context.Cuestionario.Where(x=>x.Estado == "ACT").ToList();
            this.LstPlanEvaluacion = dataContext.context.PlanEvaluacion.Where(x => x.Estado == "ACT").ToList();
            this.LstRolEvaluacion = dataContext.context.RolEvaluacion.Where(x => x.Estado == "ACT").ToList();
            this.LstProyecto = dataContext.context.Proyecto.Where(x => x.Estado == "ACT").ToList();
            if (EvaluacionProyectoId.HasValue)
            {
                var EvaluacionProyecto = dataContext.context.EvaluacionProyecto.First(x => x.EvaluacionProyectoId == evaluacionProyectoId);
                this.Estado = EvaluacionProyecto.Estado;
                this.PlanEvaluacionId = EvaluacionProyecto.PlanEvaluacionId;
                this.RolEvaluacionId = EvaluacionProyecto.RolEvaluacionId;
                this.UsuarioAsignadoId = EvaluacionProyecto.UsuarioAsignadoId;
                this.CuestionarioId = EvaluacionProyecto.CuestionarioId;
                this.ProyectoId = EvaluacionProyecto.ProyectoId;
            }

        }
    }
}