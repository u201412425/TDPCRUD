﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using ent = BitPerfect.GPRO.Models;
using BitPerfect.GPRO.Controllers;
using BitPerfect.GPRO.Helpers;
using System.Data.Entity;

namespace BitPerfect.GPRO.ViewModel.EvaluacionProyecto
{
    public class ListEvaluacionProyectoViewModel
    {
        public List<ent.EvaluacionProyecto> LstEvaluacionProyecto { get; set; }

        public ListEvaluacionProyectoViewModel()
        {
            LstEvaluacionProyecto = new List<ent.EvaluacionProyecto>();
        }

        public void CargarDatos(CargarDatosContext dataContext)
        {
            LstEvaluacionProyecto = dataContext.context.EvaluacionProyecto.Include(x => x.Usuario).Include(x => x.Usuario1).Include(x => x.Cuestionario).Include(x => x.PlanEvaluacion).Include(x=>x.RolEvaluacion).Include(x => x.Proyecto).ToList();
        }
    }
}
