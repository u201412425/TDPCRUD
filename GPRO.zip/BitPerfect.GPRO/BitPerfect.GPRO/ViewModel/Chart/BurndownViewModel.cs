﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using BitPerfect.GPRO.Controllers;
using BitPerfect.GPRO.Models;
using BitPerfect.GPRO.Helpers;
using System.Data.Entity;
using PagedList;

namespace BitPerfect.GPRO.ViewModel.Chart
{
    public class BurndownViewModel
    {
        public Int32 ProyectoId { get; set; }
        public Int32? IteracionId { get; set; }
        public Int32? HistoriaId { get; set; }
        public List<Iteracion> LstIteracion { get; set; }
        public List<Historia> LstHistoria { get; set; }

        public BurndownViewModel() { }

        public void CargarDatos(CargarDatosContext dataContext, Int32? proyectoId, Int32? iteracionId, Int32? historiaId)
        {
            if (!proyectoId.HasValue)
                ProyectoId = dataContext.session.GetProyectoId();

            IteracionId = iteracionId;
            HistoriaId = historiaId;

            LstIteracion = dataContext.context.Iteracion.Where(x => x.ProyectoId == ProyectoId && x.Estado != ConstantHelpers.EstadoIteracion.INACTIVO).ToList();
            LstHistoria = dataContext.context.Historia.Where(x => x.ProyectoId == ProyectoId && x.Estado != ConstantHelpers.EstadoHistoria.INACTIVO).ToList();
        }
    }
}