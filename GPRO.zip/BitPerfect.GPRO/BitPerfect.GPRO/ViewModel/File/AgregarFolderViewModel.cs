using BitPerfect.GPRO.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Data.Entity;
using BitPerfect.GPRO.Controllers;
using BitPerfect.GPRO.Helpers;

namespace BitPerfect.GPRO.ViewModel.File
{
    public class AgregarFolderViewModel
    {
        public Int32? RecursoId { get; set; }
        
        [Required]
        public String Nombre { get; set; }
        
        public Int32? RecursoPadreId { get; set; }

        [Required]
        public Int32 UsuarioId { get; set; }

        public Proyecto Proyecto { get; set; }
        public Int32 ProyectoId { get; set; }

        public AgregarFolderViewModel()
        {

        }

        public void Fill(CargarDatosContext datacontext, Int32 usuarioId, Int32? recursoPadreId, Int32? recursoId)
        {
            ProyectoId = datacontext.session.GetProyectoId();
            if (ProyectoId != 0)
                Proyecto = datacontext.context.Proyecto.FirstOrDefault(x => x.ProyectoId == ProyectoId);

            RecursoId = recursoId;
            UsuarioId = usuarioId;
            RecursoPadreId = recursoPadreId;

            if (RecursoId.HasValue)
            {
                Recurso recurso = datacontext.context.Recurso.Find(recursoId);
                Nombre = recurso.Nombre;
                RecursoPadreId = recurso.RecursoPadreId;
            }
        }

        public void FillWithDefault(CargarDatosContext context)
        {
            Fill(context, UsuarioId, RecursoPadreId, RecursoId);
        }
    }
}