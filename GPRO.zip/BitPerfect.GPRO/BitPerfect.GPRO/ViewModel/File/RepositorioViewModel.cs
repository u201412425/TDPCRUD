using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Data.Entity;
using BitPerfect.GPRO.Models;
using BitPerfect.GPRO.Helpers;
using BitPerfect.GPRO.Controllers;

namespace BitPerfect.GPRO.ViewModel.File
{
    public class RepositorioViewModel
    {
        public Recurso Recurso;
        public List<Recurso> LstRecurso;
        public List<Recurso> LstRecursoPadre;
        public Int32? RecursoId { get; set; }

        public Proyecto Proyecto { get; set; }
        public Int32 ProyectoId { get; set; }

        public RepositorioViewModel()
        {
            LstRecurso = new List<Recurso>();
            LstRecursoPadre = new List<Recurso>(); 
        }

        public void Fill(CargarDatosContext datacontext, Int32? recursoId)
        {
            RecursoId = recursoId;
            
            ProyectoId = datacontext.session.GetProyectoId();
            if (ProyectoId != 0)
                Proyecto = datacontext.context.Proyecto.FirstOrDefault(x => x.ProyectoId == ProyectoId);

            Int32? RecursoPadreId = null;
            if (recursoId.HasValue)
            {
                Recurso = datacontext.context.Recurso.Find(recursoId);
                RecursoPadreId = Recurso.RecursoPadreId;
            }

            while (RecursoPadreId.HasValue)
            {
                Recurso recursoPadre = datacontext.context.Recurso.Where(x => x.ProyectoId == ProyectoId && x.RecursoId == RecursoPadreId).SingleOrDefault();
                RecursoPadreId = recursoPadre.RecursoPadreId;
                LstRecursoPadre.Insert(0,recursoPadre);
            }

            if (recursoId.HasValue)
                LstRecurso = datacontext.context.Recurso.Where(x => x.RecursoPadreId == recursoId && x.Estado == ConstantHelpers.Estado.ACTIVO && x.ProyectoId == ProyectoId).ToList();
            else
                LstRecurso = datacontext.context.Recurso.Where(x => x.RecursoPadreId == null && x.Estado == ConstantHelpers.Estado.ACTIVO && x.ProyectoId == ProyectoId).ToList();
        }
    }
}