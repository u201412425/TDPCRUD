﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using BitPerfect.GPRO.Models;
using BitPerfect.GPRO.Controllers;
using BitPerfect.GPRO.Helpers;
using System.ComponentModel.DataAnnotations;
using System.Data.Entity;

namespace BitPerfect.GPRO.ViewModel.Cuestionario
{
    public class EditCuestionarioViewModel
    {
        public Int32? CuestionarioId { get; set; }


        [Display(Name = "Nombre")]
        [Required(ErrorMessageResourceName = "CampoRequerido", ErrorMessageResourceType = typeof(i18n.ValidationStrings))]
        [StringLength(50, ErrorMessageResourceName = "LongitudMaxima", ErrorMessageResourceType = typeof(i18n.ValidationStrings))]
        public String Nombre { get; set; }

        [Display(Name = "Descripción")]
        [Required(ErrorMessageResourceName = "CampoRequerido", ErrorMessageResourceType = typeof(i18n.ValidationStrings))]
        [StringLength(50, ErrorMessageResourceName = "LongitudMaxima", ErrorMessageResourceType = typeof(i18n.ValidationStrings))]
        public String Descripcion { get; set; }

        [Display(Name = "Estado")]
        [Required(ErrorMessageResourceName = "CampoRequerido", ErrorMessageResourceType = typeof(i18n.ValidationStrings))]
        public String Estado { get; set; }
        public List<PreguntaCuestionario> LstPregunta { get; set; }
        public EditCuestionarioViewModel()
        {
        }

        public void CargarDatos(CargarDatosContext dataContext, Int32? cuestionarioId)
        {
            CuestionarioId = cuestionarioId;
            this.LstPregunta = new List<PreguntaCuestionario>();
            if (CuestionarioId.HasValue)
            {
                var Cuestionario = dataContext.context.Cuestionario.First(x => x.CuestionarioId == cuestionarioId);
                this.Estado = Cuestionario.Estado;
                this.Nombre = Cuestionario.Nombre;
                this.Descripcion = Cuestionario.Descripcion;
                if (Cuestionario.PreguntaCuestionario != null)
                {
                    this.LstPregunta = Cuestionario.PreguntaCuestionario.ToList();
                }
            }
            
        }
    }
}
