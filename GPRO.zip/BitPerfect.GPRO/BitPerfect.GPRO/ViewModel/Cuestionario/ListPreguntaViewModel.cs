﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using BitPerfect.GPRO.Controllers;
using BitPerfect.GPRO.Models;
using BitPerfect.GPRO.Helpers;
using System.Data.Entity;
using PagedList;

namespace BitPerfect.GPRO.ViewModel.Cuestionario
{
    public class ListPreguntaViewModel
    {
        public Int32 CuestionarioId { get; set; }

        public List<PreguntaCuestionario> LstPregunta { get; set; }

        public ListPreguntaViewModel() { }

        public void CargarDatos(CargarDatosContext dataContext, Int32 cuestionarioId)
        {
            CuestionarioId = cuestionarioId;
            LstPregunta = dataContext.context.PreguntaCuestionario.Where(x => x.CuestionarioId== cuestionarioId).Include(x => x.Usuario).OrderBy(x=>x.Orden).ToList();
        }
    }
}