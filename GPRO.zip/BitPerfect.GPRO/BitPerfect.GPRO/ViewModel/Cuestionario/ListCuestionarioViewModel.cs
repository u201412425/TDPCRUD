﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using ent = BitPerfect.GPRO.Models;
using BitPerfect.GPRO.Controllers;
using BitPerfect.GPRO.Helpers;
using System.Data.Entity;

namespace BitPerfect.GPRO.ViewModel.Cuestionario
{
    public class ListCuestionarioViewModel
    {
        public List<ent.Cuestionario> LstCuestionario { get; set; }

        public ListCuestionarioViewModel()
        {
            LstCuestionario = new List<ent.Cuestionario>();
        }

        public void CargarDatos(CargarDatosContext dataContext)
        {
            LstCuestionario = dataContext.context.Cuestionario.Include(x => x.Usuario).ToList();
        }
    }
}
