﻿using BitPerfect.GPRO.Controllers;
using BitPerfect.GPRO.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Data.Entity;


namespace BitPerfect.GPRO.ViewModel.Cuestionario
{
    public class EditPreguntaViewModel
    {
        public Int32? PreguntaCuestionarioId { get; set; }
        public Int32? CuestionarioId { get; set; }
        public bool EsMultiple { get; set; }
        public bool TieneCampoLibre { get; set; }

        [Display(Name = "Pregunta")]
        [Required(ErrorMessageResourceName = "CampoRequerido", ErrorMessageResourceType = typeof(i18n.ValidationStrings))]
        [StringLength(50, ErrorMessageResourceName = "LongitudMaxima", ErrorMessageResourceType = typeof(i18n.ValidationStrings))]
        public String Pregunta { get; set; }
        public String Estado { get; set; }
        [Display(Name = "Orden")]
        [Required(ErrorMessageResourceName = "CampoRequerido", ErrorMessageResourceType = typeof(i18n.ValidationStrings))]
        [StringLength(50, ErrorMessageResourceName = "LongitudMaxima", ErrorMessageResourceType = typeof(i18n.ValidationStrings))]
        public int Orden { get; set; }
        public List<OpcionCuestionario> LstOpcion { get; set; }
        public void CargarDatos(CargarDatosContext dataContext, Int32? preguntaCuestionarioId)
        {
            this.PreguntaCuestionarioId = preguntaCuestionarioId;
            this.LstOpcion = new List<OpcionCuestionario>();
            if (PreguntaCuestionarioId.HasValue)
            {
                var pregunta = dataContext.context.PreguntaCuestionario.Include(x => x.OpcionCuestionario).First(x => x.PreguntaCuestionarioId == preguntaCuestionarioId);
                this.Estado = pregunta.Estado;
                this.Pregunta = pregunta.Pregunta;
                this.Orden = pregunta.Orden;
                this.EsMultiple = (bool)pregunta.EsMultiple;
                this.TieneCampoLibre = (bool)pregunta.TieneCampoLibre;
                this.LstOpcion = pregunta.OpcionCuestionario.ToList();
            }
            else
            {
                var lista = dataContext.context.PreguntaCuestionario.Where(x => x.CuestionarioId == CuestionarioId).ToList();
                Int32 ultimo;
                if (lista.Count > 0)
                {
                    ultimo=lista.Max(x => x.Orden);
                }
                else
                {
                    ultimo = 0;
                }
                this.Orden = ultimo + 1;
            }
        }
    }
}