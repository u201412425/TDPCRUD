﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using BitPerfect.GPRO.Controllers;
using BitPerfect.GPRO.Models;
using BitPerfect.GPRO.Helpers;
using System.Data.Entity;
using PagedList;

namespace BitPerfect.GPRO.ViewModel.Widget
{
    public class BurndownChartViewModel
    {
        public Int32 ProyectoId { get; set; }
        public Int32? IteracionId { get; set; }
        public Int32? HistoriaId { get; set; }
        public String Titulo { get; set; }

        public BurndownChartViewModel() { }

        public void CargarDatos(CargarDatosContext dataContext, Int32 proyectoId, Int32? iteracionId, Int32? historiaId)
        {
            ProyectoId = proyectoId;
            IteracionId = iteracionId;
            HistoriaId = historiaId;

            Titulo = "";

            if (iteracionId.HasValue)
            {
                var iteracion = dataContext.context.Iteracion.Find(iteracionId);
                Titulo += iteracion.Codigo + " | " + iteracion.Nombre;
            }

            if (historiaId.HasValue)
            {
                var historia = dataContext.context.Historia.Find(historiaId);

                if (!String.IsNullOrEmpty(Titulo))
                    Titulo += " // ";
                Titulo += historia.Codigo + " | " + historia.Nombre;
            }

            if (String.IsNullOrEmpty(Titulo))
                Titulo = "Proyecto";

        }
    }
}