﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using BitPerfect.GPRO.Controllers;
using BitPerfect.GPRO.Models;
using BitPerfect.GPRO.Helpers;
using System.Data.Entity;
using PagedList;

namespace BitPerfect.GPRO.ViewModel.Widget
{
    public class ListArchivoViewModel
    {
        public Int32 Page { get; set; }
        public Int32 ObjetoId { get; set; }
        public String Objeto { get; set; }

        public IPagedList<Archivo> LstArchivo { get; set; }

        public ListArchivoViewModel() { }

        public void CargarDatos(CargarDatosContext dataContext, String objeto, Int32 objetoId, Int32? page)
        {
            Page = page ?? 1;
            Objeto = objeto;
            ObjetoId = objetoId;
            var queryArchivos = dataContext.context.Archivo.Include(x => x.Usuario).Where(x => x.Objeto == objeto && x.ObjetoId == objetoId && x.Estado == ConstantHelpers.Estado.ACTIVO).OrderByDescending(x => x.ArchivoId);
            LstArchivo = queryArchivos.ToPagedList(Page, 6);
        }
    }
}