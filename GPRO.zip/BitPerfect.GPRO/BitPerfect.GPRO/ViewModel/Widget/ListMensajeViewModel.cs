﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using BitPerfect.GPRO.Controllers;
using BitPerfect.GPRO.Models;
using BitPerfect.GPRO.Helpers;
using System.Data.Entity;
using PagedList;

namespace BitPerfect.GPRO.ViewModel.Widget
{
    public class ListMensajeViewModel
    {
        public Int32 Page { get; set; }
        public Int32 ObjetoId { get; set; }
        public String Objeto { get; set; }
        
        public IPagedList<Mensaje> LstMensaje { get; set; }

        public ListMensajeViewModel() { }

        public void CargarDatos(CargarDatosContext dataContext, String objeto, Int32 objetoId, Int32? page)
        {
            Page = page ?? 1;
            Objeto = objeto;
            ObjetoId = objetoId;
            var queryMensajes = dataContext.context.Mensaje.Include(x => x.Usuario).Where(x => x.Objeto == objeto && x.ObjetoId == objetoId && x.Estado == ConstantHelpers.Estado.ACTIVO).OrderByDescending(x=>x.MensajeId);
            LstMensaje = queryMensajes.ToPagedList(Page,6);
        }
    }
}