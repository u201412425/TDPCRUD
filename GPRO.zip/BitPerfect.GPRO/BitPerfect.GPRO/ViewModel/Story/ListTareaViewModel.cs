using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using BitPerfect.GPRO.Models;
using BitPerfect.GPRO.Controllers;
using BitPerfect.GPRO.Helpers;
using System.Data.Entity;

namespace BitPerfect.GPRO.ViewModel.Story
{
    public class ListTareaViewModel
    {
        public Int32 HistoriaId { get; set; }
        public List<Tarea> LstTarea { get; set; }

        public ListTareaViewModel()
        {
			LstTarea = new List<Tarea>();
        }

        public void CargarDatos(CargarDatosContext dataContext, Int32 historiaId)
        {
            HistoriaId = historiaId;
            LstTarea = dataContext.context.Tarea.Where(x=>x.HistoriaId == historiaId && x.Estado != ConstantHelpers.EstadoTarea.INACTIVO).ToList();
        }
    }
}
