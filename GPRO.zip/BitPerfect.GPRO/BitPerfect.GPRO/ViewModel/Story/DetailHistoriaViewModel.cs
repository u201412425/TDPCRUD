﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using BitPerfect.GPRO.Controllers;
using BitPerfect.GPRO.Models;
using BitPerfect.GPRO.Helpers;
using System.Data.Entity;
using PagedList;

namespace BitPerfect.GPRO.ViewModel.Story
{
    public class DetailHistoriaViewModel
    {
        public Int32 HistoriaId { get; set; }
        public Int32 IteracionId { get; set; }

        public Historia Historia { get; set; }
        public Iteracion Iteracion { get; set; }
        public HistoriaIteracion HistoriaIteracion { get; set; }

        public List<HistoriaIteracion> LstHistoriaIteracion { get; set; }
        public List<AvanceHistoria> LstAvanceHistoria { get; set; }
        public List<Tarea> LstTarea { get; set; }

        public DetailHistoriaViewModel() { }

        public void CargarDatos(CargarDatosContext dataContext, Int32 historiaId, Int32 iteracionId)
        {
            HistoriaId = historiaId;
            IteracionId = iteracionId;
            Historia = dataContext.context.Historia.Find(historiaId);
            Iteracion = dataContext.context.Iteracion.Find(iteracionId);
            HistoriaIteracion = dataContext.context.HistoriaIteracion.Include(x => x.Usuario).Include(x => x.Usuario1).First(x => x.HistoriaId == historiaId && x.IteracionId == iteracionId);
            LstAvanceHistoria = dataContext.context.AvanceHistoria.Include(x=>x.Usuario).Where(x => x.HistoriaId == HistoriaId).OrderByDescending(x=>x.AvanceHistoriaId).ToList();
            LstHistoriaIteracion = dataContext.context.HistoriaIteracion.Where(x => x.HistoriaId == HistoriaId).ToList();
            LstTarea = dataContext.context.Tarea.Include(x => x.Usuario).Include(x => x.Usuario1).Where(x => x.HistoriaId == historiaId && x.Estado != ConstantHelpers.EstadoTarea.INACTIVO).ToList();
        }
    }
}