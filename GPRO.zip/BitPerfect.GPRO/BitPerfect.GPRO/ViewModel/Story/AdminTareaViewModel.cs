using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using BitPerfect.GPRO.Models;
using BitPerfect.GPRO.Controllers;
using BitPerfect.GPRO.Helpers;
using System.ComponentModel.DataAnnotations;
using System.Data.Entity;


namespace BitPerfect.GPRO.ViewModel.Story
{
    public class AdminTareaViewModel
    {
        public Int32 HistoriaId { get; set; }
        public Int32? TareaId { get; set; }

        [Display(Name = "Nombre")]
        [Required(ErrorMessageResourceName = "CampoRequerido", ErrorMessageResourceType = typeof(i18n.ValidationStrings))]
        [StringLength(70, ErrorMessageResourceName = "LongitudMaxima", ErrorMessageResourceType = typeof(i18n.ValidationStrings))]
        public String Nombre { get; set; }

		[Display(Name = "Descripci�n")]
		[Required(ErrorMessageResourceName = "CampoRequerido", ErrorMessageResourceType = typeof(i18n.ValidationStrings))]
		public String Descripcion { get; set; }
        
        public List<Tarea> LstTarea { get; set; }

        public AdminTareaViewModel()
        {
        }

        public void CargarDatos(CargarDatosContext dataContext, Int32 historiaId, Int32? tareaId)
        {
            HistoriaId = historiaId;
            TareaId = tareaId;

            if (tareaId.HasValue)
            {
                var Tarea = dataContext.context.Tarea.First(x => x.TareaId == tareaId);
				this.Descripcion = Tarea.Descripcion;
				this.HistoriaId = Tarea.HistoriaId;
				this.Nombre = Tarea.Nombre;
            }

            LstTarea = dataContext.context.Tarea.Include(x => x.Usuario).Include(x => x.Usuario1).Where(x => x.HistoriaId == historiaId && x.Estado != ConstantHelpers.EstadoTarea.INACTIVO).ToList();
        }
    }
}
