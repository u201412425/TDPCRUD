﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using BitPerfect.GPRO.Controllers;
using BitPerfect.GPRO.Models;
using BitPerfect.GPRO.Helpers;
using System.Data.Entity;
using PagedList;

namespace BitPerfect.GPRO.ViewModel.Story
{
    public class AssignHistoriaViewModel
    {
        public Int32 HistoriaIteracionId { get; set; }
        public Int32 IteracionId { get; set; }
        public Int32 HistoriaId { get; set; }
        public String UrlReferrer { get; set; }

        public HistoriaIteracion HistoriaIteracion { get; set; }
        public List<UsuarioProyecto> LstUsuarioProyecto { get; set; }

        [Display(Name = "Usuario asignado")]
        [Required(ErrorMessageResourceName = "CampoRequerido", ErrorMessageResourceType = typeof(i18n.ValidationStrings))]
        public Int32? UsuarioAsignadoId { get; set; }

        public AssignHistoriaViewModel() { }

        public void CargarDatos(CargarDatosContext dataContext, Int32 historiaIteracionId)
        {
            HistoriaIteracionId = historiaIteracionId;
            HistoriaIteracion = dataContext.context.HistoriaIteracion.Include(x => x.Historia).Include(x => x.Iteracion).First(x => x.HistoriaIteracionId == historiaIteracionId);
            LstUsuarioProyecto = dataContext.context.UsuarioProyecto.Include(x => x.Usuario).Where(x => x.ProyectoId == HistoriaIteracion.Historia.ProyectoId)
                                                                                            .OrderBy(x => x.Usuario.Apellido).ThenBy(x => x.Usuario.Nombre).ToList();
            HistoriaId = HistoriaIteracion.HistoriaId;
            IteracionId = HistoriaIteracion.IteracionId;
        }
    }
}