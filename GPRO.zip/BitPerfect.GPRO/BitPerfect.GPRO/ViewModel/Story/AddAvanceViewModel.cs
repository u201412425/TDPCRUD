﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using BitPerfect.GPRO.Controllers;
using BitPerfect.GPRO.Models;
using BitPerfect.GPRO.Helpers;
using System.Data.Entity;
using PagedList;

namespace BitPerfect.GPRO.ViewModel.Story
{
    public class AddAvanceViewModel
    {
        public Int32 HistoriaIteracionId { get; set; }
        public Int32 IteracionId { get; set; }
        public Int32 HistoriaId { get; set; }

        public Historia Historia { get; set; }
        public Iteracion Iteracion { get; set; }
        public HistoriaIteracion HistoriaIteracion { get; set; }

        [Display(Name = "Tiempo")]
        [Required(ErrorMessageResourceName = "CampoRequerido", ErrorMessageResourceType = typeof(i18n.ValidationStrings))]
        [Range(1, Int32.MaxValue, ErrorMessageResourceName = "ValorMinimo", ErrorMessageResourceType = typeof(i18n.ValidationStrings))]
        public Int32? TiempoEfectivo { get; set; }

        [Display(Name = "Comentario")]
        [Required(ErrorMessageResourceName = "CampoRequerido", ErrorMessageResourceType = typeof(i18n.ValidationStrings))]
        public String Comentario { get; set; }

        [Display(Name = "Medida")]
        [Required(ErrorMessageResourceName = "CampoRequerido", ErrorMessageResourceType = typeof(i18n.ValidationStrings))]
        public String Medida { get; set; }

        public AddAvanceViewModel() { }

        public void CargarDatos(CargarDatosContext dataContext, Int32 historiaIteracionId)
        {
            HistoriaIteracionId = historiaIteracionId;
            HistoriaIteracion = dataContext.context.HistoriaIteracion.Include(x => x.Historia).Include(x => x.Iteracion).First(x => x.HistoriaIteracionId == historiaIteracionId);
            HistoriaId = HistoriaIteracion.HistoriaId;
            IteracionId = HistoriaIteracion.IteracionId;
            Historia = HistoriaIteracion.Historia;
            Iteracion = HistoriaIteracion.Iteracion;

        }
    }
}