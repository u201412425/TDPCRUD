using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using BitPerfect.GPRO.Models;
using BitPerfect.GPRO.Controllers;
using BitPerfect.GPRO.Helpers;
using System.ComponentModel.DataAnnotations;
using System.Data.Entity;

namespace BitPerfect.GPRO.ViewModel.Story
{
    public class EditHistoriaViewModel
    {
		public Int32? HistoriaId { get; set; }

		[Display(Name = "C�digo")]
		[Required(ErrorMessageResourceName = "CampoRequerido", ErrorMessageResourceType = typeof(i18n.ValidationStrings))]
        [StringLength(15, ErrorMessageResourceName = "LongitudMaxima", ErrorMessageResourceType = typeof(i18n.ValidationStrings))]
		public String Codigo { get; set; }

        [Display(Name = "Nombre")]
        [Required(ErrorMessageResourceName = "CampoRequerido", ErrorMessageResourceType = typeof(i18n.ValidationStrings))]
        [StringLength(70, ErrorMessageResourceName = "LongitudMaxima", ErrorMessageResourceType = typeof(i18n.ValidationStrings))]
        public String Nombre { get; set; }

		[Display(Name = "Descripci�n")]
		[Required(ErrorMessageResourceName = "CampoRequerido", ErrorMessageResourceType = typeof(i18n.ValidationStrings))]
        [DataType(DataType.MultilineText)]
		public String Descripcion { get; set; }

        [Display(Name = "Horas estimadas")]
        [Required(ErrorMessageResourceName = "CampoRequerido", ErrorMessageResourceType = typeof(i18n.ValidationStrings))]
        [Range(1,Int32.MaxValue,ErrorMessageResourceName = "ValorMinimo", ErrorMessageResourceType = typeof(i18n.ValidationStrings))]
        public Int32 HorasEstimadas { get; set; }

        public EditHistoriaViewModel()
        {
        }

        public void CargarDatos(CargarDatosContext dataContext, Int32? historiaId)
        {
            HistoriaId = historiaId;

            if (historiaId.HasValue)
            {
                var Historia = dataContext.context.Historia.First(x => x.HistoriaId == historiaId);
				this.Codigo = Historia.Codigo;
                this.Nombre = Historia.Nombre;
                this.Descripcion = Historia.Descripcion;
				this.HorasEstimadas = Historia.HorasEstimadas;
            }
        }
    }
}
