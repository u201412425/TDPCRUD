using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using BitPerfect.GPRO.Models;
using BitPerfect.GPRO.Controllers;
using BitPerfect.GPRO.Helpers;
using System.Data.Entity;

namespace BitPerfect.GPRO.ViewModel.Story
{
    public class ListHistoriaViewModel
    {
        public List<Historia> LstHistoria { get; set; }

        public ListHistoriaViewModel()
        {
			LstHistoria = new List<Historia>();
        }

        public void CargarDatos(CargarDatosContext dataContext)
        {
            var proyectoId = dataContext.session.GetProyectoId();
            LstHistoria = dataContext.context.Historia.Include(x => x.Usuario).Where(x => x.ProyectoId == proyectoId && x.Estado != ConstantHelpers.EstadoHistoria.INACTIVO).ToList();
        }
    }
}
