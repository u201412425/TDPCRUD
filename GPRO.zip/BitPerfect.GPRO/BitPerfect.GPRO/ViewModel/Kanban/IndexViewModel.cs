﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using BitPerfect.GPRO.Controllers;
using BitPerfect.GPRO.Models;
using BitPerfect.GPRO.Helpers;
using System.Data.Entity;
using PagedList;

namespace BitPerfect.GPRO.ViewModel.Kanban
{
    public class IndexViewModel
    {
        public Int32 IteracionId { get; set; }

        public Iteracion Iteracion { get; set; }

        public List<HistoriaIteracion> LstHistoriaIteracion { get; set; }

        public IndexViewModel() { }

        public void CargarDatos(CargarDatosContext dataContext, Int32 iteracionId)
        {
            var usuarioId = dataContext.session.GetUsuarioId();
            IteracionId = iteracionId;
            Iteracion = dataContext.context.Iteracion.Find(IteracionId);
            LstHistoriaIteracion = dataContext.context.HistoriaIteracion.Include(x=>x.Historia)
                                            .Where(x => x.IteracionId == IteracionId && x.Estado == ConstantHelpers.Estado.ACTIVO)
                                            .OrderBy(x => x.UsuarioAsignadoId != usuarioId).ThenBy(x => x.Historia.Codigo).ToList();
        }
    }
}