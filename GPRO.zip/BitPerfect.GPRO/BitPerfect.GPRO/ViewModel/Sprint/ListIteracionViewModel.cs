using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using BitPerfect.GPRO.Models;
using BitPerfect.GPRO.Controllers;
using BitPerfect.GPRO.Helpers;
using System.Data.Entity;

namespace BitPerfect.GPRO.ViewModel.Sprint
{
    public class ListIteracionViewModel
    {
        public List<Iteracion> LstIteracion { get; set; }

        public ListIteracionViewModel()
        {
			LstIteracion = new List<Iteracion>();
        }

        public void CargarDatos(CargarDatosContext dataContext)
        {
            var proyectoId = dataContext.session.GetProyectoId();
            LstIteracion = dataContext.context.Iteracion.Include(x => x.Usuario).Where(x => x.ProyectoId == proyectoId && x.Estado != ConstantHelpers.EstadoIteracion.INACTIVO).ToList();
        }
    }
}
