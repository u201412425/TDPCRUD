using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using BitPerfect.GPRO.Models;
using BitPerfect.GPRO.Controllers;
using BitPerfect.GPRO.Helpers;
using System.Data.Entity;


namespace BitPerfect.GPRO.ViewModel.Sprint
{
    public class ListHistoriaIteracionViewModel
    {
        public List<Iteracion> LstIteracion { get; set; }
        public List<HistoriaIteracion> LstHistoriaIteracion { get; set; }
        public Dictionary<Int32, UsuarioProyecto> DictUsuarioProyecto { get; set; }

        public ListHistoriaIteracionViewModel()
        {
            LstIteracion = new List<Iteracion>();
            LstHistoriaIteracion = new List<HistoriaIteracion>();
        }

        public void CargarDatos(CargarDatosContext dataContext)
        {
            var proyectoId = dataContext.session.GetProyectoId();

            LstIteracion = dataContext.context.Iteracion.Where(x => x.ProyectoId == proyectoId && x.Estado != ConstantHelpers.EstadoIteracion.INACTIVO).OrderBy(x => x.Codigo).ToList();
            LstHistoriaIteracion = dataContext.context.HistoriaIteracion.Include(x => x.Historia).Where(x => x.Iteracion.ProyectoId == proyectoId && x.Historia.ProyectoId == proyectoId && x.Historia.Estado != ConstantHelpers.EstadoHistoria.INACTIVO).OrderBy(x => x.Historia.Codigo).ToList();
            DictUsuarioProyecto = dataContext.context.UsuarioProyecto.Include(x=>x.Usuario).Where(x => x.ProyectoId == proyectoId).ToDictionary(x=>x.UsuarioId, x=>x);
        }
    }
}
