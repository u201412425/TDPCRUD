using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using BitPerfect.GPRO.Models;
using BitPerfect.GPRO.Controllers;
using BitPerfect.GPRO.Helpers;
using System.ComponentModel.DataAnnotations;
using System.Data.Entity;


namespace BitPerfect.GPRO.ViewModel.Sprint
{
    public class EditIteracionViewModel
    {
		public Int32? IteracionId { get; set; }

		[Display(Name = "C�digo")]
		[Required(ErrorMessageResourceName = "CampoRequerido", ErrorMessageResourceType = typeof(i18n.ValidationStrings))]
        [StringLength(15, ErrorMessageResourceName = "LongitudMaxima", ErrorMessageResourceType = typeof(i18n.ValidationStrings))]
		public String Codigo { get; set; }

        [Display(Name = "Nombre")]
        [Required(ErrorMessageResourceName = "CampoRequerido", ErrorMessageResourceType = typeof(i18n.ValidationStrings))]
        [StringLength(50, ErrorMessageResourceName = "LongitudMaxima", ErrorMessageResourceType = typeof(i18n.ValidationStrings))]
        public String Nombre { get; set; }

        [Display(Name = "Fecha de inicio")]
        [Required(ErrorMessageResourceName = "CampoRequerido", ErrorMessageResourceType = typeof(i18n.ValidationStrings))]
        public DateTime FechaInicio { get; set; }

        [Display(Name = "Fecha de fin")]
		[Required(ErrorMessageResourceName = "CampoRequerido", ErrorMessageResourceType = typeof(i18n.ValidationStrings))]
		public DateTime FechaFin { get; set; }

        public EditIteracionViewModel()
        {
        }

        public void CargarDatos(CargarDatosContext dataContext, Int32? iteracionId)
        {
            IteracionId = iteracionId;

            if (iteracionId.HasValue)
            {
                var Iteracion = dataContext.context.Iteracion.First(x => x.IteracionId == iteracionId);
				this.Codigo = Iteracion.Codigo;
				this.FechaFin = Iteracion.FechaFin;
				this.FechaInicio = Iteracion.FechaInicio;
				this.Nombre = Iteracion.Nombre;
            }
        }
    }
}
