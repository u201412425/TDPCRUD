using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using BitPerfect.GPRO.Models;
using BitPerfect.GPRO.Controllers;
using BitPerfect.GPRO.Helpers;
using System.ComponentModel.DataAnnotations;
using System.Data.Entity;

namespace BitPerfect.GPRO.ViewModel.Sprint
{
    public class AdminHistoriaIteracionViewModel
    {
        public Int32 IteracionId { get; set; }
        public Iteracion Iteracion { get; set; }

        public List<Historia> LstHistoria { get; set; }
        public List<UsuarioProyecto> LstUsuarioProyecto { get; set; }
        public Dictionary<Int32, HistoriaIteracion> DictHistoriaIteracion { get; set; }

        public List<Int32> LstHistoriaSeleccionadaId { get; set; }

        public AdminHistoriaIteracionViewModel()
        {
            LstHistoriaSeleccionadaId = new List<Int32>();
        }

        public void CargarDatos(CargarDatosContext dataContext, Int32 iteracionId)
        {
            var proyectoId = dataContext.session.GetProyectoId();
            IteracionId = iteracionId;

            Iteracion = dataContext.context.Iteracion.Find(iteracionId);
            DictHistoriaIteracion = dataContext.context.HistoriaIteracion.Include(x => x.Usuario1).Include(x => x.Usuario).Where(x => x.IteracionId == IteracionId).ToDictionary(x => x.HistoriaId, x => x);
			LstHistoria = dataContext.context.Historia.Where(x=>x.ProyectoId == proyectoId && x.Estado != ConstantHelpers.EstadoHistoria.APROBADO && x.Estado != ConstantHelpers.EstadoHistoria.INACTIVO)
                                                      .OrderBy(x=>x.Codigo).ToList();
            LstUsuarioProyecto = dataContext.context.UsuarioProyecto.Include(x => x.Usuario).Where(x => x.ProyectoId == proyectoId)
                                                                    .OrderBy(x => x.Usuario.Apellido).ThenBy(x => x.Usuario.Nombre).ToList();
        }
    }
}
