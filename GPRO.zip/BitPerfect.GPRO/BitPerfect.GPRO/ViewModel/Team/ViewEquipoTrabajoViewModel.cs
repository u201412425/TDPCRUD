﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using BitPerfect.GPRO.Controllers;
using BitPerfect.GPRO.Models;
using BitPerfect.GPRO.Helpers;
using System.Data.Entity;
using PagedList;

namespace BitPerfect.GPRO.ViewModel.Kanban
{
    public class ViewEquipoTrabajoViewModel
    {
        public List<UsuarioProyecto> LstUsuarioProyecto { get; set; }

        public ViewEquipoTrabajoViewModel() { }

        public void CargarDatos(CargarDatosContext dataContext)
        {
            var proyectoId = dataContext.session.GetProyectoId();

            LstUsuarioProyecto = dataContext.context.UsuarioProyecto.Include(x => x.Usuario).Where(x => x.ProyectoId == proyectoId)
                                            .OrderBy(x=>x.Usuario.Apellido).ThenBy(x=>x.Usuario.Nombre).ToList();
        }
    }
}