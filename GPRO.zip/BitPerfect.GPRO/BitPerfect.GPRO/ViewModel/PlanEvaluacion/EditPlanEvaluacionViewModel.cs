﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using BitPerfect.GPRO.Models;
using BitPerfect.GPRO.Controllers;
using BitPerfect.GPRO.Helpers;
using System.ComponentModel.DataAnnotations;
using System.Data.Entity;

namespace BitPerfect.GPRO.ViewModel.PlanEvaluacion
{
    public class EditPlanEvaluacionViewModel
    {
        public Int32? PlanEvaluacionId { get; set; }


        [Display(Name = "Nombre")]
        [Required(ErrorMessageResourceName = "CampoRequerido", ErrorMessageResourceType = typeof(i18n.ValidationStrings))]
        [StringLength(50, ErrorMessageResourceName = "LongitudMaxima", ErrorMessageResourceType = typeof(i18n.ValidationStrings))]
        public String Nombre { get; set; }

        [Display(Name = "Estado")]
        [Required(ErrorMessageResourceName = "CampoRequerido", ErrorMessageResourceType = typeof(i18n.ValidationStrings))]
        public String Estado { get; set; }
        public EditPlanEvaluacionViewModel()
        {
        }

        public void CargarDatos(CargarDatosContext dataContext, Int32? planEvaluacionId)
        {
            PlanEvaluacionId = planEvaluacionId;
            if (PlanEvaluacionId.HasValue)
            {
                var PlanEvaluacion = dataContext.context.PlanEvaluacion.First(x => x.PlanEvaluacionId == planEvaluacionId);
                this.Estado = PlanEvaluacion.Estado;
                this.Nombre = PlanEvaluacion.Nombre;
            }

        }
    }
}
