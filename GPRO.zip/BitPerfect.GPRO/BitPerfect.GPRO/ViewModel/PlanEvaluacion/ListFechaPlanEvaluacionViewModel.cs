﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using BitPerfect.GPRO.Controllers;
using BitPerfect.GPRO.Models;
using BitPerfect.GPRO.Helpers;
using System.Data.Entity;
using PagedList;

namespace BitPerfect.GPRO.ViewModel.PlanEvaluacion
{
    public class ListFechaPlanEvaluacionViewModel
    {
        public Int32 PlanEvaluacionId { get; set; }

        public List<FechaPlanEvaluacion> LstFechaPlanEvaluacion { get; set; }

        public ListFechaPlanEvaluacionViewModel() { }

        public void CargarDatos(CargarDatosContext dataContext, Int32 planEvaluacionId)
        {
            PlanEvaluacionId = planEvaluacionId;
            LstFechaPlanEvaluacion = dataContext.context.FechaPlanEvaluacion.Where(x => x.PlanEvaluacionId == PlanEvaluacionId).Include(x => x.Usuario).ToList();
        }
    }
}