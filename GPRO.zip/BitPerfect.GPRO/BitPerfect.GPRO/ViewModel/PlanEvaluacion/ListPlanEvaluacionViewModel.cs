﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using ent = BitPerfect.GPRO.Models;
using BitPerfect.GPRO.Controllers;
using BitPerfect.GPRO.Helpers;
using System.Data.Entity;

namespace BitPerfect.GPRO.ViewModel.PlanEvaluacion
{
    public class ListPlanEvaluacionViewModel
    {
        public List<ent.PlanEvaluacion> LstPlanEvaluacion { get; set; }

        public ListPlanEvaluacionViewModel()
        {
            LstPlanEvaluacion = new List<ent.PlanEvaluacion>();
        }

        public void CargarDatos(CargarDatosContext dataContext)
        {
            LstPlanEvaluacion = dataContext.context.PlanEvaluacion.Include(x => x.Usuario).ToList();
        }
    }
}
