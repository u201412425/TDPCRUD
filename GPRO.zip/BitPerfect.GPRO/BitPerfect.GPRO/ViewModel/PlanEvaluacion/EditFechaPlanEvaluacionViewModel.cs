﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using BitPerfect.GPRO.Models;
using BitPerfect.GPRO.Controllers;
using BitPerfect.GPRO.Helpers;
using System.ComponentModel.DataAnnotations;
using System.Data.Entity;

namespace BitPerfect.GPRO.ViewModel.PlanEvaluacion
{
    public class EditFechaPlanEvaluacionViewModel
    {
        public Int32? FechaPlanEvaluacionId { get; set; }

        public Int32 PlanEvaluacionId { get; set; }

        [Display(Name = "Nombre")]
        [Required(ErrorMessageResourceName = "CampoRequerido", ErrorMessageResourceType = typeof(i18n.ValidationStrings))]
        [StringLength(50, ErrorMessageResourceName = "LongitudMaxima", ErrorMessageResourceType = typeof(i18n.ValidationStrings))]
        public String Nombre { get; set; }

        [Display(Name = "Fecha de Inicio")]
        [Required(ErrorMessageResourceName = "CampoRequerido", ErrorMessageResourceType = typeof(i18n.ValidationStrings))]
        public DateTime FechaInicio { get; set; }
        [Display(Name = "Fecha de Fin")]
        [Required(ErrorMessageResourceName = "CampoRequerido", ErrorMessageResourceType = typeof(i18n.ValidationStrings))]
        public DateTime FechaFin { get; set; }
        [Display(Name = "Estado")]
        [Required(ErrorMessageResourceName = "CampoRequerido", ErrorMessageResourceType = typeof(i18n.ValidationStrings))]
        public String Estado { get; set; }
        public EditFechaPlanEvaluacionViewModel()
        {
        }

        public void CargarDatos(CargarDatosContext dataContext, Int32? fechaPlanEvaluacionId)
        {
            FechaPlanEvaluacionId = fechaPlanEvaluacionId;
            if (FechaPlanEvaluacionId.HasValue)
            {
                var FechaPlanEvaluacion = dataContext.context.FechaPlanEvaluacion.First(x => x.FechaPlanEvaluacionId== fechaPlanEvaluacionId);
                this.Nombre = FechaPlanEvaluacion.Nombre;
                this.FechaInicio = FechaPlanEvaluacion.FechaInicio;
                this.FechaFin = FechaPlanEvaluacion.FechaFin;
                this.PlanEvaluacionId = FechaPlanEvaluacion.PlanEvaluacionId;
                this.Estado = FechaPlanEvaluacion.Estado;
            }

        }
    }
}
