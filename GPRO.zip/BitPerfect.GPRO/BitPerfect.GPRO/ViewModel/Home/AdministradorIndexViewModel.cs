using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using BitPerfect.GPRO.Models;
using BitPerfect.GPRO.Controllers;
using BitPerfect.GPRO.Helpers;

namespace BitPerfect.GPRO.ViewModel.Home
{
    public class AdministradorIndexViewModel
    {
        public Int32 NroUsuario { get; set; }
        public Int32 NroVendedor { get; set; }
        public Int32 NroTransportista { get; set; }
        public Int32 NroCliente { get; set; }
        
        public AdministradorIndexViewModel()
        {
        }

        public void CargarDatos(CargarDatosContext dataContext)
        {
          /*  NroUsuario = dataContext.context.Usuario.Count();
            NroVendedor = dataContext.context.Vendedor.Count();
            NroTransportista = dataContext.context.Transportista.Count();
            NroCliente = dataContext.context.Cliente.Count();*/
        }
    }
}