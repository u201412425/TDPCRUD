using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using BitPerfect.GPRO.Models;
using BitPerfect.GPRO.Controllers;
using BitPerfect.GPRO.Helpers;

namespace BitPerfect.GPRO.ViewModel.Home
{
    public class UsuarioIndexViewModel
    {
        public Int32 NroIteraciones { get; set; }
        public Int32 NroHistorias { get; set; }
        public Int32 NroIteracionesFinalizadas { get; set; }
        public Int32 NroHistoriasDiseno { get; set; }
        public Int32 NroHistoriasEnProgreso { get; set; }
        public Int32 NroHistoriasPendiente { get; set; }
        public Int32 NroHistoriasFinalizado { get; set; }
        public Int32 NroHistoriasAprobado { get; set; }

        public UsuarioIndexViewModel()
        {
        }

        public void CargarDatos(CargarDatosContext dataContext)
        {
            var proyectoId = dataContext.session.GetProyectoId();

            NroIteraciones = dataContext.context.Iteracion.Count(x => x.ProyectoId == proyectoId && x.Estado != ConstantHelpers.EstadoIteracion.INACTIVO);
            NroIteracionesFinalizadas = dataContext.context.Iteracion.Count(x => x.ProyectoId == proyectoId && x.Estado == ConstantHelpers.EstadoIteracion.FINALIZADO);
            NroHistorias = dataContext.context.Historia.Count(x => x.ProyectoId == proyectoId && x.Estado != ConstantHelpers.EstadoHistoria.INACTIVO);
            NroHistoriasDiseno = dataContext.context.Historia.Count(x => x.ProyectoId == proyectoId && x.Estado == ConstantHelpers.EstadoHistoria.DISENO);
            NroHistoriasEnProgreso = dataContext.context.Historia.Count(x => x.ProyectoId == proyectoId && x.Estado == ConstantHelpers.EstadoHistoria.EN_PROGRESO);
            NroHistoriasPendiente = dataContext.context.Historia.Count(x => x.ProyectoId == proyectoId && x.Estado == ConstantHelpers.EstadoHistoria.PENDIENTE);
            NroHistoriasFinalizado = dataContext.context.Historia.Count(x => x.ProyectoId == proyectoId && x.Estado == ConstantHelpers.EstadoHistoria.FINALIZADO);
            NroHistoriasAprobado = dataContext.context.Historia.Count(x => x.ProyectoId == proyectoId && x.Estado == ConstantHelpers.EstadoHistoria.APROBADO);

          /*  NroVentasMostrador = dataContext.context.VentasMostrador.Count(x => x.Fecha.Year == _ffecha.Year && x.Fecha.Month == _ffecha.Month && x.Fecha.Day == _ffecha.Day && x.CajaDiarioId == id);
            NroCobranzaVendedor = dataContext.context.Cobranza.Count(x => x.Fecha.Year == _ffecha.Year && x.Fecha.Month == _ffecha.Month && x.Fecha.Day == _ffecha.Day && x.CajaDiarioId == id);
            NroCobranzaTransportista = dataContext.context.VentasTransportista.Count(x => x.Fecha.Year == _ffecha.Year && x.Fecha.Month == _ffecha.Month && x.Fecha.Day == _ffecha.Day && x.CajaDiarioId == id);
            NroPagoNoEfectivo = dataContext.context.PagoNoEfectivo.Count(x => x.Fecha.Year == _ffecha.Year && x.Fecha.Month == _ffecha.Month && x.Fecha.Day == _ffecha.Day && x.CajaDiarioId == id);
            NroContadoPendiente = dataContext.context.HistorialContadoPendiente.Count(x => x.Fecha.Year == _ffecha.Year && x.Fecha.Month == _ffecha.Month && x.Fecha.Day == _ffecha.Day && x.CajaDiarioId == id);
           * */
        }
    }
}