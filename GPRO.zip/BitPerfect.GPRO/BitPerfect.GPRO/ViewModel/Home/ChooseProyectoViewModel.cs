﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using BitPerfect.GPRO.Controllers;
using BitPerfect.GPRO.Models;
using BitPerfect.GPRO.Helpers;
using System.Data.Entity;

namespace BitPerfect.GPRO.ViewModel.Home
{
    public class ChooseProyectoViewModel
    {
        public Int32? CajaDiarioId { get; set; }

        public List<UsuarioProyecto> LstUsuarioProyecto { get; set; }

        public ChooseProyectoViewModel() { }

        public void CargarDatos(CargarDatosContext dataContext)
        {
            var usuarioId = dataContext.session.GetUsuarioId();
            LstUsuarioProyecto = dataContext.context.UsuarioProyecto.Include(x => x.Proyecto).Where(x => x.UsuarioId == usuarioId).ToList();
        }
    }
}