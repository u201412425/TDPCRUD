using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BitPerfect.GPRO.ViewModel.Home
{
    public class LoginViewModel
    {
        public String Codigo { get; set; }
        public String Contrasena { get; set; }
    }
}