﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using BitPerfect.GPRO.Controllers;
using ent = BitPerfect.GPRO.Models;
using System.Data.Entity;

namespace BitPerfect.GPRO.ViewModel.Revision
{
    public class VerRespuestaViewModel
    {
        public List<Int32> LstOpcionSeleccionadoId { get; set; }
        public bool Aprueba { get; set; }
        public Int32? EvaluacionId { get; set; }
        public Dictionary<string, string> DictEvaluacion { get; set; }
        public List<ent.PreguntaCuestionario> ListaPregunta { get; set; }
        public VerRespuestaViewModel()
        {
            LstOpcionSeleccionadoId = new List<Int32>();
            DictEvaluacion = new Dictionary<string, string>();
        }
        public void CargarDatos(CargarDatosContext cargarDatosContext,int? evaluacionId,int? cuestionarioId)
        {
            var preguntas = cargarDatosContext.context.PreguntaCuestionario.Include(x => x.OpcionCuestionario).Where(x => x.CuestionarioId == cuestionarioId && x.Estado == "ACT").OrderBy(x => x.Orden).ToList();
            this.ListaPregunta = preguntas; 
            if (evaluacionId.HasValue)
            {
                this.EvaluacionId = evaluacionId;
                var ctx = cargarDatosContext.context;
                this.Aprueba = ctx.Evaluacion.Where(x => x.EvaluacionId == EvaluacionId).FirstOrDefault().Aprueba;
                this.DictEvaluacion = (from ev in ctx.Evaluacion
                                       join er in ctx.EvaluacionRespuesta on ev.EvaluacionId equals er.EvaluacionId
                                       join eo in ctx.EvaluacionOpcion on er.EvaluacionRespuestaId equals eo.EvaluacionRespuestaId
                                       where ev.EvaluacionId == EvaluacionId
                                       select new
                                       {
                                           Key = "PR-" + er.PreguntaCuestionarioId + "-OP-" + eo.OpcionCuestionarioId,
                                           Value = "checked"
                                       }).ToDictionary(x => x.Key, x => x.Value);
                var DictRespuestasLibres = (from ev in ctx.Evaluacion
                                            join er in ctx.EvaluacionRespuesta on ev.EvaluacionId equals er.EvaluacionId
                                            where ev.EvaluacionId == EvaluacionId && !String.IsNullOrEmpty(er.RespuestaCampoLibre)
                                            select new
                                            {
                                                Key = "TXT-" + er.PreguntaCuestionarioId,
                                                Value = er.RespuestaCampoLibre
                                            }).ToDictionary(x => x.Key, x => x.Value);
                foreach (var item in DictRespuestasLibres)
                {
                    this.DictEvaluacion.Add(item.Key, item.Value);
                }
            }
        }
    }
}