﻿using BitPerfect.GPRO.Controllers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using ent = BitPerfect.GPRO.Models;
using System.Data.Entity;

namespace BitPerfect.GPRO.ViewModel.Revision
{
    public class RevisionEvaluadorViewModel
    {
        public List<ent.EvaluacionProyecto> ListEvaluacionProyecto { get; set; }
        public void CargarDatos(CargarDatosContext dataContext,int? ProyectoId)
        {
            var ctx = dataContext.context;
            var ListProyectoEvaluacion = ctx.EvaluacionProyecto.Include(x => x.PlanEvaluacion.FechaPlanEvaluacion).Include(x => x.PlanEvaluacion.FechaPlanEvaluacion.Select(t=>t.Evaluacion)).Where(x => x.ProyectoId == ProyectoId).ToList();
            var a = ctx.FechaPlanEvaluacion.Include(y => y.Evaluacion);
        }
    }
}