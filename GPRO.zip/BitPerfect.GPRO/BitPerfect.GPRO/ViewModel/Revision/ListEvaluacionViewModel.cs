﻿using BitPerfect.GPRO.Controllers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.Entity;
using System.Web;
using ent = BitPerfect.GPRO.Models;

namespace BitPerfect.GPRO.ViewModel.Revision
{
    public class Estado
    {
        public string Descripcion { get; set; }
        public int Value { get; set; }
        public Estado(string descripcion, int value)
        {
            this.Descripcion = Descripcion;
            this.Value = value;
        }
    }
    public class EvaluacionItem
    {
        public DateTime FechInicio { get; set; }
        public DateTime FechaFin { get; set; }
        public string Cuestionario { get; set; }
        public string Proyecto { get; set; }
        public int? FechaPlanEvaluacionId { get; set; }
        public int? EvaluacionProyectoId { get; set; }
        public int? CuestionarioId { get; internal set; }
        public string Estado { get; set; }
        public int? EvaluacionId { get; set; }
        public string Evaluador { get; set; }
        public string RolEvaluador { get; set; }
        public string FechaPlanEvaluacion { get; set; }
    }
    public class ListEvaluacionViewModel
    {
        public List<EvaluacionItem> LstEvaluaciones { get; set; }
        public List<ent.Usuario> LstEvaluador { get; set; }
        public List<ent.Proyecto> LstProyecto { get; set; }
        public List<Estado> LstEstado { get; set; }
        public Int32? UsuarioId{ get; set; }
        public Int32? ProyectoId { get; set; }
        public Int32? Estado { get; set; }
        public ListEvaluacionViewModel()
        {
            this.LstEstado = new List<Revision.Estado>();
        }
        public void CargarDatos(CargarDatosContext dataContext)
        {
            var ctx = dataContext.context;
            this.LstEvaluador =  ctx.Usuario.ToList();
            this.LstProyecto = ctx.Proyecto.ToList();
            this.LstEstado.Add(new Estado("Respondido-Todos",1));
            this.LstEstado.Add(new Estado("Respondido-Aprobado", 2));
            this.LstEstado.Add(new Estado("Respondido-Rechazado", 3));
            this.LstEstado.Add(new Estado("Sin Responder-Todos", 4));
            this.LstEstado.Add(new Estado("Sin Responder-Futuras", 5));
            this.LstEstado.Add(new Estado("Sin Responder-En Curso", 6));
            this.LstEstado.Add(new Estado("Sin Responder-Fuera de fecha", 7));
            DateTime fechaActual = DateTime.Now;
            DateTime fechaActualFin = DateTime.Now.AddDays(-1);
            this.LstEvaluaciones = (from ep in ctx.EvaluacionProyecto
                                     join cu in ctx.Cuestionario on ep.CuestionarioId equals cu.CuestionarioId
                                     join pe in ctx.PlanEvaluacion on ep.PlanEvaluacionId equals pe.PlanEvaluacionId
                                     join fp in ctx.FechaPlanEvaluacion on pe.PlanEvaluacionId equals fp.PlanEvaluacionId
                                     join us in ctx.Usuario on ep.UsuarioAsignadoId equals us.UsuarioId
                                     join pro in ctx.Proyecto on ep.ProyectoId equals pro.ProyectoId
                                     from ev in ctx.Evaluacion.Where(c => c.UsuarioId == ep.UsuarioAsignadoId).DefaultIfEmpty()
                                     where (ep.UsuarioAsignadoId == UsuarioId || UsuarioId==null) && (ep.ProyectoId == ProyectoId || ProyectoId==null) 
                                     && (Estado == null || 
                                     (Estado == 1 ? ev.EvaluacionProyectoId == ep.EvaluacionProyectoId :
                                     Estado == 2 ? ev.Aprueba: 
                                     Estado == 3 ? !ev.Aprueba : 
                                     Estado == 4 ? ev.EvaluacionProyectoId != ep.EvaluacionProyectoId :
                                     Estado == 5 ? fp.FechaInicio > fechaActual :
                                     Estado == 6 ? (fp.FechaInicio <= fechaActual && fp.FechaFin >= fechaActualFin) :
                                     Estado == 7 ? fp.FechaFin > fechaActualFin :
                                     false
                                     ))
                                     select new EvaluacionItem
                                     {
                                         Cuestionario = cu.Nombre,
                                         FechInicio = fp.FechaInicio,
                                         FechaFin = fp.FechaFin,
                                         Proyecto = pro.Nombre,
                                         EvaluacionProyectoId = ep.EvaluacionProyectoId,
                                         FechaPlanEvaluacionId = fp.FechaPlanEvaluacionId,
                                         Evaluador = us.Nombre+" "+us.Apellido ,
                                         CuestionarioId = cu.CuestionarioId,
                                         EvaluacionId = ev != null ? ev.EvaluacionId : default(int?)
                                     }).ToList();
            this.LstEvaluaciones = LstEvaluaciones.OrderBy(x => x.Proyecto).ThenBy(x => x.Evaluador).ThenByDescending(x => x.FechInicio).ToList();
        }
        public string DeterminarEstado(int? evaluacionId,bool? aprueba,DateTime? fechaInicio,DateTime? fechaFin)
        {
            string Estado = "";
            DateTime fechaActual = DateTime.Now;
            DateTime fechaActualFin = DateTime.Now.AddDays(-1);
            if (evaluacionId.HasValue)
            {
                if (aprueba.Value)
                {
                    Estado = "Aprobado";
                }
                else
                {
                    Estado = "Desaprobado";
                }
            }
            else
            {
                if(fechaInicio > fechaActual)
                {
                    Estado = "Futura";
                }
                else if (fechaInicio <= fechaActual && fechaFin >= fechaActualFin)
                {
                    Estado = "En curso";
                }
                else
                {
                    Estado = "Fuera de fecha";
                }
            }
            return Estado;
        }
    }
}