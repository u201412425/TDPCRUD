﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using BitPerfect.GPRO.Controllers;
using ent=BitPerfect.GPRO.Models;
using BitPerfect.GPRO.Helpers;
using System.Data.Entity;
using PagedList;


namespace BitPerfect.GPRO.ViewModel.Evaluacion
{
    public class EvaluacionItem
    {
        public DateTime FechInicio { get; set; }
        public DateTime FechaFin { get; set; }
        public string Cuestionario { get; set; }
        public string Proyecto { get; set; }
        public int? FechaPlanEvaluacionId { get; set; }
        public int? EvaluacionProyectoId { get; set; }
        public int? CuestionarioId { get; internal set; }
        public string Estado { get; set; }
        public int? EvaluacionId { get; set; }
    }
    public class ListEvaluacionViewModel
    {

        public List<EvaluacionItem> ListEvaluacionesPendientes { get; set; }

        public ListEvaluacionViewModel() { }

        public void CargarDatos(CargarDatosContext dataContext, Int32 usuarioId)
        {
            var ctx = dataContext.context;
            var fechaActual = DateTime.Now;
            var fechaActualFinCompare = fechaActual.AddDays(-1);
            this.ListEvaluacionesPendientes = (from ep in ctx.EvaluacionProyecto
                                               join cu in ctx.Cuestionario on ep.CuestionarioId equals cu.CuestionarioId
                                               join pe in ctx.PlanEvaluacion on ep.PlanEvaluacionId equals pe.PlanEvaluacionId
                                               join fp in ctx.FechaPlanEvaluacion on pe.PlanEvaluacionId equals fp.PlanEvaluacionId
                                               join pro in ctx.Proyecto on ep.ProyectoId equals pro.ProyectoId
                                               from ev in ctx.Evaluacion.Where(c => c.UsuarioId == ep.UsuarioAsignadoId).DefaultIfEmpty()
                                               where ep.UsuarioAsignadoId == usuarioId && fp.FechaInicio <= fechaActual
                                               select new EvaluacionItem
                                               {
                                                   Cuestionario = cu.Nombre,
                                                   FechInicio = fp.FechaInicio,
                                                   FechaFin = fp.FechaFin,
                                                   Proyecto = pro.Nombre,
                                                   EvaluacionProyectoId = ep.EvaluacionProyectoId,
                                                   FechaPlanEvaluacionId = fp.FechaPlanEvaluacionId,
                                                   CuestionarioId = cu.CuestionarioId,
                                                   Estado = ev.EvaluacionProyectoId== ep.EvaluacionProyectoId ? "COMPLETADO": (fp.FechaFin>= fechaActualFinCompare?"PENDIENTE": "FUERA DE TIEMPO"),
                                                   EvaluacionId = ev != null ? ev.EvaluacionId: default(int?)
                                               }).ToList();
            this.ListEvaluacionesPendientes = ListEvaluacionesPendientes.OrderByDescending(x => x.FechaFin).ToList();
        }
    }
}