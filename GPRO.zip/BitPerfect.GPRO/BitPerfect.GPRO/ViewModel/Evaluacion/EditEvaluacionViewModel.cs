﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using BitPerfect.GPRO.Controllers;
using ent = BitPerfect.GPRO.Models;
using System.Data.Entity;

namespace BitPerfect.GPRO.ViewModel.Evaluacion
{
    public class EditEvaluacionViewModel
    {
        public ent.Cuestionario Cuestionario { get; set; }
        public ent.Proyecto Proyecto { get; set; }
        public List<Int32> LstOpcionSeleccionadoId { get; set; }
        public List<ent.PreguntaCuestionario> ListaPregunta { get; set; }
        public Int32 FechaPlanEvaluacionId { get; set; }
        public Int32 EvaluacionProyectoId { get; set; }
        public Int32 UsuarioId { get; set; }
        public Int32 CuestionarioId { get; set; }
        public bool Aprueba { get; set; }
        public Int32? EvaluacionId { get; set; }
        public Dictionary<string, string> DictEvaluacion { get; set; }
        public EditEvaluacionViewModel()
        {
            LstOpcionSeleccionadoId = new List<Int32>();
            DictEvaluacion = new Dictionary<string, string>();
        }
        public void CargarDatos(CargarDatosContext cargarDatosContext, int usuarioId, int evaluacionProyectoId, int fechaPlanEvaluacionId,int CuestionarioId,Int32? evaluacionId)
        {
            this.FechaPlanEvaluacionId = fechaPlanEvaluacionId;
            this.EvaluacionProyectoId = evaluacionProyectoId;
            this.UsuarioId = usuarioId;
            this.Proyecto = cargarDatosContext.context.EvaluacionProyecto.Include(x=>x.Proyecto).Where(x => x.EvaluacionProyectoId == EvaluacionProyectoId).FirstOrDefault().Proyecto;
            this.Cuestionario = cargarDatosContext.context.Cuestionario.Where(x => x.CuestionarioId == CuestionarioId).FirstOrDefault();
            var preguntas = cargarDatosContext.context.PreguntaCuestionario.Include(x => x.OpcionCuestionario).Where(x => x.CuestionarioId == CuestionarioId && x.Estado=="ACT").OrderBy(x => x.Orden).ToList();
            this.ListaPregunta = preguntas;
            if (evaluacionId.HasValue)
            {
                this.EvaluacionId = evaluacionId;
                var ctx = cargarDatosContext.context;
                this.Aprueba = ctx.Evaluacion.Where(x => x.EvaluacionId == EvaluacionId).FirstOrDefault().Aprueba;
                this.DictEvaluacion = (from ev in ctx.Evaluacion 
                                 join er in ctx.EvaluacionRespuesta on ev.EvaluacionId equals er.EvaluacionId
                                 join eo in ctx.EvaluacionOpcion on er.EvaluacionRespuestaId equals eo.EvaluacionRespuestaId
                                 where ev.EvaluacionId == EvaluacionId && ev.FechaPlanEvaluacionId==FechaPlanEvaluacionId &&
                                 ev.UsuarioId == UsuarioId && ev.EvaluacionProyectoId==EvaluacionProyectoId
                                 select new 
                                 {
                                     Key = "PR-"+er.PreguntaCuestionarioId+"-OP-"+eo.OpcionCuestionarioId,
                                     Value = "checked"
                                 }).ToDictionary(x=>x.Key,x=>x.Value);
                var DictRespuestasLibres = (from ev in ctx.Evaluacion
                                       join er in ctx.EvaluacionRespuesta on ev.EvaluacionId equals er.EvaluacionId
                                       where ev.EvaluacionId == EvaluacionId && ev.FechaPlanEvaluacionId == FechaPlanEvaluacionId &&
                                       ev.UsuarioId == UsuarioId && ev.EvaluacionProyectoId == EvaluacionProyectoId && !String.IsNullOrEmpty(er.RespuestaCampoLibre)
                                       select new
                                       {
                                           Key = "TXT-" + er.PreguntaCuestionarioId,
                                           Value = er.RespuestaCampoLibre
                                       }).ToDictionary(x => x.Key, x => x.Value);
                foreach(var item in DictRespuestasLibres)
                {
                    this.DictEvaluacion.Add(item.Key, item.Value);
                }
            }
        }
    }
}