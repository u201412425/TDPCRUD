using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using BitPerfect.GPRO.Models;
using BitPerfect.GPRO.Controllers;
using BitPerfect.GPRO.Helpers;
using System.Data.Entity;

namespace BitPerfect.GPRO.ViewModel.Project
{
    public class ListProyectoViewModel
    {
        public List<Proyecto> LstProyecto { get; set; }

        public ListProyectoViewModel()
        {
            LstProyecto = new List<Proyecto>();
        }

        public void CargarDatos(CargarDatosContext dataContext)
        {
            var proyectoId = dataContext.session.GetProyectoId();
            LstProyecto = dataContext.context.Proyecto.Include(x=>x.Usuario).OrderBy(x=>x.Nombre).ToList();
        }
    }
}
