using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using BitPerfect.GPRO.Models;
using BitPerfect.GPRO.Controllers;
using BitPerfect.GPRO.Helpers;
using System.ComponentModel.DataAnnotations;
using System.Data.Entity;


namespace BitPerfect.GPRO.ViewModel.Project
{
    public class EditProyectoViewModel
    {
        public Int32? ProyectoId { get; set; }

		[Display(Name = "C�digo")]
		[Required(ErrorMessageResourceName = "CampoRequerido", ErrorMessageResourceType = typeof(i18n.ValidationStrings))]
        [StringLength(10, ErrorMessageResourceName = "LongitudMaxima", ErrorMessageResourceType = typeof(i18n.ValidationStrings))]
		public String Codigo { get; set; }

        [Display(Name = "Nombre")]
        [Required(ErrorMessageResourceName = "CampoRequerido", ErrorMessageResourceType = typeof(i18n.ValidationStrings))]
        [StringLength(50, ErrorMessageResourceName = "LongitudMaxima", ErrorMessageResourceType = typeof(i18n.ValidationStrings))]
        public String Nombre { get; set; }

        [Display(Name = "Estado")]
		[Required(ErrorMessageResourceName = "CampoRequerido", ErrorMessageResourceType = typeof(i18n.ValidationStrings))]
        public String Estado { get; set; }

        public EditProyectoViewModel()
        {
        }

        public void CargarDatos(CargarDatosContext dataContext, Int32? proyectoId)
        {
            ProyectoId = proyectoId;

            if (proyectoId.HasValue)
            {
                var Proyecto = dataContext.context.Proyecto.First(x => x.ProyectoId == proyectoId);
                this.Codigo = Proyecto.Codigo;
                this.Estado = Proyecto.Estado;
                this.Nombre = Proyecto.Nombre;
            }
        }
    }
}
