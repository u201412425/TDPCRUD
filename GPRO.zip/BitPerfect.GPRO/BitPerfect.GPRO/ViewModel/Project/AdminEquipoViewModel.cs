using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using BitPerfect.GPRO.Models;
using BitPerfect.GPRO.Controllers;
using BitPerfect.GPRO.Helpers;
using System.ComponentModel.DataAnnotations;
using System.Data.Entity;


namespace BitPerfect.GPRO.ViewModel.Project
{
    public class AdminEquipoViewModel
    {
        public Int32 ProyectoId { get; set; }
        public Proyecto Proyecto { get; set; }

        public List<Usuario> LstUsuario { get; set; }
        public List<Int32> LstUsuarioSeleccionadoId { get; set; }
        
        public Dictionary<Int32,UsuarioProyecto> DictUsuarioProyecto { get; set; }

        public AdminEquipoViewModel()
        {
            LstUsuarioSeleccionadoId = new List<Int32>();
        }

        public void CargarDatos(CargarDatosContext dataContext, Int32 proyectoId)
        {
            ProyectoId = proyectoId;
            Proyecto = dataContext.context.Proyecto.Find(proyectoId);
            LstUsuario = dataContext.context.Usuario.Where(x=>x.Rol ==  ConstantHelpers.Rol.USUARIO).OrderBy(x=>x.Apellido).ThenBy(x=>x.Nombre).ToList();
            DictUsuarioProyecto = dataContext.context.UsuarioProyecto.Where(x => x.ProyectoId == proyectoId).ToDictionary(x => x.UsuarioId, x => x);
        }
    }
}
