﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BitPerfect.GPRO.Models
{
    partial class Usuario
    {
        public string NombreCompleto {
            get
            {
                return this.Nombre+" "+ this.Apellido;
            }
        }
    }
}