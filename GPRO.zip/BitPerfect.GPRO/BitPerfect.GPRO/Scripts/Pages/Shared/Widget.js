﻿$(document).ready(function () {
    refreshWidgetMessage();
    refreshWidgetFile();
    refreshWidgetBurndownChart();
});

function refreshWidgetMessage() {
    $('[data-widget-message]').each(function (e) {
        var $this = $(this);
        $this.data('widget-page', 1);
        var objeto = $this.data('widget-message');
        var objetoId = $this.data('widget-object-id');
        var url = '/Widget/ListMensaje?' + $.param({ Objeto: objeto, ObjetoId: objetoId });
        $this.load(url, function () { $this.find('[data-toggle="tooltip"]').tooltip(); });
    });
};

$(document).on('click', '[data-widget-message-action="next"]', function (e) {
    e.preventDefault();
    var $this = $(this);
    $this.button('loading');
    var $widget = $this.closest('[data-widget-message]');
    var objeto = $widget.data('widget-message');
    var objetoId = $widget.data('widget-object-id');
    var page = $widget.data('widget-page') + 1;
    var url = '/Widget/ListMensaje?' + $.param({ Objeto: objeto, ObjetoId: objetoId, Page: page });
    $widget.data('widget-page', page + 1);
    $.get(url, function (data) {
        var content = $(data).find(".chat-content").html().trim();
        if (content == "" && !$this.hasClass('animated')) {
            $this.addClass("animated shake");
            window.setTimeout(function () {
                $this.removeClass('animated shake');
            }, 2000);
        }
        $widget.find('.chat-content').append($(data).find(".chat-content").html());
        $widget.find('[data-toggle="tooltip"]').tooltip();
        $this.button('reset');
    });
});

$(document).on('submit', '[data-widget-message-action="post"]', function (e) {
    e.preventDefault();
    var $this = $(this);
    var $button = $this.find('button');
    var $text = $this.find('[name="Texto"]');
    var $widget = $this.closest('[data-widget-message]');
    var url = $this.attr('action');
    $button.button('loading');
    $.ajax({
        type: "POST",
        url: url,
        data: $this.serialize(),
        success: function (data) {
            $widget.find('.chat-content').prepend(data);
            $widget.find('[data-toggle="tooltip"]').tooltip();
            $button.button('reset');
            $text.val('');
        }
    });
});

function refreshWidgetFile() {
    $('[data-widget-file]').each(function (e) {
        var $this = $(this);
        $this.data('widget-page', 1);
        var objeto = $this.data('widget-file');
        var objetoId = $this.data('widget-object-id');
        var url = '/Widget/ListArchivo?' + $.param({ Objeto: objeto, ObjetoId: objetoId });
        $this.load(url, function () { $this.find('[data-toggle="tooltip"]').tooltip(); });
    });
};

$(document).on('click', '[data-widget-file-action="next"]', function (e) {
    e.preventDefault();
    var $this = $(this);
    $this.button('loading');
    var $widget = $this.closest('[data-widget-file]');
    var objeto = $widget.data('widget-message');
    var objetoId = $widget.data('widget-object-id');
    var page = $widget.data('widget-page') + 1;
    var url = '/Widget/ListArchivo?' + $.param({ Objeto: objeto, ObjetoId: objetoId, Page: page });
    $widget.data('widget-page', page + 1);
    $.get(url, function (data) {
        var content = $(data).find(".file-content").html().trim();
        if (content == "" && !$this.hasClass('animated')) {
            $this.addClass("animated shake");
            window.setTimeout(function () {
                $this.removeClass('animated shake');
            }, 2000);
        }
        $widget.find('.file-content').append($(data).find(".file-content").html());
        $widget.find('[data-toggle="tooltip"]').tooltip();
        $this.button('reset');
    });
});

$(document).on('submit', '[data-widget-file-action="post"]', function (e) {
    e.preventDefault();
    var $this = $(this);
    var $button = $this.find('button');
    var $text = $this.find('[name="Texto"]');
    var $widget = $this.closest('[data-widget-file]');
    var url = $this.attr('action');
    $button.button('loading');
    $.ajax({
        type: "POST",
        url: url,
        data: $this.serialize(),
        success: function (data) {
            $widget.find('.file-content').prepend(data);
            $widget.find('[data-toggle="tooltip"]').tooltip();
            $button.button('reset');
            $text.val('');
        }
    });
});

function refreshWidgetBurndownChart() {
    $('[data-widget-burndown-chart]').each(function (e) {
        var $this = $(this);
        var proyectoId = $this.data('widget-burndown-chart');
        var iteracionId = $this.data('widget-iteracion');
        var historiaId = $this.data('widget-historia');

        var url = '/Widget/BurndownChart?' + $.param({ ProyectoId: proyectoId, IteracionId: iteracionId, HistoriaId: historiaId });
        $this.load(url, function () { RebindJquery($this); });
    });
};

