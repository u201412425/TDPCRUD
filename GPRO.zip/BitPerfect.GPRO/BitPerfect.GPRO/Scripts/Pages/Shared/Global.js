﻿$(document).on('click', '[data-type="modal-link"]', function (e) {
    e.preventDefault();

    // Url de vista a cargar
    var sourceUrl = $(this).attr('data-source-url');
    var customWidth = $(this).attr('data-modal-width');
    if (customWidth) {
        $modal.css('width', customWidth + "px");
        $modal.css('margin-left', "-" + (customWidth / 2) + "px");
    }
    var $modalLoading = $('#default-modal-loading');
    var $modal = $('<div class="modal fade"><div class="modal-dialog"><div class="modal-content"></div></div></div>');
    var $modalContent = $modal.find('.modal-content');
    if (customWidth) {
        $modal.css('width', customWidth + "px");
        $modal.css('margin-left', "-" + (customWidth / 2) + "px");
    }

    $modalContent.html($modalLoading.html());

    var $container = $('#default-modal-container');
    $container.append($modal);

    var bootModal = $modal.modal('show');

    $modalContent.load(sourceUrl, function (response, status, xhr) {
        if (status == "error") {
            $modalContent.html($('#default-modal-loading-error').html());
        }
        else {
            RebindJquery($modalContent);
        }
    });

    bootModal.on('hidden.bs.modal', function () {
        $(this).remove();
    });
});

$(document).on('click', '[data-toggle]', function (e) {
    var target = $(this).data("toggle")
    $(target == "this" ? this : target).toggle();
});

$(document).on('click', '[data-hide]', function (e) {
    var target = $(this).data("hide")
    $(target == "this" ? this : target).hide();
});

$(document).on('click', '[data-show]', function (e) {
    var target = $(this).data("show")
    $(target == "this" ? this : target).show();
});

function RebindJquery($element) {
    $.validator.unobtrusive.parse($element);
    $element.find('.datepicker').datepicker({ format: 'dd/mm/yyyy', weekStart: 1 })
    $element.find('[data-toggle="tooltip"]').tooltip();
    $('.i-checks').iCheck({ checkboxClass: 'icheckbox_square-green',radioClass: 'iradio_square-green'});
}

function KeepAlive() {
    http_request = new XMLHttpRequest();
    http_request.open('GET', "/Home/KeepAlive");
    http_request.send(null);
};

$(document).ready(function () {
    setInterval(KeepAlive, 300000);
    RebindJquery($(document));
});
